# /bin/bash

ssh-add
COPY_ONLY=0
REMOTE_DIR=src/SBRS_7.0
REMOTE_MACHINES="michelangelo@10.1.0.88 diligenti@10.1.0.85 diligenti@10.1.0.26"
TARGET=TrainParallel

set -x

cd $HOME/src/eclipse
DATE=$(date +%Y%m%d)

V=7.0
tar cvfz SBRS_${V}_${DATE}.tar.gz SBRS_$V

cp -f SBRS_${V}_${DATE}.tar.gz  $HOME/Google\ Drive/Shared/PhD\ work\ and\ Documents/Code\ and\ Utilities/

for m in $REMOTE_MACHINES; do
  scp SBRS_${V}_${DATE}.tar.gz ${m}:src/.

  if [[ $COPY_ONLY == 0 ]]; then
    ssh ${m} \
      "mkdir tmp; cd tmp && rm -rf SBRS_$V && tar xvfz ~/src/SBRS_${V}_${DATE}.tar.gz && cd SBRS_${V}/$TARGET && make clean && make all && cd && rm -rf $REMOTE_DIR && mv tmp/SBRS_${V} $REMOTE_DIR && ls -l $REMOTE_DIR/${TARGET}/sbr_train" &
  fi
done
