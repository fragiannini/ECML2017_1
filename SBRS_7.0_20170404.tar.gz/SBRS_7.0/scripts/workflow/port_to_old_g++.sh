DIR=$HOME/src/SBRS_6.0
cd $DIR

for i in Train Predict; do
  pushd $i
  find . name *.mk | xargs -I{} sed -i 's/-std=c++11 /-D__NO_STD_C11__=1 /' {}
  popd
done
