#! /bin/bash 

if [[ -z $1 ]]; then DATA=biological_process; else DATA=$1; fi
if [[ -z $2 ]]; then KERNEL=interpro; else KERNEL=$2; fi
if [[ -n $3 ]]; then OPT=$3; fi

OUTDIR_BASE=experiment${DATA}_3_100/results_${KERNEL}

for f in $OUTDIR_BASE/*; do
EXPS=$(ls -d $f/?/ll* 2> /dev/null | awk -F '/' '{print $NF}' | sort | uniq)

for e in $EXPS; do
  # grep Micro_F1 $f/?/$e/results/test_summary_th0.5.dat 2> /dev/null | awk -v f="$f/?/$e/results/test_summary_th0.5.dat" 'BEGIN{n=s=0}{s+=$NF; n++}END{if(n>0) print f,s,"/",n,"=",s/n}'
  echo "$f/?/$e" $(cat $f/?/$e/results/test_results.dat | ./test.pl "$OPT" --exclude_class_prefix "BIN-FOR")
done
done