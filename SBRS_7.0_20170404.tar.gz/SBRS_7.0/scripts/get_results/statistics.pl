#! /usr/bin/perl -w

# -1 if using libSVM o SVMlight / 0 if using SBRS / 0 if using libSVM with probability estimate 
my $minTarg = 0;

sub InArray {
  my $array = shift;
  my $field = shift;
  for (my $i = 0; $i < @{$array}; ++$i) {
    if ($$array[$i] eq $field) {
      return 1;
    }
  }

  return 0;
}

# INPUT : a reference to the vector of targets, a reference to the vector of prediction and the threshold
# OUTPUT : an array with accuracy, precision, recall and F1
sub compute_statistics_by_class {

	my @targets = @{$_[0]};
   	my @predictions = @{$_[1]};
        my $treshold = $_[2];

	if ($#targets != $#predictions) {
	  die "different size: ".($#targets+1)." != ".($#predictions+1);
	}

	my $TP = 0;
	my $TN = 0;
	my $FP = 0;
	my $FN = 0;
	my $recall = 0;
	my $precision = 0;
	my $F1 = 0; 
	my $accuracy = 0;
	my $total_positive = 0;
	my $total_negative = 0;

	for (my $i=0; $i<=$#predictions; $i++) {
	 
	  if ($targets[$i] == $minTarg) {
	    $total_negative++;
	  } elsif ($targets[$i] == 1) {
	    $total_positive++;
	  } else {
	    warn "targets must be {".$minTarg.",1} : [".$i."]".$targets[$i]."\n";
	  }

	  if ($targets[$i] == $minTarg && $predictions[$i] <= $treshold) {
	    $TN++;
	  } elsif ($targets[$i] == $minTarg && $predictions[$i] > $treshold) {
	    $FP++;
	  } elsif ($targets[$i] == 1 && $predictions[$i] <= $treshold) {
	    $FN++;
	  } else {
	    $TP++;
	  }

	}

	if (($TP+$FP) != 0) {
          $precision = $TP/($TP+$FP);
	}
	if (($TP+$FN) != 0) {
          $recall = $TP/($TP+$FN);
	}
	if (($TP+$TN+$FP+$FN) != 0) {
          $accuracy = ($TP+$TN)/($TP+$TN+$FP+$FN);
	}
	if (($precision+$recall) != 0) {
          $F1 = (2*$precision*$recall)/($precision+$recall);
	}

        return ($accuracy, $precision, $recall, $F1);
}

# INPUT : a reference to the vector of targets and a reference to the vector of prediction for each function and the threshold
# OUTPUT : an array with micro and macro statistics
sub compute_multiclass_statistics {

	my @targetsVec = @{$_[0]};
   	my @predictionsVec = @{$_[1]};
        my $treshold = $_[2];

	my $total_TP = 0;
	my $total_TN = 0;
	my $total_FP = 0;
	my $total_FN = 0;
        my $macroF1 = 0;
        my $macroAccuracy = 0;
        my $macroPrecision = 0;
        my $macroRecall = 0;
	my $microRecall = 0;
	my $microPrecision = 0;
	my $microF1 = 0; 
	my $microAccuracy = 0;

	for (my $j=0; $j<=$#predictionsVec; $j++) {	   

	  my $TP = 0;
	  my $TN = 0;
	  my $FP = 0;
	  my $FN = 0;
          my $precision = 0;
          my $recall = 0;
          my $accuracy = 0;
          my $F1 = 0;

          my $n_patterns = $#{$targetsVec[$j]};
	  for (my $i=0; $i<=$n_patterns; $i++) {
	 
	    if ($targetsVec[$j][$i] != $minTarg && $targetsVec[$j][$i] != 1) {
	      warn "targets must be {".$minTarg.",1}\n";
	    }

	    if ($targetsVec[$j][$i] == $minTarg && $predictionsVec[$j][$i] <= $treshold) {
	      $TN++;
	    } elsif ($targetsVec[$j][$i] == $minTarg && $predictionsVec[$j][$i] > $treshold) {
	      $FP++;
	    } elsif ($targetsVec[$j][$i] == 1 && $predictionsVec[$j][$i] <= $treshold) {
	      $FN++;
	    } else {
	      $TP++;
	    }

	  }

	  $total_TP = $total_TP + $TP;
	  $total_TN = $total_TN + $TN;
	  $total_FP = $total_FP + $FP;
	  $total_FN = $total_FN + $FN;

	  if (($TP+$FP) != 0) {
            $precision = $TP/($TP+$FP);
	  }
	  if (($TP+$FN) != 0) {
            $recall = $TP/($TP+$FN);
	  }
	  if (($TP+$TN+$FP+$FN) != 0) {
            $accuracy = ($TP+$TN)/($TP+$TN+$FP+$FN);
	  }
	  if (($precision+$recall) != 0) {
            $F1 = (2*$precision*$recall)/($precision+$recall);
	  }

          $macroAccuracy = $macroAccuracy + $accuracy; 
	  $macroPrecision = $macroPrecision + $precision; 
	  $macroRecall = $macroRecall + $recall; 
	  $macroF1 = $macroF1 + $F1; 

	}

        $macroAccuracy = $macroAccuracy / ($#predictionsVec+1); 
	$macroPrecision = $macroPrecision / ($#predictionsVec+1); 
	$macroRecall = $macroRecall / ($#predictionsVec+1); 
	$macroF1 = $macroF1 / ($#predictionsVec+1); 

	if (($total_TP+$total_FP) != 0) {
        $microPrecision = $total_TP/($total_TP+$total_FP);
        }
	if (($total_TP+$total_FN) != 0) {
        $microRecall = $total_TP/($total_TP+$total_FN);
	}
	if (($total_TP+$total_TN+$total_FP+$total_FN) != 0) {
        $microAccuracy = ($total_TP+$total_TN)/($total_TP+$total_TN+$total_FP+$total_FN);
	}
	if (($microPrecision+$microRecall) != 0) {
        $microF1 = (2*$microPrecision*$microRecall)/($microPrecision+$microRecall);
	}

        return ($macroAccuracy, $macroPrecision, $macroRecall, $macroF1, $microAccuracy, $microPrecision, $microRecall, $microF1);

}


# INPUT : two reference to the vectors with the targets_map and predictions_map for each pattern and the threshold
# OUTPUT : the confusion table
sub compute_argmax_confusion_table {

	my @targets = @{$_[0]};
   	my @predictions = @{$_[1]};
        my $treshold = $_[2];

	my %table;
	
	#prepare confusion table
	for my $T (sort keys %{$targets[0]}) {
		my %map;
		for my $P (sort keys %{$targets[0]}) {
			$map{$P}=0;
		}
		$table{$T}=\%map;
	}

	if ($#targets != $#predictions) {
          die "error: different size ".($#targets+1)."!=".($#predictions+1)."\n";
        }

	for (my $i=0; $i<=$#targets; $i++) {

		#compute target class (in must be only one in argmax test type)
	 	my $target_class = get_winner_class(\%{$targets[$i]}, $threshold);

		#compute winner class
	 	my $predicted_class = get_winner_class(\%{$predictions[$i]}, $threshold);

		if (exists $table{$target_class}{$predicted_class}) {
			$table{$target_class}{$predicted_class}++;
		} else {
			die "error: bad construction of confusion table [".$target_class."][".$predicted_class."] does not exists\n";
		}
	}

        return %table;

}


# INPUT : confusion table
# OUTPUT : the micro and macro statistics
sub compute_argmax_statistics {

	my %table = %{$_[0]};

	my $total_TP = 0;
	my $total_TN = 0;
	my $total_FP = 0;
	my $total_FN = 0;
        my $macroF1 = 0;
        my $macroAccuracy = 0;
        my $macroPrecision = 0;
        my $macroRecall = 0;
	my $microRecall = 0;
	my $microPrecision = 0;
	my $microF1 = 0; 
	my $microAccuracy = 0;
	my $n_classes = 0;

	print_confusion_table(\%table);


	for my $T (sort keys %table) {
	  
	  $n_classes++;

  	  $macroAccuracy = $macroAccuracy + get_accuracy(\%table, $T);
          $macroPrecision = $macroPrecision + get_precision(\%table, $T);
          $macroRecall = $macroRecall + get_recall(\%table, $T);
          $macroF1 = $macroF1 + get_f1(\%table, $T);

	  $total_TP = $total_TP + get_TP(\%table, $T);
	  $total_TN = $total_TN + get_TN(\%table, $T);
	  $total_FP = $total_FP + get_FP(\%table, $T);
	  $total_FN = $total_FN + get_FN(\%table, $T);

	}

	print "tot_TP:".$total_TP." tot_TN:".$total_TN." tot_FP:".$total_FP." tot_FN:".$total_FN."\n"; 

	if (($total_TP+$total_FP) != 0) {
          $microPrecision = $total_TP/($total_TP+$total_FP);
        }
	if (($total_TP+$total_FN) != 0) {
          $microRecall = $total_TP/($total_TP+$total_FN);
	}
	if (($total_TP+$total_TN+$total_FP+$total_FN) != 0) {
          $microAccuracy = ($total_TP+$total_TN)/($total_TP+$total_TN+$total_FP+$total_FN);
	}
	if (($microPrecision+$microRecall) != 0) {
          $microF1 = (2*$microPrecision*$microRecall)/($microPrecision+$microRecall);
	}

        $macroAccuracy = $macroAccuracy / $n_classes; 
	$macroPrecision = $macroPrecision / $n_classes; 
	$macroRecall = $macroRecall / $n_classes; 
	$macroF1 = $macroF1 / $n_classes; 

        return ($macroAccuracy, $macroPrecision, $macroRecall, $macroF1, $microAccuracy, $microPrecision, $microRecall, $microF1);

}


# INPUT : a reference to the vector of targets and a reference to the vector of prediction
# OUTPUT : ROC_curve, a vector with the i-esim element a tern with TPR, FPR and the threshold
sub compute_roc_curve {

	my @targets = @{$_[0]};
   	my @predictions = @{$_[1]};
        
	@orderedScores = sort(@predictions);

        my @tpr;
	my @fpr;
	my @th;
	
	for (my $i=0; $i<=$#orderedScores; $i++) {

          my @vec;
   	  
	  my $n_patterns = $#predictions;
	  my $TH = $orderedScores[$i];
	  my $TPR = 0;
          my $FPR = 0;

	  my $TP = 0;
	  my $TN = 0;
	  my $FP = 0;
	  my $FN = 0;

	  for (my $j=0; $j<=$n_patterns; $j++) {

	    if ($targetsVec[$j][$i] == $minTarg && $predictionsVec[$j][$i] <= $TH) {
	      $TN++;
	    } elsif ($targetsVec[$j][$i] == $minTarg && $predictionsVec[$j][$i] > $TH) {
	      $FP++;
	    } elsif ($targetsVec[$j][$i] == 1 && $predictionsVec[$j][$i] <= $TH) {
	      $FN++;
	    } else {
	      $TP++;
	    }

	  }

	  $TPR = $TP/($TP+$FN);
  	  $FPR = $FP/($FP+$TN);

          push (@tpr, $TPR);
          push (@fpr, $FPR);
          push (@th, $TH);

        }

	return (@tpr, @fpr, @th);
}

# The AUC is related to the Gini coefficient G by the formula: G = 2*AUC-1 where:
# G = 1 - \sum_{i=1 .. n} (x_{i} - x_{i-1})(y_{i} - y_{i-1})
# then:
# AUC = (2-G)/2
# In this case it is computed as the sum of rectangular under the curve   
sub compute_auc {
	
	my @tpr = @{$_[0]};
   	my @fpr = @{$_[1]};
	my @th = @{$_[2]};

	if ($#tpr != $#fpr) {
	  die "different size of TPR and FPR vectors\n";
	}

	my %map;
	for (my $i=0; $i<=$#tpr; $i++) {
	  $map{$fpr[$i]}=$tpr[$i];
	}

	my @orderedfpr = (sort keys %map);

	my $n_instance = $#orderedfpr;	
	my $auc = 0;

	for (my $i=0; $i<$#n_instance; $i++) {
	  $auc = $auc + $orderedMap{$orderedfpr[$i]}*($orderedfpr[($i+1)]-$orderedfpr[$i]);
	}

	return $auc;
}

# Riceve in ingresso un file di risultati in formato SBRS e una classe 
# e restituisce la colonna di target estratta per quella classe
sub get_targets_by_id {
	
	my $filename = $_[0];
   	my $tag = $_[1];

	my @ret;

	open (DATA, $filename) || die "Can not open: $filename";

	my $linecnt = 0;
	while (my $line = <DATA>) {

		chop $line;
		$linecnt++;

		if ($line =~ /^#/) {
		    next;
		}

		my @F = split(/\t/, $line);

		if ($#F != 2) {
  		  print $filename." ".$linecnt." ".$line."\n";
		  die "error 1: ".$filename." - ".$linecnt." - ".$line."\n";;
		}

		my @targets = split(/,/, $F[1]);

		for (my $i=0; $i<=$#targets; $i++) {
		  my @value = split (/:/, $targets[$i]);
		  if ($#value != 1) {
		    warn "error 3";
		  }
		  if ($value[0] eq $tag) {
		    push @ret, ($value[1]*1);
                    last;
		  } else {
		    next;
		  }
		}
	    
	}

	return @ret;
}


# Riceve in ingresso un file di risultati in formato SBRS e una classe 
# e restituisce due vettori colonna di targets e predizioni estratta per quella classe
sub get_predictions_by_id {
	
	my $filename = $_[0];
   	my $tag = $_[1];

	my @ret;

	open (DATA, $filename) || die "Can not open: $filename";

	my $linecnt = 0;
	while (my $line = <DATA>) {

		chop $line;
		$linecnt++;

		if ($line =~ /^#/) {
		    next;
		}

		my @F = split(/\t/, $line);

		if ($#F != 2) {
  		  print $filename." ".$linecnt." ".$line."\n";
		  die "error 1";
		}

		my @predictions = split(/,/, $F[2]);

		for (my $i=0; $i<=$#predictions; $i++) {
		  my @value = split (/:/, $predictions[$i]);
		  if ($#value != 1) {
		    warn "error 3";
		  }
		  if ($value[0] eq $tag) {
		    push @ret, ($value[1]*1);
                    last;
		  } else {
		    next;
		  }
		}
	    
	}

	return @ret;
}


# Riceve in ingresso un file di risultati in formato SBRS e una classe 
# e restituisce la colonna di target e predizioni estratta per quella classe
# Questa versione è usata quando ci sono pattern unsupervised nel file.
sub get_targets_and_predictions_by_id {
	
	my $filename = $_[0];
   	my $tag = $_[1];

	my @targ;
        my @pred;

        my @ret;

	open (DATA, $filename) || die "Can not open: $filename";

	my $linecnt = 0;
	while (my $line = <DATA>) {

		chop $line;
		$linecnt++;

		if ($line =~ /^#/) {
		    next;
		}

		my @F = split(/\t/, $line);

		if ($#F != 2) {
  		  print $filename." ".$linecnt." ".$line."\n";
		  die "error 1: splitting line $line (".($#F+1).")\n";
		}

		# no targets, unsupervised pattern
		my $has_target = 0;

		my @targets = split(/,/, $F[1]);

		for (my $i=0; $i<=$#targets; $i++) {
		  my @value = split (/:/, $targets[$i]);
		  if ($#value != 1) {
		    warn "error 3";
		  }
		  if ($value[0] eq $tag) {
		    push @targ, ($value[1]*1);
                    $has_target = 1;
                    last;
		  } else {
		    next;
		  }
		}

                if ($has_target == 0) {
                  next;
                }

		my @predictions = split(/,/, $F[2]);

		for (my $i=0; $i<=$#predictions; $i++) {
		  my @value = split (/:/, $predictions[$i]);
		  if ($#value != 1) {
		    warn "error 3";
		  }
		  if ($value[0] eq $tag) {
		    push @pred, ($value[1]*1);
                    last;
		  } else {
		    next;
		  }
		}
	    
	}
 
        if ($#targ != $#pred) {
          die "targets and predictions vectors have different size\n";
        }

        push (@ret, \@targ);
	push (@ret, \@pred);

	return @ret;
}


# Riceve in ingresso un file di risultati in formato SBRS,
# il vettore di tags da considerare 
# restituisce un vettore di dimensione pari al numero di pattern
# e il cui i-esimo elemento corrisponde alla mappa di targets per quel pattern
sub get_targets_map {

	my $filename = $_[0];
	my @tags = @{$_[1]};

	my @ret;

	open (DATA, $filename) || die "Can not open: $filename";

	my $linecnt = 0;
	while (my $line = <DATA>) {

		chop $line;
		$linecnt++;

		if ($line =~ /^#/) {
		    next;
		}        

		my @F = split(/\t/, $line);

		if ($#F != 2) {
  		  print $filename." ".$linecnt." ".$line."\n";
		  die "error 1 : ".$filename." ".$linecnt." ".$line."\n";
		}

		my @data = split(/,/, $F[1]);

		my $at_least_one = 0;
		my %map;

                for (my $i=0; $i<=$#data; $i++) {
			my @value = split (/:/, $data[$i]);

			if (InArray(\@tags, $value[0]) == 1) {
				$map{$value[0]} = $value[1];
				$at_least_one = 1;
                        }

		}

		if ($at_least_one == 1) {
			push (@ret, \%map);
                }
	}

	return @ret;
}

# Riceve in ingresso un file di risultati in formato SBRS e
# il vettore di tags da considerare 
# restituisce un vettore di dimensione pari al numero di pattern
# e il cui i-esimo elemento corrisponde a alla mappa di 
# predizioni per quel pattern
sub get_predictions_map {

	my $filename = $_[0];
	my @tags = @{$_[1]};

	my @ret;

	open (DATA, $filename) || die "Can not open: $filename";

	my $linecnt = 0;
	while (my $line = <DATA>) {

		chop $line;
		$linecnt++;

		if ($line =~ /^#/) {
		    next;
		}        

		my @F = split(/\t/, $line);

		if ($#F != 2) {
  		  print $filename." ".$linecnt." ".$line."\n";
		  die "error 1";
		}

		my @data = split(/,/, $F[2]);

		my $at_least_one = 0;
		my %map;

                for (my $i=0; $i<=$#data; $i++) {
			my @value = split (/:/, $data[$i]);

			if (InArray(\@tags, $value[0]) == 1) {
				$map{$value[0]} = $value[1];
				$at_least_one = 1;
                        }

		}

		if ($at_least_one == 1) {
			push (@ret, \%map);
                }
	}

	return @ret;
}

# Rivece in ingresso una mappa con i valori associati a ogni tag
# e restituisce la classe con lo score più alto
sub get_winner_class {

	my %tags_scores = %{$_[0]};
	my $threshold = $_[1];

	my $max_score = 0;
	my $winner;

	#questo serve perche in modo da avere un valore iniziale di riferimento.
	#altrimenti iniziarlo a zero può essere sbagliato se ci sono anche valori negativi
	my $first = 1;

	for $T (sort keys %tags_scores) {
		if ($tags_scores{$T} > $max_score || $first == 1) {
			$max_score = $tags_scores{$T};
			$winner = $T;
			$first = 0;	
		}
 	}

	return $winner;
}

# Riceve in ingresso la confusion table e
# restituisce in numero di TP per lo specifico tag
sub get_TP {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;
	
	if (exists $table{$tag}{$tag}) {
		$ret = $table{$tag}{$tag};
	} else {
		die "missing entry [".$tag."][".$tag."] in confusion table\n";
	}

	return $ret;	
}


# Riceve in ingresso la confusion table e
# restituisce in numero di FP per lo specifico tag
sub get_FP {

	my %table = %{$_[0]};
	my $tag = $_[1];
		
	my $predicted_as = 0;
	for my $T (sort keys %table) {
	  $predicted_as = $predicted_as + $table{$T}{$tag};
	}	
	my $TP = get_TP(\%table, $tag);

	if ($predicted_as < $TP) {
		die "error: ".$predicted_as."<".$TP."\n";
	}

	return $predicted_as - $TP;	
}

# Riceve in ingresso la confusion table e
# restituisce in numero di TN per lo specifico tag
sub get_TN {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;

	my $TP = get_TP(\%table, $tag);
	
	my $all = 0;
	for my $T (sort keys %table) {
	  for my $P (sort keys %{$table{$T}}) {
  	    $all = $all + $table{$T}{$P};
	  }
	}

	my $predicted_as = 0;
	for my $T (sort keys %table) {
	  $predicted_as = $predicted_as + $table{$T}{$tag};
	}	

	my $target_as = 0;
	for my $T (sort keys %{$table{$tag}}) {
	  $target_as = $target_as + $table{$tag}{$T};
	}	

	if (($all + $TP) < ($predicted_as + $target_as)) {
		die "error: ".($all + $TP)."<".($predicted_as + $target_as)."\n";
        }

	return (($all + $TP) - ($predicted_as + $target_as));	
}

# Riceve in ingresso la confusion table e
# restituisce in numero di FN per lo specifico tag
sub get_FN {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;

	my $target_as = 0;
	for my $T (sort keys %{$table{$tag}}) {
	  $target_as = $target_as + $table{$tag}{$T};
	}	
	my $TP = get_TP(\%table, $tag);

	if ($target_as < $TP) {
		die "error: ".$predicted_as."<".$TP."\n";
	}
	
	return $target_as - $TP;
}


# Riceve in ingresso la confusion table e
# restituisce la metrica richiesta per lo specifico tag
sub get_accuracy {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;

	my $num = get_TP(\%table, $tag) + get_TN(\%table, $tag);
	my $den = get_TP(\%table, $tag) + get_TN(\%table, $tag) + get_FP(\%table, $tag) + get_FN(\%table, $tag);

	if ($den != 0) {
		$ret = $num / $den;
	}

	return $ret;
}

# Riceve in ingresso la confusion table e
# restituisce la metrica richiesta per lo specifico tag
sub get_precision {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;

	my $num = get_TP(\%table, $tag);
	my $den = get_TP(\%table, $tag) + get_FP(\%table, $tag);

	if ($den != 0) {
		$ret = $num / $den;
	}

	return $ret;
}

# Riceve in ingresso la confusion table e
# restituisce la metrica richiesta per lo specifico tag
sub get_recall {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;

	my $num = get_TP(\%table, $tag);
	my $den = get_TP(\%table, $tag) + get_FN(\%table, $tag);

	if ($den != 0) {
		$ret = $num / $den;
	}

	return $ret;
}

# Riceve in ingresso la confusion table e
# restituisce la metrica richiesta per lo specifico tag
sub get_f1 {

	my %table = %{$_[0]};
	my $tag = $_[1];
	my $ret = 0;

	my $recall = get_recall(\%table, $tag);
	my $precision = get_precision(\%table, $tag);
	my $den = $recall + $precision;

	if ($den != 0) {
		$ret = ((2 * $recall * $precision) / $den);
	}

	return $ret;
}

sub print_confusion_table {

	my %table = %{$_[0]};

	for my $T (sort keys %table) {
	  print $T." -";
	  for my $P (sort keys %{$table{$T}}) {
  	    print " ".$P.":".$table{$T}{$P};
	  }
	  print "\n";
	}

	return 1;
}


1
