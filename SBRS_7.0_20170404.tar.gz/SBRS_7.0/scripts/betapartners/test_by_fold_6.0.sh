#! /bin/bash

FOLD_START=${1:-"3"}
FOLD_END=${2:-"10"}

BIN_DIR="$HOME/src/SBRS_6.0/Predict"
BIN_NAME="sbr_predict"
BIN="${BIN_DIR}/${BIN_NAME}"
NUM_PROCESSES=33

cd /home/diligmic/src/SBRS_5.0/input_data
for FOLD in $(seq $FOLD_START $FOLD_END); do
pushd fold${FOLD}.data
OUTPUT_DIR=output_cc
mkdir -p $OUTPUT_DIR

for i in $(seq 0 91); do
  while [[ $(ps uxww | grep "$BIN_NAME" | wc -l | awk '{print $1}') -gt $NUM_PROCESSES ]]; do
    sleep 5;
  done
  EXT=split$i; mkdir -p $OUTPUT_DIR/$EXT;
  $BIN --data_files=test.$FOLD.data.$EXT --example_files=evidence_for_cc.examples.${EXT},test_for_cc.examples.${EXT} -test_example_index=1 --predicates_file=test.$FOLD.predicates.$EXT --rules_file=test.$FOLD.rules.$EXT -classifier_file=output_6.0/ll1-lr0.01-lc0-mlr1e-10/classifier.dat --classification_threshold=0.5 --max_iterations=100 --lambda_labeled_values=1 --lambda_constraint_values=100 --min_learning_rate_values=0 --labeled_lossfunction=2 --labeled_p1=0 --learning_rate=0.01 --min_gradient_module=1e-20 --min_total_error=1e-06 --transductive_mode=true --bias=0 --iterations_x_add_constraints=50  --learning_type=RGD --classification_threshold=0.5 --squashing_function_type=LINEAR_BIASED_SATURATED  --squashing_function_slope=0.275 --per_function_squashing_function_type=PARTNERS:LINEAR_BIASED_SATURATED:0.2,SEGMENTCONTACT:LINEAR_BIASED_SATURATED:0.275,PARALLELCONTACT:LINEAR_BIASED_SATURATED:0.2,ANTIPARALLELCONTACT:LINEAR_BIASED_SATURATED:0.325 --max_learning_rate=10 --normalize_constraints_by_cardinality=false --output_dir=$OUTPUT_DIR/$EXT --input_dir=. 2>&1 > $OUTPUT_DIR/$EXT/OUTPUT &
done
# end splits

popd
done
# end folds