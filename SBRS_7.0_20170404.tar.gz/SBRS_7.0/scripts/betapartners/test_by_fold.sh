#! /bin/bash

BIN="$HOME/src/SBRS_5.1/PredictBetaPartners/sbr_predict"

cd /home/diligmic/src/SBRS_5.0/input_data
for FOLD in $(seq 2 10); do
cd fold${FOLD}.data

OUTPUT_DIR=output_cc
mkdir -p $OUTPUT_DIR

for i in $(seq 0 30); do
  EXT=split$i; mkdir -p $OUTPUT_DIR/$EXT;
  $BIN --training_data_file=test.${FOLD}.data.$EXT --training_examples_file=test.${FOLD}.examples.$EXT --test_data_file=test.${FOLD}.data.$EXT --test_examples_file=test.${FOLD}.examples.$EXT --predicates_file=test.${FOLD}.predicates.$EXT --rules_file=test.${FOLD}.rules.$EXT --model_file=output/ll1-lr0.01-lc1-mlr1/model.dat --collective_classification=true --max_iterations=280 --lambda_labeled_values=1 --lambda_constraint_values=0.01,0.05,0.1,0.5,1 --min_learning_rate_values=0.00001 --labeled_lossfunction=2 --labeled_p1=0 --learning_rate=0.001 --min_gradient_module=1e-20 --min_total_error=1e-06 --transductive_mode=true --bias=0 --iterations_x_add_constraints=30 --learning_type=RGD --classification_threshold=0.5 --squashing_function_type=LINEAR_BIASED_SATURATED --squashing_function_slope=0.275 --per_function_squashing_function_type=PARTNERS:LINEAR_BIASED_SATURATED:0.2,SEGMENTCONTACT:LINEAR_BIASED_SATURATED:0.275,PARALLELCONTACT:LINEAR_BIASED_SATURATED:0.2,ANTIPARALLELCONTACT:LINEAR_BIASED_SATURATED:0.325 --max_learning_rate_with_constraints=10 --normalize=false --increase_learning_rate=1.25 --decrease_learning_rate=0.1 --output_dir=$OUTPUT_DIR/$EXT --input_dir=. > $OUTPUT_DIR/OUTPUT$i 2>&1 &
done

sleep 4000
for i in $(seq 31 60); do
  EXT=split$i; mkdir -p $OUTPUT_DIR/$EXT;
  $BIN --training_data_file=test.${FOLD}.data.$EXT --training_examples_file=test.${FOLD}.examples.$EXT --test_data_file=test.${FOLD}.data.$EXT --test_examples_file=test.${FOLD}.examples.$EXT --predicates_file=test.${FOLD}.predicates.$EXT --rules_file=test.${FOLD}.rules.$EXT --model_file=output/ll1-lr0.01-lc1-mlr1/model.dat --collective_classification=true --max_iterations=280 --lambda_labeled_values=1 --lambda_constraint_values=0.01,0.05,0.1,0.5,1 --min_learning_rate_values=0.00001 --labeled_lossfunction=2 --labeled_p1=0 --learning_rate=0.001 --min_gradient_module=1e-20 --min_total_error=1e-06 --transductive_mode=true --bias=0 --iterations_x_add_constraints=30 --learning_type=RGD --classification_threshold=0.5 --squashing_function_type=LINEAR_BIASED_SATURATED --squashing_function_slope=0.275 --per_function_squashing_function_type=PARTNERS:LINEAR_BIASED_SATURATED:0.2,SEGMENTCONTACT:LINEAR_BIASED_SATURATED:0.275,PARALLELCONTACT:LINEAR_BIASED_SATURATED:0.2,ANTIPARALLELCONTACT:LINEAR_BIASED_SATURATED:0.325 --max_learning_rate_with_constraints=10 --normalize=false --increase_learning_rate=1.25 --decrease_learning_rate=0.1 --output_dir=$OUTPUT_DIR/$EXT --input_dir=. > $OUTPUT_DIR/OUTPUT$i 2>&1 &
done

sleep 4000
for i in $(seq 61 91); do
  EXT=split$i; mkdir -p $OUTPUT_DIR/$EXT;
  $BIN --training_data_file=test.${FOLD}.data.$EXT --training_examples_file=test.${FOLD}.examples.$EXT --test_data_file=test.${FOLD}.data.$EXT --test_examples_file=test.${FOLD}.examples.$EXT --predicates_file=test.${FOLD}.predicates.$EXT --rules_file=test.${FOLD}.rules.$EXT --model_file=output/ll1-lr0.01-lc1-mlr1/model.dat --collective_classification=true --max_iterations=280 --lambda_labeled_values=1 --lambda_constraint_values=0.01,0.05,0.1,0.5,1 --min_learning_rate_values=0.00001 --labeled_lossfunction=2 --labeled_p1=0 --learning_rate=0.001 --min_gradient_module=1e-20 --min_total_error=1e-06 --transductive_mode=true --bias=0 --iterations_x_add_constraints=30 --learning_type=RGD --classification_threshold=0.5 --squashing_function_type=LINEAR_BIASED_SATURATED --squashing_function_slope=0.275 --per_function_squashing_function_type=PARTNERS:LINEAR_BIASED_SATURATED:0.2,SEGMENTCONTACT:LINEAR_BIASED_SATURATED:0.275,PARALLELCONTACT:LINEAR_BIASED_SATURATED:0.2,ANTIPARALLELCONTACT:LINEAR_BIASED_SATURATED:0.325 --max_learning_rate_with_constraints=10 --normalize=false --increase_learning_rate=1.25 --decrease_learning_rate=0.1 --output_dir=$OUTPUT_DIR/$EXT --input_dir=. > $OUTPUT_DIR/OUTPUT$i 2>&1 &
done
sleep 4000

cd ..
done
