#! /bin/bash

for i in $(seq 7 10); do
echo "Processing fold${i}.data"
cd fold${i}.data
mkdir -p output_6.0

cd /home/diligmic/src/SBRS_5.0/input_data/fold$i.data
~/src/SBRS_6.0/Train/sbr_train --training_data_file=train.$i.data \
  --training_examples_file=train.$i.examples --predicates_file=predicates \
  --max_iterations=450 --iteration_start_constraints=450 \
  --lambda_labeled_values=1 --lambda_regularization_values=0.01 \
  --lambda_constraint_values=0 --nn_num_units=35 --nn_num_units_by_id=PARTNERS:70 \
  --max_learning_rate=100 --min_learning_rate=0.0001 --learning_rate=0.1 \
  --random_initialization_weights=true \
  --output_dir=output_6.0 --input_dir=. --bias=0 \
  --learning_type=RGD --min_gradient_module=0 --min_gradient_module=1e-20 \
  --squashing_function_type=SIGMOID --labeled_lossfunction=2 \
  --labeled_p1=0 --labeled_p2=0 \
  --function_type=NEURAL_NETWORK --random_initialization_weights=true \
  --nn_pre_built_inputs=true --nn_stochastic_portion=0.5 > \
  output_6.0/OUTPUT 2>&1 &
cd ..
done > OUTPUT
