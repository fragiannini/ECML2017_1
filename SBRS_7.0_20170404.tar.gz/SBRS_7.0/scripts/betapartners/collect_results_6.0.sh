#! /bin/bash

FOLD_START=${1:-"3"}
FOLD_END=${2:-"10"}

for P in SEGMENTCONTACT PARTNERS; do
echo "Predicate $P"
for F in $(seq $FOLD_START $FOLD_END); do
echo "Fold $F"

pushd fold${F}.data
mkdir -p results

OFILE=/tmp/RESULTS_${RAND}

# Find the correct configuration
for i in $(ls -d output_cc/split1/collective_classification/lr* | sed 's/output_cc\/split[0123456789]\+\/collective_classification\///'); do
  NUM=$(ls -l output_cc/split*/collective_classification/$i/results/test_results.dat | wc | awk '{print $1}');
  cat output_cc/split*/collective_classification/$i/results/test_results.dat > results/res_$i
  for t in 0.05 0.1 0.15 0.2 0.25 0.27 0.3 0.35 0.4 0.5; do
    RES=$(../../scripts/compute_multiclass.pl results/res_$i $P $t | grep $P)
    echo "$RES $i Splits $NUM"
    echo $RES $i Splits $NUM >> $OFILE
  done
done
# end configuration $i

popd
done
# end fold $F

echo $RESULTS

done
# end predicate $P

# Fold averages
echo -e "\nAverage by configuration"
awk '{conf=$1" "$2" "$12; NUM[conf]++; RES[conf]+=$11} END{ for(conf in NUM) { print conf, RES[conf]/NUM[conf]; } }' $OFILE | sort
rm $OFILE