#! /bin/bash

for i in $(seq 1 10); do
set -x
  ./filter_rules.pl fold${i}.data
set +x
  cd fold${i}.data
  NUM_SPLITS=$(wc -l test.${i}.map_IN | awk '{print $1}')
set -x
  # ../split_to_n_datasets.pl test.${i}.data test.${i}.examples $NUM_SPLITS
  ../split_to_n_datasets_6.0.pl test.${i}.data evidence_for_cc.examples test_for_cc.examples $NUM_SPLITS
set +x
  cd ..
done
