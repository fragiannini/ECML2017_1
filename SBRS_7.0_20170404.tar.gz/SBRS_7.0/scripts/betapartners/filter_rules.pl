#! /usr/bin/perl -w

if (!defined $ARGV[0]) {
    die "usage: $0 foldNUM_dir";
}

$ARGV[0] =~ /^fold([\d]+)/;
if (!defined $1 || $1 eq "") {
    die "Need a fold number. Fold name should be in the form foldNUM.*";
} else {
    print "Processing fold number $1\n";
}

my $foldNum = "$1";

chdir $ARGV[0];

my $n = 0;
open MAP, "test.${foldNum}.map_IN" || die;
while (my $line = <MAP>) {
    ++$n;
}

print "Test has $n proteins\n";

seek MAP, 0, 0;
my %predicate2split;
while (my $line = <MAP>) {
    chop $line;
    my @F = split(/\s+/, $line);
    $F[0] =~ s/^s//;
    $predicate2split{$F[1]} = ($F[0] % $n);
}

my $rules;
open RULES, "test.${foldNum}.rules" || die;
while (my $line = <RULES>) {
    $rules .= $line;
}
close RULES;

my @outputs;
for (my $i = 0; $i < $n; ++$i) {
    local *OUT;
    open OUT, ">test.${foldNum}.rules.split$i";
    push @outputs, *OUT;
    print OUT $rules;
}

open RULES, "test.${foldNum}.rules_IN" || die;
while (my $line = <RULES>) {
    $line =~ /AND \((IN[A-Z]+)\(/;
    if (defined $predicate2split{$1}) {
	print { $outputs[$predicate2split{$1}] } $line;
    }
}

my @prior_inputs;
for (my $i = 0; $i < $n; ++$i) {
    local *IN;
    local $/ = undef;
    open IN, "test.${foldNum}.rules.split${i}_priors" || next;
    my $str = <IN>;
    if ($str) {
	print { $outputs[$i] } $str;
    }
}


my $predicates;
open PREDICATES, "predicates" || die;
while (my $line = <PREDICATES>) {
    $predicates .= $line;
}
close PREDICATES;

my @outputsp;
for (my $i = 0; $i < $n; ++$i) {
    local *OUT;
    open OUT, ">test.${foldNum}.predicates.split$i";
    push @outputsp, *OUT;
    print OUT $predicates;
}

open PREDICATES, "test.${foldNum}.predicates_IN" || die;
while (my $line = <PREDICATES>) {
    $line =~ /^DEF (IN[A-Z]+)\(/;
    if (defined $predicate2split{$1}) {
        print { $outputsp[$predicate2split{$1}] } $line;
    }
}


