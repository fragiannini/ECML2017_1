#! /bin/bash

# Parallelism definition
PROCESSES=3
NUM_THREADS=6

# Working environment.
BIN=/home/diligenti/src/SBRS_6.1.5/TrainParallel/sbr_train
WORKING_DIR=/home/diligenti/workspace/SBRS/input_data/ppi-pf-sgd-4
INPUT_PREFIX=/home/diligenti/workspace/SBRS/input_data/ppi-pf-sgd-4
OUTPUT_PREFIX=constraints_spd_gram_matrix5_with_inter-lvl12345_constraints_cc_only
FOLDS="0 1 2 3 4 5 6 7 8 9"

set -x
pushd ${WORKING_DIR}

for f in $FOLDS; do
    RUNNING=$(ps auxww | grep sbr_train | grep -v grep | wc -l | awk '{print $1}')
    while [[ ${RUNNING} -ge ${PROCESSES} ]]; do
        sleep 60
        RUNNING=$(ps auxww | grep sbr_train | grep -v grep | wc -l | awk '{print $1}')
    done
    
    # Run in background.
    ${BIN} --training_data_file=data/sbr-datapoints.txt \
      --training_examples_file=data/BP/sbr-fold${f}-trainset-fun.txt,data/sbr-fold${f}-trainset-int.txt \
      --validation_examples_file=data/BP/sbr-fold${f}-validset-fun.txt,data/sbr-fold${f}-validset-int.txt \
      --test_examples_file=data/BP/sbr-fold${f}-testset-fun.txt,data/sbr-fold${f}-testset-int.txt \
      --transductive=true \
      --predicates_file=data/BP/sbr-predicates.txt \
      --rules_file=rules/sbr-rules-interaction_implies_same_biological_process_levelwise_min-lvl12345.txt,rules/sbr-rules-biological_process-term_implies_and_of_parents_min.txt,rules/sbr-rules-biological_process-term_implies_or_of_children_min.txt \
      --max_iterations=500 --second_pass_max_iterations=400 --iteration_start_constraints=500 \
      --crossvalidation_iterations=10 --iterations_x_add_constraints=-1 \
      --lambda_labeled_values=1 --lambda_regularization_values=0.1 --lambda_constraint_values=0.1 \
      --function_type=KERNEL_MACHINE --gram_matrix_type=SYMMETRIC \
      --gram_matrices=PROTEIN:${INPUT_PREFIX}/kernels/p_average_kernel_symmetric.txt,PPAIR:${INPUT_PREFIX}/kernels/pp_average_kernel_symmetric5.bin:binary \
      --learning_type=RGD --learning_rate=0.0001 --decrease_learning_rate=0.1 --max_learning_rate=0.001 --learning_rate_for_constraints=0.0001 \
      --min_gradient_module=1e-09 --min_total_error=1e-06 --min_delta_error=1e-09 \
      --squashing_function_type=SIGMOID --normalize_constraints_by_cardinality=false --rgd_plus_algorithm_enabled=true \
      --run_collective_classification_after_train \
      --prebuild_constraint_patterns_size=80000 \
      --input_dir=${INPUT_PREFIX} --output_dir=results/fold${f}/${OUTPUT_PREFIX} \
      --verbose=2 --logtostdout=false \
      --active_threads=${NUM_THREADS} &
done

popd
exit 0
