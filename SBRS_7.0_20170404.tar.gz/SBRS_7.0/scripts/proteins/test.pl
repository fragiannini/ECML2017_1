#! /usr/bin/perl -w
# usage cat input_files | ./test.pl [--considered_classes comma_separated_class_list] [--exclude_class_prefix prefix_of_excluded_classes] [-threshold 0.5]
# Example:
# cat experimentbiological_process_3_100/results_interpro-match-all/OC/0/*/results/test_results.dat | ./test.pl --exclude_class_prefix "BIN-FOR"

use Getopt::Long qw(GetOptions);
my $classes;
my $exclude_prefix;
my $exclude_string = "";
my $include_string = "";
my $thr = 0.5;
my $argmax = 0;
my $argmax_over_positive = 0;
GetOptions('considered_classes=s' => \$classes,
           'exclude_class_prefix=s' => \$exclude_prefix,
           'exclude_class_matching_string=s' => \$exclude_string,
           'exclude_class_not_matching_string=s' => \$include_string,
           'argmax' => sub { $argmax = 1; },
           'argmax_over_positive' => sub { $argmax_over_positive = 1; },
           'threshold=s' => \$thr);

sub GetEntries {
  my %table;
  my $str = shift;
  my @F = split(/,/, $str);
  for (my $i = 0; $i < @F; ++$i) {
    my @F1 = split(/:/, $F[$i]);
    if (@F1 != 2) {
      warn "Wrong entry $F[$i] in $str";
      next;
    }
    # print "Adding $F1[0] in $F1[1]\n";
    $table{$F1[0]} = $F1[1];
  }

  return %table;
}

my $useConsideredClasses = 0;
my %ConsideredClasses;
if ($classes) {
  my @ConsideredClassesArray = split(/,/, $classes);
  foreach (@ConsideredClassesArray) {
    # print "Adding $_\n";
    $ConsideredClasses{$_} = 1;
  }
  $useConsideredClasses = 1;
}

my @exclude_strings = split(/,/, $exclude_string);
my @include_strings = split(/,/, $include_string);

my $TP = 0;
my $TN = 0;
my $FP = 0;
my $FN = 0;
while (my $line = <STDIN>) {
  chop $line;
  my @F = split(/\s+/, $line);
  if (@F != 3 || $F[1] eq "" || $F[2] eq "") { next; }

  my %S = GetEntries("$F[1]");
  my %V = GetEntries("$F[2]");

  my $argmaxkey = "";
  my $argmaxvalue = -10000000;
  if ($argmax == 1) {
    foreach my $key (keys %S) {
      if ($useConsideredClasses == 0 ||
          defined $ConsideredClasses{$key}) {
        if ($exclude_prefix && $key =~ /^$exclude_prefix/) {
          next;
        }
        my $skip = 0;
        foreach my $s (@exclude_strings) {
          if ($skip == 0 && $s && $key =~ /$s/) {
            $skip = 1;
            next;
          }
        }
        foreach my $s (@include_strings) {
          if ($skip == 0 && $s && $key !~ /$s/) {
            $skip = 1;
            next;
          }
        }
        if ($skip == 1) {
          next;
        }

        if ($V{$key} > $argmaxvalue && ($argmax_over_positive == 0 || $V{$key} > 0)) {
          $argmaxkey = $key;
          $argmaxvalue = $V{$key};
        }
      }
    }
  }

  if ($argmax == 1 && $argmaxkey eq "") { next; }

  foreach my $key (keys %S) {
    if (!defined $V{$key}) {
      warn "Missing value for $key : wrong line $line";
      next;
    }
    if ($useConsideredClasses == 0 ||
        defined $ConsideredClasses{$key}) {
      if ($exclude_prefix && $key =~ /^$exclude_prefix/) {
        next;
      }
      my $skip = 0;
      foreach my $s (@exclude_strings) {
        if ($skip == 0 && $s && $key =~ /$s/) {
          $skip = 1;
          next;
        }
      }
      foreach my $s (@include_strings) {
        if ($skip == 0 && $s && $key !~ /$s/) {
          $skip = 1;
          next;
        }
      }
      if ($skip == 1) {
        next;
      }

      if ($argmax == 1) {
        if ($key eq $argmaxkey && $S{$key} == 1) { $TP++; }
        elsif ($key eq $argmaxkey && $S{$key} == 0) { $FP++; }
        elsif ($S{$key} == 0) { $TN++; }
        elsif ($S{$key} == 1) { $FN++; }
      } else {
        if ($S{$key} == 1 && $V{$key} >= $thr) { $TP++; }
        elsif ($S{$key} == 0 && $V{$key} < $thr) { $TN++; }
        elsif ($S{$key} == 0 && $V{$key} >= $thr) { $FP++; }
        elsif ($S{$key} == 1 && $V{$key} < $thr) { $FN++; }
      }
    }
  }
}


print "TP $TP TN $TN FP $FP FN $FN F1 ",
      sprintf("%.3f\n", 2 * $TP / (2 * $TP + $FN + $FP));
if ($argmax == 1) {
  print "Accuracy ", $TP / ($TP + $FP), "\n";
}
