#! /bin/bash 
 
##################################################### 
# Params 
SCRIPT=/home/diligenti/src/SBRS_6.1.4/scripts/proteins/test.pl 
LEVELS="1 2 3 4 5 6 7 8 9 10" 
EXP=constraints_spd_gram_matrix5_with_inter-lvl1234_constraints_cc_only 
 
##################################################### 
# No Constraints 
FILES=results/fold?/${EXP}/ll*-lr*/results/test_results.dat 
echo No Constraints $FILES 
for L in "" $LEVELS; do 
  echo -n "l$L " 
  cat $FILES | $SCRIPT --exclude_class_not_matching_string=lvl$L --exclude_class_matching_string=lvl0,bin-term 
done 
echo -n "BOUND " 
cat $FILES | $SCRIPT --exclude_class_not_matching_string=BOUND 
 
##################################################### 
# With Constraints 
echo With Constraints $FILES 
FILES=results/fold?/${EXP}/cc/ll*-lr*/results/test_results.dat 
for L in "" $LEVELS; do 
  echo -n "l$L " 
  cat $FILES | $SCRIPT --exclude_class_not_matching_string=lvl$L --exclude_class_matching_string=lvl0,bin-term 
done 
echo -n "BOUND " 
cat $FILES | $SCRIPT --exclude_class_not_matching_string=BOUND 
 