#include "train/options.h"

#include <sstream>
#include <string>
#include <vector>

#include "utils/string_utils.h"
#include "train/trainer.h"
#include "train/loss/loss_function_factory.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/string_utils.h"


DEFINE_string(output_dir, ".", "Directory of output files");

// Learning definitions.
DEFINE_string(learning_type, "RGD", "Algorithm used during optimization procedure: Gradient Descent=GD - Resilient-BackPropagation=RPROP");
DEFINE_bool(normalize_gradient, false, "Normalize gradient before descent step.");

// Stop conditions
DEFINE_int32(max_iterations, 1000,
             "Maximum number of iterations allowed during optimization procedure");
DEFINE_int32(second_pass_max_iterations, -1,
             "Maximum number of iterations allowed during optimization procedure in the second step. "
             "If negative, the value of FLAGS_max_iterations will be used.");
DEFINE_double(min_gradient_module, 0,
              "Minimum value of the module of the Gradient * learning_rate before stopping optimization procedure");
DEFINE_double(min_total_error, 1e-6,
              "Minimum value of the total error (labeled error + regularization error + constraints error) before stopping optimization procedure");
DEFINE_double(min_delta_error, 1e-10,
              "Minimum value of delta error (|error_current - error_previous|) before stopping optimization procedure");

// Active Teaching
DEFINE_int32(iterations_x_add_constraints, 20,
        "Number of iterations before adding new constraints in active teaching mode. "
        "If <=0 then active teaching is deactivated: all constraints are added at the same time.");
// Learning Rate
DEFINE_double(learning_rate, 0.001, "Initial value of the learning rate");
DEFINE_double(second_pass_learning_rate, -1.0,
              "Initial value of the learning rate in second step "
              "collective classification. If < 0, the standard learning rate will be used.");

DEFINE_double(learning_rate_for_constraints, -1.0,
              "Initial value of the learning rate when learning with constraints, "
              "if < 0 --learning__rate will be used.");
DEFINE_double(increase_learning_rate, 1.1,
              "Learning rate increase value. NOTE: learning_rate * increase_learning_rate");
DEFINE_double(decrease_learning_rate, 0.5,
              "Learning rate decrease value. NOTE: learning_rate * decrease_learning_rate");

// Min/Max Learning Rate
DEFINE_double(min_learning_rate, 0.0, "Minimum value of the learning rate");
DEFINE_double(max_learning_rate, -1.0, "Maximum value of the learning rate, if <0 no maximum is set.");

// Constraints
DEFINE_int32(iteration_start_constraints, 0, "Iteration when constraints are activated");

// Labeled Loss Function
DEFINE_string(labeled_lossfunction, "HINGE",
        "Type of loss function used for the labeled error part:\n"
        "\tHINGE (Default), QUADRATIC, LOGISTIC, CROSS_ENTROPY, etc."
        "see loss_function_factory.h for details.");

DEFINE_double(labeled_p1, 1.0, "Labeled loss function parameter p1");
DEFINE_double(labeled_p2, 1.0, "Labeled loss function parameter p2");
DEFINE_double(labeled_p3, 0.0, "Labeled loss function parameter p3");

// Constraints Loss Function
DEFINE_string(constraints_lossfunction, "CONSTRAINT",
        "Type of loss function used for the constraints error part:\n"
        "\tCONSTRAINTS (Default), etc. see loss_function_factory.h for details.");

DEFINE_double(second_pass_lambda_constraints, 1,
             "Constraint weight to be used in collective classification.");

DEFINE_double(constraints_p1, 1.0, "Constraint loss function parameter p1");
DEFINE_double(constraints_p2, 1.0, "Constraint loss function parameter p2");
DEFINE_double(constraints_p3, 0.0, "Constraint loss function parameter p3");

// Kernel
DEFINE_string(kernel_type, "LINEAR", "Type of Kernel: GAUSSIAN - LINEAR a*x + b - POLYNOMIAL (a*x + b)^p - TANH tanh (a*x + b)");
DEFINE_string(kernelParameters, "", "Custom value for the variance of the Gaussian Kernel. NOTE: each function can use a different value (predicate/function name:value)");
DEFINE_double(sigmaGaussianKernel, 0.25, "Default value for the variance of the Gaussian Kernel");
DEFINE_double(aCoefficentKernel, 1, "Coefficient a for Linear/Polynomial/Tanh Kernel");
DEFINE_double(bCoefficentKernel, 0, "Coefficient b for Linear/Polynomial/Tanh Kernel");
DEFINE_double(pCoefficentKernel, 1, "Coefficient p for Polynomial Kernel");

DEFINE_double(center_value_gaussian_constraint, 0.5, "Value of a Gaussian in the center of the hypercube with the Gauss's Norm for the conversion of the propositional part");
DEFINE_string(distance_hypercube_constraint, "L1", "Type of norm used to compute the distance between the vertexes in the Hypercube's Norm for the conversion of the propositional part");
DEFINE_double(sigma_square_gaussian_constraint, -1, "Sigma square for Gauss's norm. If -1 the value is precomputed using expected value at the center of hypercube");

// Function
DEFINE_string(function_type, "KERNEL_MACHINE",
              "Type of functions: KERNEL_MACHINE - NEURAL_NETWORK "
              "If different predicates used different functions, you can list them as:"
              "[default_function_type],predicate1:function_type1,...,predicateN:function_typeN");
DEFINE_string(balance_weights, "", "Weight for balancing positive examples respect to negatives ones. Format: classID:value,classID:value,....");

// Gram Matrix
DEFINE_string(gram_matrices, "", "List of file containing the gram matrix, in the format: domainName1:file1,domainName2:file2");
DEFINE_bool(online_gram_matrix, false, "Optimization: compute the Gram matrix online instead of store it in memory");

// Neural Networks parameters
DEFINE_int32(nn_num_units, 10, "Number of hidden units of the generated Neural Networks.");
DEFINE_string(nn_num_units_by_id, "", "Number of hidden units of the generated Neural Networks by function id: id1:val,id2:val,...");
DEFINE_bool(nn_pre_built_inputs, true, "If the NN classifier functions should pre-build the patterns for "
        "the train dataset, instead of converting them on the fly during training. "
        "If set to true, the process will use more memory but less cpu at training time.");
DEFINE_double(nn_dropout_thr, 0.0, "Dropout portion for neural network learning.");
DEFINE_double(nn_input_dropout_thr, 0.0,
              "Dropout portion for neural network learning in the input layer. "
              "If <0 this is disabled");
DEFINE_double(nn_weight_norm_thr, -1.0, "Normalization of the norm of the input weights for each neuron.");
DEFINE_int32(nn_num_layers, 2, "Number of layers of the generated Neural Networks.");
DEFINE_string(nn_hidden_layer_activation, "LEAKYRECTIFIEDLINEAR",
        "Neuron activation function on the output layer of the generated Neural Networks.");
DEFINE_string(nn_output_layer_activation, "LECUN_HYPERBOLIC_TANGENT",
        "Neuron activation function on the output layer of the generated Neural Networks.");

DEFINE_double(stochastic_portion, 1.0, "Portion of training examples used at each step, "
        "if 1 not stochastic as all patterns are used.");
// CrossValidation during training
DEFINE_int32(crossvalidation_iterations, -1, "Interval of iterations between cross-validation during training, If -1 is deactivated");
DEFINE_string(metric, "F1", "metric for cross-validation and model selection: Accuracy - F1 - Precision - Recall");
DEFINE_bool(micro_stat, true, "micro or macro statistics for cross-validation");
DEFINE_bool(save_lowest_error_model, false, "Save the model with the lowest train error.");

using namespace Regularization;
using namespace std;


/* static */
std::string TrainOptions::LearningTypeToString(const TrainOptions::LEARNING_TYPE lt) {
    if (lt == GD)  return "GD";
    if (lt == RGD)  return "RGD";
    if (lt == RGDNBT)  return "RGDNBT";
    return "";
}

/**
 * Select the learning type from string STATIC
 **/
/* static */
TrainOptions::LEARNING_TYPE
TrainOptions::SelectLearningType(const string& learning_type)
{
    if (learning_type == "GD") {
        return GD;
    }
    if (learning_type == "RGD") {
        return RGD;
    }
    if (learning_type == "RGDNBT") {
        return RGDNBT;
    }
    FAULT("Unknown learning type: " << learning_type);
    return INVALID;
}

TrainOptions::GramMatrixFile::GramMatrixFile(const std::string& filename_, const bool binary_) :
        filename(filename_), binary(binary_) {
}

TrainOptions::TrainOptions() :
             normalize_gradient(FLAGS_normalize_gradient),
             max_iterations(FLAGS_max_iterations),
             second_pass_max_iterations(FLAGS_second_pass_max_iterations),
             min_gradient_module(FLAGS_min_gradient_module),
             min_total_error(FLAGS_min_total_error),
             min_delta_error(FLAGS_min_delta_error),
             lambda_labeled(static_cast<Value>(1)),
             lambda_regularization(static_cast<Value>(0.1)),
             lambda_constraints(static_cast<Value>(1)),
             second_pass_lambda_constraints(FLAGS_second_pass_lambda_constraints),
             iterations_x_add_constraints(FLAGS_iterations_x_add_constraints),
             learning_rate(FLAGS_learning_rate),
             second_pass_learning_rate(FLAGS_second_pass_learning_rate),
             learning_rate_for_constraints(FLAGS_learning_rate_for_constraints),
             increase_learning_rate(FLAGS_increase_learning_rate),
             decrease_learning_rate(FLAGS_decrease_learning_rate),
             min_learning_rate(FLAGS_min_learning_rate),
             max_learning_rate(FLAGS_max_learning_rate),
             iteration_start_constraints(FLAGS_iteration_start_constraints),
             labeled_loss_type(FLAGS_labeled_lossfunction),
             labeled_loss_p1(FLAGS_labeled_p1),
             labeled_loss_p2(FLAGS_labeled_p2),
             labeled_loss_p3(FLAGS_labeled_p3),
             constraints_loss_type(FLAGS_constraints_lossfunction),
             constraints_loss_p1(FLAGS_constraints_p1),
             constraints_loss_p2(FLAGS_constraints_p2),
             constraints_loss_p3(FLAGS_constraints_p3),
             crossvalidation_iterations(FLAGS_crossvalidation_iterations),
             metric(FLAGS_metric),
             micro_statistics(FLAGS_micro_stat),
             kernel_type(FLAGS_kernel_type),
             kernelParameters(FLAGS_kernelParameters),
             sigmaGaussianKernel(FLAGS_sigmaGaussianKernel),
             aCoefficentKernel(FLAGS_aCoefficentKernel),
             bCoefficentKernel(FLAGS_bCoefficentKernel),
             pCoefficentKernel(FLAGS_pCoefficentKernel),
             online_gram_matrix(FLAGS_online_gram_matrix),
             output_dir(FLAGS_output_dir),
             nn_num_units_default(FLAGS_nn_num_units),
             nn_num_layers(FLAGS_nn_num_layers),
             nn_hidden_layer_activation(FLAGS_nn_hidden_layer_activation),
             nn_output_layer_activation(FLAGS_nn_output_layer_activation),
             nn_pre_built_inputs(FLAGS_nn_pre_built_inputs),
             nn_dropout_thr(FLAGS_nn_dropout_thr),
             nn_input_dropout_thr(FLAGS_nn_input_dropout_thr),
             nn_weight_norm_thr(FLAGS_nn_weight_norm_thr),
             stochastic_portion(FLAGS_stochastic_portion),
             save_lowest_error_model(FLAGS_save_lowest_error_model) {
    learning_type = TrainOptions::SelectLearningType(FLAGS_learning_type);

    vector<string> function_types_vec;
    StringUtils::SplitToVector(
            FLAGS_function_type, &function_types_vec, ",", true);
    for (unsigned int i = 0; i < function_types_vec.size(); ++i) {
        vector<string> function_type_def;
        StringUtils::SplitToVector(
                function_types_vec[i], &function_type_def, ":", true);
        CHECK_INE_RANGE(static_cast<int>(function_type_def.size()), 1, 2);
        if (function_type_def.size() == 2) {
            function_types[function_type_def[0]] = function_type_def[1];
        } else {
            function_type = function_type_def[0];
        }
    }

    // build the labeled loss function
    const LossFunctionFactory::LOSS_FUNCTION loss_function =
            LossFunctionFactory::LossFunctionFromString(labeled_loss_type);
    CHECK_NE_WITH_MESSAGE(loss_function, LossFunctionFactory::INVALID,
                          "Invalid loss function name " + labeled_loss_type);

    labeled_loss_function = LossFunctionFactory::SelectLossFunction(
            loss_function, FLAGS_labeled_p1, FLAGS_labeled_p2, FLAGS_labeled_p3);
    // build the constraints loss function
    const LossFunctionFactory::LOSS_FUNCTION closs_function =
            LossFunctionFactory::LossFunctionFromString(constraints_loss_type);
    CHECK_NE_WITH_MESSAGE(closs_function, LossFunctionFactory::INVALID,
                          "Invalid loss function name " + constraints_loss_type);

    constraints_loss_function = LossFunctionFactory::SelectLossFunction(
            closs_function, FLAGS_constraints_p1, FLAGS_constraints_p2, FLAGS_constraints_p3);

    vector<string> gram_matrices_files;
    StringUtils::SplitToVector(
            FLAGS_gram_matrices, &gram_matrices_files, ",", true);
    for (unsigned int i = 0; i < gram_matrices_files.size(); ++i) {
        vector<string> gram_matrix_file_def;
        StringUtils::SplitToVector(
                gram_matrices_files[i], &gram_matrix_file_def, ":", true);
        CHECK_INE_RANGE(static_cast<int>(gram_matrix_file_def.size()), 2, 3);
        if(gram_matrix_file_def.size() == 3) {
            CHECK_WITH_MESSAGE(gram_matrix_file_def[2] == "binary" || gram_matrix_file_def[2] == "b",
                    " Unknown matrix loader modifier " + gram_matrix_file_def[2]);
        }
        const bool binary = (gram_matrix_file_def.size() == 3 &&
                (gram_matrix_file_def[2] == "binary" || gram_matrix_file_def[2] == "b"));
        gram_matrices_files_map[gram_matrix_file_def[0]] =
                GramMatrixFile(gram_matrix_file_def[1], binary);
    }

    StringUtils::SplitToMapByType(
                FLAGS_balance_weights, &balance_map, ",", ":", static_cast<Value>(1.0), true);
    StringUtils::SplitToMapByType(
                FLAGS_nn_num_units_by_id, &nn_num_units, ",", ":", 0, true);

    crossvalidation_dataset = NULL;
    crossvalidation_examples = NULL;

    // To DO
    this->CheckOptions();
}

TrainOptions& TrainOptions::operator=(const TrainOptions& other) {
    this->Copy(other);
    return *this;
}

void TrainOptions::Copy(const TrainOptions& options) {
    learning_type = options.learning_type;
    normalize_gradient = options.normalize_gradient;
    max_iterations = options.max_iterations;
    second_pass_max_iterations = options.second_pass_max_iterations;
    min_gradient_module = options.min_gradient_module;
    min_total_error = options.min_total_error;
    min_delta_error = options.min_delta_error;
    lambda_labeled = options.lambda_labeled;
    lambda_regularization = options.lambda_regularization;
    lambda_constraints = options.lambda_constraints;
    second_pass_lambda_constraints = options.second_pass_lambda_constraints;
    iterations_x_add_constraints = options.iterations_x_add_constraints;
    learning_rate = options.learning_rate;
    second_pass_learning_rate = options.second_pass_learning_rate;
    learning_rate_for_constraints = options.learning_rate_for_constraints;
    increase_learning_rate = options.increase_learning_rate;
    decrease_learning_rate = options.decrease_learning_rate;
    min_learning_rate = options.min_learning_rate;
    max_learning_rate = options.max_learning_rate;
    iteration_start_constraints = options.iteration_start_constraints;
    labeled_loss_type = options.labeled_loss_type;
    labeled_loss_p1 = options.labeled_loss_p1;
    labeled_loss_p2 = options.labeled_loss_p2;
    labeled_loss_p3 = options.labeled_loss_p3;
    constraints_loss_type = options.constraints_loss_type;
    constraints_loss_p1 = options.constraints_loss_p1;
    constraints_loss_p2 = options.constraints_loss_p2;
    constraints_loss_p3 = options.constraints_loss_p3;
    crossvalidation_iterations = options.crossvalidation_iterations;
    metric = options.metric;
    micro_statistics = options.micro_statistics;
    kernel_type = options.kernel_type;
    kernelParameters = options.kernelParameters;
    sigmaGaussianKernel = options.sigmaGaussianKernel;
    aCoefficentKernel = options.aCoefficentKernel;
    bCoefficentKernel = options.bCoefficentKernel;
    pCoefficentKernel = options.pCoefficentKernel;
    function_type = options.function_type;
    online_gram_matrix = options.online_gram_matrix;
    output_dir = options.output_dir;
    nn_num_units_default = options.nn_num_units_default;
    nn_num_layers = options.nn_num_layers;
    nn_hidden_layer_activation = options.nn_hidden_layer_activation;
    nn_output_layer_activation = options.nn_output_layer_activation;
    nn_pre_built_inputs = options.nn_pre_built_inputs;
    nn_dropout_thr = options.nn_dropout_thr;
    nn_input_dropout_thr = options.nn_input_dropout_thr;
    nn_weight_norm_thr = options.nn_weight_norm_thr;
    stochastic_portion = options.stochastic_portion;
    // build the labeled loss function
    labeled_loss_function = options.labeled_loss_function->Clone();
    // build the constraints loss function
    constraints_loss_function = options.constraints_loss_function->Clone();

    gram_matrices_files_map = options.gram_matrices_files_map;
    balance_map = options.balance_map;
    nn_num_units = options.nn_num_units;

    save_lowest_error_model = options.save_lowest_error_model;

    crossvalidation_dataset = options.crossvalidation_dataset;
    crossvalidation_examples = options.crossvalidation_examples;
}

TrainOptions::~TrainOptions() {
    this->Clear();
}

void TrainOptions::Clear() {
    if (labeled_loss_function != NULL)
    {
        delete labeled_loss_function;
        labeled_loss_function = NULL;
    }

    if (constraints_loss_function != NULL)
    {
        delete constraints_loss_function;
        constraints_loss_function = NULL;
    }
}

void TrainOptions::CheckOptions() {
    CHECK_INE_RANGE(stochastic_portion, 0.0, 1.0);
    // TODO
}

void TrainOptions::SetModelOptions(
        Value lambda_labeled_,
        Value lambda_regularization_,
        Value lambda_constraints_,
        const string& output_dir_) {
    lambda_labeled = lambda_labeled_;
    lambda_regularization = lambda_regularization_;
    lambda_constraints = lambda_constraints_;
    output_dir = output_dir_;
}

void TrainOptions::SetIterations(
        const Value iteration_start_constraints_, const Value max_iterations_) {
    iteration_start_constraints = iteration_start_constraints_;
    max_iterations = max_iterations_;
}

void TrainOptions::SetLearningRate(const Value learning_rate_) {
    learning_rate = learning_rate_;
}

std::string TrainOptions::ToString() const {
  std::ostringstream os;
  this->SaveToStream(os);
  return os.str();
}

bool TrainOptions::SaveToStream(ostream& os) const {
    if (constraintsWeights.size() > 0)
    {
        os << "# Rule weights " << endl;
        for (ConstraintsWeights::const_iterator it = constraintsWeights.begin();
                it != constraintsWeights.end(); ++it)
        {
            os << "R;" <<it->first <<":" <<it->second <<endl;
        }
    }
    os << "# Training Data of the Model " << endl;
    os << "P;lambda_labeled:" << this->lambda_labeled;
    os << ",lambda_regularization:" << this->lambda_regularization ;
    os << ",lambda_constraints:" << this->lambda_constraints;
    os << ",second_pass_lambda_constraints:" << this->second_pass_lambda_constraints;
    os << ",learning_rate:" << this->learning_rate;
    os << ",second_pass_learning_rate:" << this->second_pass_learning_rate;
    os << ",learning_rate_for_constraints:" << this->learning_rate_for_constraints;
    os << ",normalize_gradient:" << this->normalize_gradient;
    os << ",increase_learning_rate:" << this->increase_learning_rate;
    os << ",decrease_learning_rate:" << this->decrease_learning_rate;
    os << ",min_learning_rate:" << this->min_learning_rate;
    os << ",max_learning_rate:" << this->max_learning_rate;
    os << ",max_iterations:" << this->max_iterations;
    os << ",second_pass_max_iterations:" << this->second_pass_max_iterations;
    os << ",min_gradient_module:" << this->min_gradient_module;
    os << ",min_total_error:" << this->min_total_error;
    os << ",min_delta_error:" << this->min_delta_error;
    os << ",iteration_start_constraints:" << this->iteration_start_constraints;
    os << ",learning_type:" << TrainOptions::LearningTypeToString(this->learning_type);
    os << ",iterations_x_add_constraints:" << this->iterations_x_add_constraints;
    os << ",crossvalidation_iterations:" << this->crossvalidation_iterations;
    os << ",metric:" << this->metric;
    os << ",micro_statistics:" << this->micro_statistics;
    os <<",labeled_loss_type:" << this->labeled_loss_type;
    os <<",labeled_loss_p1:" << this->labeled_loss_p1;
    os <<",labeled_loss_p2:" << this->labeled_loss_p2;
    os <<",labeled_loss_p3:" << this->labeled_loss_p3;
    os <<",constraints_loss_type:" << this->constraints_loss_type;
    os <<",constraints_loss_p1:" << this->constraints_loss_p1;
    os <<",constraints_loss_p2:" << this->constraints_loss_p2;
    os <<",constraints_loss_p3:" << this->constraints_loss_p3;
    os <<",kernel_type:" <<this->kernel_type;
    os <<",kernelParameters:" <<this->kernelParameters;
    os <<",sigmaGaussianKernel:" <<this->sigmaGaussianKernel;
    os <<",aCoefficentKernel:" <<this->aCoefficentKernel;
    os <<",bCoefficentKernel:" <<this->bCoefficentKernel;
    os <<",pCoefficentKernel:" <<this->pCoefficentKernel;
    os <<",function_type:" <<this->function_type;
    os <<",nn_num_units_default:" <<this->nn_num_units_default;
    os <<",nn_num_layers:" <<this->nn_num_layers;
    os <<",nn_hidden_layer_activation:" <<this->nn_hidden_layer_activation;
    os <<",nn_output_layer_activation:" <<this->nn_output_layer_activation;
    os <<",nn_pre_built_inputs" << this->nn_pre_built_inputs;
    os <<",nn_dropout_thr:" << this->nn_dropout_thr;
    os <<",nn_weight_norm_thr" << this->nn_weight_norm_thr;
    os <<",nn_input_dropout_thr:" << this->nn_input_dropout_thr;
    os <<",stochastic_portion" << this->stochastic_portion;
    os <<",nn_num_units:" << StringUtils::MapToString(this->nn_num_units, ";", "-", "");
    os << ",save_lowest_error_model:" << save_lowest_error_model << endl;
    return true;
}

void TrainOptions::Save(const string& filename) const {
    ofstream os(filename.c_str());
    CHECK(os.good());
    CHECK(this->SaveToStream(os));
    os.close();
}

// Load entire model
bool TrainOptions::Load(const string& filename) {
    this->Clear();

    // Opening the model file
    ifstream ifs(filename.c_str());
    if (!ifs.is_open()) {
        WARN("Could not open the file " << filename);
        return false;
    }

    string line;
    unsigned int lineCounter = static_cast<unsigned int>(0);

    while (!ifs.eof())
    {
        line.clear();
        getline(ifs, line);
        lineCounter++;

        // skip empty lines and carriage return
        if (line.empty() || line.size() == 1)
            continue;

        // skip comment line
        if (line.find('#') == 0)
            continue;

        vector<string> optionsLine;
        StringUtils::SplitToVector(line, &optionsLine, ";", 0);

        if (optionsLine[0] == "P")
        {
            CHECK_EQ(static_cast<int>(optionsLine.size()), 2);

            map<string, string> mapOptions;
            StringUtils::SplitToMapByType(optionsLine[1], &mapOptions, ",", ":",
                                          string("0") /* default */, false);

            StringUtils::ReadElement(mapOptions["lambda_labeled"], &lambda_labeled);
            StringUtils::ReadElement(mapOptions["lambda_regularization"], &lambda_regularization);
            StringUtils::ReadElement(mapOptions["lambda_constraints"], &lambda_constraints);
            StringUtils::ReadElement(mapOptions["second_pass_lambda_constraints"], &second_pass_lambda_constraints);
            StringUtils::ReadElement(mapOptions["learning_rate"], &learning_rate);
            StringUtils::ReadElement(mapOptions["second_pass_learning_rate"], &second_pass_learning_rate);
            StringUtils::ReadElement(mapOptions["learning_rate_for_constraints"], &learning_rate_for_constraints);
            StringUtils::ReadElement(mapOptions["normalize_gradient"], &normalize_gradient);
            StringUtils::ReadElement(mapOptions["increase_learning_rate"], &increase_learning_rate);
            StringUtils::ReadElement(mapOptions["decrease_learning_rate"], &decrease_learning_rate);
            StringUtils::ReadElement(mapOptions["min_learning_rate"], &min_learning_rate);
            StringUtils::ReadElement(mapOptions["max_learning_rate"], &max_learning_rate);
            StringUtils::ReadElement(mapOptions["max_iterations"], &max_iterations);
            StringUtils::ReadElement(mapOptions["second_pass_max_iterations"], &second_pass_max_iterations);
            StringUtils::ReadElement(mapOptions["min_gradient_module"], &min_gradient_module);
            StringUtils::ReadElement(mapOptions["min_total_error"], &min_total_error);
            StringUtils::ReadElement(mapOptions["min_delta_error"], &min_delta_error);
            StringUtils::ReadElement(mapOptions["iteration_start_constraints"], &iteration_start_constraints);
            StringUtils::ReadElement(mapOptions["iterations_x_add_constraints"], &iterations_x_add_constraints);
            StringUtils::ReadElement(mapOptions["labeled_loss_type"], &labeled_loss_type);
            StringUtils::ReadElement(mapOptions["labeled_loss_p1"], &labeled_loss_p1);
            StringUtils::ReadElement(mapOptions["labeled_loss_p2"], &labeled_loss_p2);
            StringUtils::ReadElement(mapOptions["labeled_loss_p3"], &labeled_loss_p3);
            StringUtils::ReadElement(mapOptions["constraints_loss_type"], &constraints_loss_type);
            StringUtils::ReadElement(mapOptions["constraints_loss_p1"], &constraints_loss_p1);
            StringUtils::ReadElement(mapOptions["constraints_loss_p2"], &constraints_loss_p2);
            StringUtils::ReadElement(mapOptions["constraints_loss_p3"], &constraints_loss_p3);
            StringUtils::ReadElement(mapOptions["kernel_type"], &kernel_type);
            StringUtils::ReadElement(mapOptions["kernelParameters"], &kernelParameters);
            StringUtils::ReadElement(mapOptions["sigmaGaussianKernel"], &sigmaGaussianKernel);
            StringUtils::ReadElement(mapOptions["aCoefficentKernel"], &aCoefficentKernel);
            StringUtils::ReadElement(mapOptions["bCoefficentKernel"], &bCoefficentKernel);
            StringUtils::ReadElement(mapOptions["pCoefficentKernel"], &pCoefficentKernel);
            StringUtils::ReadElement(mapOptions["function_type"], &function_type);
            StringUtils::ReadElement(mapOptions["_default"], &nn_num_units_default);
            StringUtils::ReadElement(mapOptions["nn_num_layers"], &nn_num_layers);
            StringUtils::ReadElement(mapOptions["nn_hidden_layer_activation"], &nn_hidden_layer_activation);
            StringUtils::ReadElement(mapOptions["nn_output_layer_activation"], &nn_output_layer_activation);
            StringUtils::ReadElement(mapOptions["stochastic_portion"], &stochastic_portion);
            StringUtils::SplitToMapByType(mapOptions["nn_num_units"], &nn_num_units, ";", "-", 0, true);
            StringUtils::ReadElement(mapOptions["nn_pre_built_inputs"], &nn_pre_built_inputs);
            StringUtils::ReadElement(mapOptions["nn_dropout_thr"], &nn_dropout_thr);
            StringUtils::ReadElement(mapOptions["nn_input_dropout_thr"], &nn_input_dropout_thr);
            StringUtils::ReadElement(mapOptions["nn_weight_norm_thr"], &nn_weight_norm_thr);
            StringUtils::ReadElement(mapOptions["metric"], &metric);
            StringUtils::ReadElement(mapOptions["micro_statistics"], &micro_statistics);
            StringUtils::ReadElement(mapOptions["crossvalidation_iterations"], &crossvalidation_iterations);
            StringUtils::ReadElement(mapOptions["save_lowest_error_model"], &save_lowest_error_model);

            learning_type = TrainOptions::SelectLearningType(mapOptions["learning_type"]);

            // build the labeled loss function
            const LossFunctionFactory::LOSS_FUNCTION loss_function =
                    LossFunctionFactory::LossFunctionFromString(labeled_loss_type);
            CHECK_NE_WITH_MESSAGE(loss_function, LossFunctionFactory::INVALID,
                                  "Invalid loss function name " + labeled_loss_type);
            labeled_loss_function = LossFunctionFactory::SelectLossFunction(
                    loss_function, labeled_loss_p1, labeled_loss_p2, labeled_loss_p3);

            // build the constraints loss function
            const LossFunctionFactory::LOSS_FUNCTION closs_function =
                     LossFunctionFactory::LossFunctionFromString(constraints_loss_type);
            CHECK_NE_WITH_MESSAGE(closs_function, LossFunctionFactory::INVALID,
                                  "Invalid loss function name " + constraints_loss_type);
            constraints_loss_function = LossFunctionFactory::SelectLossFunction(
                    closs_function, constraints_loss_p1, constraints_loss_p2, constraints_loss_p3);
        } else if (optionsLine[0] == "R") {
            vector<string> vec;
            StringUtils::SplitToVector(optionsLine[1], &vec, ":", 0);
            CHECK_EQ(static_cast<int>(vec.size()), 2);
            Value weight;
            StringUtils::ReadElement(vec[1], &weight);
            constraintsWeights[vec[0]]=weight;
        }
    }

    return true;
}
