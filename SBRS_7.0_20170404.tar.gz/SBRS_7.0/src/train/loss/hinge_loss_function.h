#ifndef HINGE_LOSS_FUNCTION_H
#define HINGE_LOSS_FUNCTION_H

#include "train/loss/bilateral_hinge_loss_function.h"

namespace Regularization
{

/*
\
 \
  \
   \
    \_________________________
 */
class HingeLossFunction : public BilateralHingeLossFunction
{
    public:
        HingeLossFunction(Value threshold_, Value slope_before_threshold_) :
            BilateralHingeLossFunction(threshold_, slope_before_threshold_, 0.0)
        {
        }

        virtual ~HingeLossFunction()
        {
        }

        virtual std::string Name() const { return "HINGE"; }
        virtual LossFunction* Clone() {
            return new HingeLossFunction(threshold, slope_before_threshold);
        }
}; // end HingeLossFunction
} // end namespace Regularization
#endif /* HINGE_LOSS_FUNCTION_H */
