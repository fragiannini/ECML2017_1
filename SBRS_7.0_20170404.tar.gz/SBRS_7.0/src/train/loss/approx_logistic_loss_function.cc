#include "train/loss/approx_logistic_loss_function.h"
#include "utils/general.h"
#include <cmath>

namespace Regularization
{

/************************************************************
 *
 * Logistic Taylor approximation:
 * 	log(2)- d1 * (x-u0) + (d2/2) * (x-u0)^2
 *
 ************************************************************/
ApproxLogisticLossFunction::ApproxLogisticLossFunction(Value u0_,
        Value k_,
        Value s_) : u0(u0_), k(k_), s(s_)
{
    CHECK_GT(s, static_cast<Value> (0.0));
    this->Init();
}

ApproxLogisticLossFunction::~ApproxLogisticLossFunction()
{
}

void ApproxLogisticLossFunction::Init()
{
    ep = exp(-s * (u0 - k));
    epp = ep + 1;
    // derivative 0 in u0
    d0 = log(epp);
    // derivative 1 in u0
    d1 = -s * (ep / epp);
    // derivative 2 in u0
    d2 = (-s / epp) * d1;
    m = Eval(1, 1);
    n = Eval(0, 0);
}

/*
 * m: the value that the function g(u) should have in u=1
 * n: the value that the function g(u) should have in u=0
 * k: the translation value to have g(1)=m and g(0)=n
 * s: the slope value to have g(1)=m and g(0)=n
 *
 */
void ApproxLogisticLossFunction::EvalParameters(Value u0_, Value m_, Value n_)
{
    u0 = u0_;
    s = (1 / u0) * log((exp(n_) - 1) / (exp(m_) - 1));
    k = (1 / s) * log(exp(n_) - 1);
}

Value ApproxLogisticLossFunction::Eval(const Value value, const Value target) const
{
    Value y = value * target - u0;
    return d0 + d1 * y + (0.5 * d2 * (y * y));
}

Value ApproxLogisticLossFunction::EvalDerivative(const Value value, const Value target) const
{
    Value y = value * target - u0;
    return (d1 + d2 * y);
}

}
