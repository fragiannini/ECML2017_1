#ifndef LOSS_FUNCTION_H
#define LOSS_FUNCTION_H

#include <string>
#include "data/basic_data_types.h"

namespace Regularization
{

class Function;

class LossFunction
{
    public:
        typedef Regularization::Value Value;

        LossFunction()
        {
        }

        virtual ~LossFunction()
        {
        }

        virtual std::string Name() const = 0;
        /**
         * It evaluates the loss function
         */
        virtual Value Eval(const Value value, const Value target) const = 0;
        virtual Value EvalDerivative(Value value, Value target) const = 0;
        virtual LossFunction* Clone() = 0;

        // Converts a value in the [0,1] interval into the [-1,1] one.
        static inline Value MAP_TO(Value val) {
            return static_cast<Value> (val * 2.0 - 1.0);
        }

        // Converts a value in the [-1,1] interval into the [0,1] one.
        static inline Value MAP_FROM(Value val) {
            return static_cast<Value> ((val + 1.0) * 0.5);
        }

}; // end LossFunction

} // end namespace Regularization
#endif /* LOSS_FUNCTION_H */
