#ifndef QUADRATIC_LOSS_FUNCTION_H
#define QUADRATIC_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"

namespace Regularization
{

/*
 *
 * \        /
 *  \      /
 *   \____/
 *
 */
class QuadraticLossFunction : public LossFunction
{
    public:
        QuadraticLossFunction(Value threshold_);
        virtual ~QuadraticLossFunction();

        Value Eval(const Value value, const Value target) const;
        Value EvalDerivative(const Value value, const Value target) const;
        virtual std::string Name() const { return "QUADRATIC"; }
        virtual LossFunction* Clone() {
            return new QuadraticLossFunction(threshold);
        }
    private:
        Value threshold;

}; // end QuadraticLossFunction
} // end Regularization

#endif /* QUADRATIC_LOSS_FUNCTION_H */
