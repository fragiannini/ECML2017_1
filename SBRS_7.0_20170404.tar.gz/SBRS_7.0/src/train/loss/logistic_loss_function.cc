#include "train/loss/logistic_loss_function.h"
#include "utils/general.h"

#include <iostream>
#include <limits>
#if __NO_STD_C11__ > 0
#include <math.h>  // as isnan and isinf are not in cmath for old macosx
#else
#include <cmath>
#endif


using namespace std;

namespace Regularization
{

/********************************************
 *
 * Logistic: log(1+e^[-s(x-k)])
 *
 ********************************************/
LogisticLossFunction::LogisticLossFunction(Value k_, Value s_) : k(k_), s(s_)
{
    CHECK_GT(s, static_cast<Value> (0.0));
    m = Eval(1);
    n = Eval(0);

   if (GetVerboseLevel() > 2)
        this->Info();
}

LogisticLossFunction::~LogisticLossFunction()
{
}

/*
 * m: the value that the function g(u) should have in u=1
 * n: the value that the function g(u) should have in u=0
 * k: the translation value to have g(1)=m and g(0)=n
 * s: the slope value to have g(1)=m and g(0)=n
 */
void LogisticLossFunction::SetParameters(const Value m_, const Value n_)
{
    // Computes s and k based on the passed m and n
    s = log((exp(n_) - 1) / (exp(m_) - 1));
    k = (1.0 / s) * log(exp(n_) - 1);
    m = Eval(1);
    n = Eval(0);

    if (GetVerboseLevel() > 2)
        this->Info();
}

void LogisticLossFunction::Info() const
{
    std::cout << "---------------------------------------" << std::endl;
    std::cout << "LogisticLossFunction" << std::endl;
    std::cout << "\tk=" << k << std::endl;
    std::cout << "\ts=" << s << std::endl;
    std::cout << std::endl;
    std::cout << "\tm=" << m << std::endl;
    std::cout << "\tn=" << n << std::endl;
}

Value LogisticLossFunction::Eval(const Value value) const
{
  const Value exponent = -s * (value - k);
  static const Value max_log = log(numeric_limits<Value>::max());
  if (exponent >= max_log) {
      return max_log;  // exponent can not be computed as it would result in an inf.
  }

  const Value e = exp(exponent);
  if (e == 0) {
    return static_cast<Value> (0.0);
  }

  const Value r = log(1.0 + e);

#if __NO_STD_C11__ > 0
  return r;
#else
  if (std::isinf(r) || std::isnan(r))
      return std::numeric_limits<Value>::max();
#endif
    return r;
}

Value LogisticLossFunction::Eval(const Value value, const Value target) const
{
    const Value temp = value * target;
    const Value exponent = -s * (temp - k);
    static const Value max_log = log(numeric_limits<Value>::max());
    if (exponent >= max_log) {
        return max_log;  // exponent can not be computed as it would result in an inf.
    }

    const Value e = exp(exponent);
    if (e == 0) {
        return static_cast<Value>(0.0);
    }

    const Value r = log(1.0 + e);
#if __NO_STD_C11__ > 0
    return r;
#else
    if (std::isinf(r) || std::isnan(r))
        return std::numeric_limits<Value>::max();
#endif
    return r;
}

Value LogisticLossFunction::EvalDerivative(const Value value, const Value target) const
{
    const Value exponent = -s * (value - k);
    static const Value max_log = log(numeric_limits<Value>::max());  // static so to call "log" only once.
    if (exponent >= max_log) {
        // exp can not be computed as too large, in any case the derivative can be approximated as:
        return -s / target;
    }
    const Value e = exp(exponent);
    return -s * target / (1 + (1 / e));
}

}
