#ifndef LINEAR_LOSS_FUNCTION_H
#define LINEAR_LOSS_FUNCTION_H

#include "train/loss/bilateral_hinge_loss_function.h"

namespace Regularization
{

/*
 * \
 *  \
 *   \
 *    \
 *     \
 *      \
 *       \
 *        \
 */
class LinearLossFunction : public BilateralHingeLossFunction
{
    public:

        LinearLossFunction(Value threshold_, Value slope_before_threshold_) :
            BilateralHingeLossFunction(threshold_, slope_before_threshold_,
                                       slope_before_threshold_)
        {
        }

        virtual LossFunction* Clone() {
            return new LinearLossFunction(threshold, slope_before_threshold);
        }

        virtual ~LinearLossFunction()
        {
        }
        virtual std::string Linear() const { return "LINEAR"; }
}; // LinearLossFunction
} // end namespace Regularization
#endif /* LINEAR_LOSS_FUNCTION_H */
