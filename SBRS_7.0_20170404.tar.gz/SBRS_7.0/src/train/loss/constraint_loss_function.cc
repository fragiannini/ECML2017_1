#include "train/loss/constraint_loss_function.h"


namespace Regularization {

/*******************************************
 *
 * ConstraintLossFunction
 *
 *******************************************/
ConstraintLossFunction::ConstraintLossFunction() { }

/**
 * Destructor
 **/
ConstraintLossFunction::~ConstraintLossFunction() {
}

/**
 * Eval with argument [max(0, 1 - f(x)*y)]
 **/
Value ConstraintLossFunction::Eval(const Value value, const Value target) const {
    const Value diff = 1.0 - value * target;
    return (diff > 0 ? diff : 0);
}

/**
 * Eval derivative with argument  dL/df=-y
 **/
Value ConstraintLossFunction::EvalDerivative(const Value value, const Value target) const {
	  const Value diff = 1.0 - value * target;
	  return (diff > 0 ? -target : 0);
}
}  // end Regularization
