#ifndef CROSS_ENTROPY_LOSS_FUNCTION_H
#define CROSS_ENTROPY_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"

namespace Regularization {
// Defined only for values and targets in [0,1], remember to apply
// a Sigmoid on the output of your functions.
class CrossEntropyLossFunction : public LossFunction {
    public:
    CrossEntropyLossFunction();
    virtual ~CrossEntropyLossFunction();

    Value Eval(const Value value, const Value target) const;
    Value EvalDerivative(const Value value, const Value target) const;
    virtual std::string Name() const { return "CROSS_ENTROPY"; }
    virtual LossFunction* Clone() {
        return new CrossEntropyLossFunction();
    }
};  // end CrossEntropyLossFunction
}   // end Regularization

#endif /* CROSS_ENTROPY_LOSS_FUNCTION_H */
