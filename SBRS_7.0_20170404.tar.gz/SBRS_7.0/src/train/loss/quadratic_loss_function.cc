#include <cmath>

#include "train/loss/quadratic_loss_function.h"
#include "utils/general.h"

namespace Regularization
{

/*********************************
 *
 * QuadraticLossFunction
 *
 *********************************/
QuadraticLossFunction::QuadraticLossFunction(Value threshold_) : threshold(threshold_)
{
}

QuadraticLossFunction::~QuadraticLossFunction()
{
}

/**
 * It evaluates the quadratic ErrorFunction, i.e. (value-target)^2
 */
Value QuadraticLossFunction::Eval(const Value value, const Value target) const
{
    Value diff = value - target;
    if (std::abs(diff) <= threshold)
        return 0;

    if (diff > 0) {
        diff -= threshold;
    } else {
        diff += threshold * (diff > 0 ? -1.0 : +1);
    }

    return 0.5 * diff * diff;
}

/**
 * It evaluates the result of the derivative of the quadratic function, i.e. val.
 */
Value QuadraticLossFunction::EvalDerivative(const Value value, const Value target) const
{
    Value diff = value - target;
    if (std::abs(diff) <= threshold)
        return 0;

    if (diff > 0) {
        diff -= threshold;
    } else {
        diff += threshold * (diff > 0 ? -1.0 : +1.0);
    }
    return diff;
}
}  // end Regularization
