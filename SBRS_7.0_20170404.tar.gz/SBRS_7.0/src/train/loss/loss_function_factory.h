#ifndef LOSSFUNCTIONFACTORY_H
#define LOSSFUNCTIONFACTORY_H

#include "train/loss/approx_logistic_loss_function.h"
#include "train/loss/bilateral_hinge_loss_function.h"
#include "train/loss/bilateral_qhinge_loss_function.h"
#include "train/loss/hinge_loss_function.h"
#include "train/loss/linear_loss_function.h"
#include "train/loss/logistic_loss_function.h"
#include "train/loss/qhinge_loss_function.h"
#include "train/loss/quadratic_loss_function.h"
#include "train/loss/cross_entropy_loss_function.h"
#include "train/loss/constraint_loss_function.h"


namespace Regularization
{
class LossFunctionFactory
{
public:
    enum LOSS_FUNCTION {
        HINGE = 0,
        BILATERAL_HINGE = 1,
        QUADRATIC = 2,
        LOGISTIC = 3,
        QHINGE = 4,
        BILATERAL_QHINGE = 5,
        CROSS_ENTROPY = 6,
        CONSTRAINT = 7,
        INVALID = 8
    };

    static LOSS_FUNCTION LossFunctionFromString(const std::string& loss_function_name) {
        if (loss_function_name == "HINGE") {
            return HINGE;
        }
        if (loss_function_name == "BILATERAL_HINGE") {
            return BILATERAL_HINGE;
        }
        if (loss_function_name == "QUADRATIC") {
            return QUADRATIC;
        }
        if (loss_function_name == "LOGISTIC") {
            return LOGISTIC;
        }
        if (loss_function_name == "QHINGE") {
            return QHINGE;
        }
        if (loss_function_name == "BILATERAL_QHINGE") {
            return BILATERAL_QHINGE;
        }
        if (loss_function_name == "CROSS_ENTROPY") {
            return CROSS_ENTROPY;
        }
        if (loss_function_name == "CONSTRAINT") {
            return CONSTRAINT;
        }
        WARN("Unknown cost function " << loss_function_name);
        return INVALID;
    }

    static std::string LossFunctionToString(const LOSS_FUNCTION loss_function_type) {
        switch (loss_function_type)
        {
        case HINGE:
            return "HINGE";
        case BILATERAL_HINGE:
            return "BILATERAL_HINGE";
        case QUADRATIC:
            return "QUADRATIC";
        case LOGISTIC:
            return "LOGISTIC";
        case QHINGE:
            return "QHINGE";
        case BILATERAL_QHINGE:
            return "BILATERAL_QHINGE";
        case CROSS_ENTROPY:
            return "CROSS_ENTROPY";
        case CONSTRAINT:
            return "CONSTRAINT";
        default:
            FAULT("Unknown cost function " << static_cast<int>(loss_function_type));
        }
        return "";  // we never get here.
    }

    static Regularization::LossFunction* SelectLossFunction(const LOSS_FUNCTION loss_function_type,
            Value p1, Value p2, Value p3)
    {
        switch (loss_function_type)
        {
        case HINGE:
            return new HingeLossFunction(p1, p2);
        case BILATERAL_HINGE:
            return new BilateralHingeLossFunction(p1, p2, p3);
        case QUADRATIC:
            return new QuadraticLossFunction(p1);
        case LOGISTIC:
            return new LogisticLossFunction(p1, p2);
        case QHINGE:
            return new QHingeLossFunction(p1, p2);
        case BILATERAL_QHINGE:
            return new BilateralQHingeLossFunction(p1, p2, p3);
        case CROSS_ENTROPY:
            return new CrossEntropyLossFunction();
        case CONSTRAINT:
            return new ConstraintLossFunction();
        default:
            FAULT("Uknown const function " << static_cast<int>(loss_function_type));
        }

        return NULL;
    }
}; // end LossFunctionFactory

} // end namespace Regularization
#endif /* LOSSFUNCTIONFACTORY_H */
