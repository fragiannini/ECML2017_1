#ifndef BILATERAL_QHINGE_LOSS_FUNCTION_H
#define BILATERAL_QHINGE_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"

namespace Regularization
{
/*
\             /
 \         ---
  \       /
   \  ---
    \/
*/
class BilateralQHingeLossFunction : public LossFunction
{
    public:
        BilateralQHingeLossFunction(
            Value threshold_,  // where becomes zero
            Value slope_before_threshold_, // value at x=0
            Value slope_after_threshold_);  // slope after threshold.
        ~BilateralQHingeLossFunction();

        Value Eval(const Value value, const Value target) const;
        Value EvalDerivative(const Value value, const Value target) const;
        virtual std::string Name() const { return "BILATERAL_QHINGE"; }
        virtual LossFunction* Clone() {
            return new BilateralQHingeLossFunction(threshold,
                                                   slope_before_threshold,
                                                   slope_after_threshold);
        }
    protected:
        Value threshold;
        Value slope_before_threshold;
        Value slope_after_threshold;

}; // end BilateralHingeLossFunction
} // end namespace Regularization
#endif /* BILATERAL_HINGE_LOSS_FUNCTION_H */
