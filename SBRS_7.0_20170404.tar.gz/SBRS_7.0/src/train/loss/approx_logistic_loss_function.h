#ifndef APPROX_LOGISTIC_LOSS_FUNCTION_H
#define APPROX_LOGISTIC_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"

namespace Regularization
{

/*
 * Logistic, Taylor approximation: log(2)-(1/2)x+(1/8)x^2
 *
 */
class ApproxLogisticLossFunction : public LossFunction
{
    public:

        ApproxLogisticLossFunction(Value u0_,
                                   Value k_, // traslation value
                                   Value s_);
        ~ApproxLogisticLossFunction();

        Value Eval(const Value value, const Value target) const;
        Value EvalDerivative(const Value value, const Value target) const;
        virtual std::string Name() const { return "APPROX"; }
        virtual LossFunction* Clone() {
            return new ApproxLogisticLossFunction(u0, k, s);
        }

    private:

        Value u0; // point around which the approximation is computed: u0
        Value k; // translation
        Value s; // slope
        Value m; // value in u=1
        Value n; // value in u=0
        Value ep; // exp(-s*(u-k))
        Value epp; // [1+exp(-s*(u-k))]
        Value d0; // derivative 0 computed in u0: first coefficient (exponent 0) of the Taylor expansion
        Value d1; // derivative 1 computed in u0: second coefficient (exponent 1) of the Taylor expansion
        Value d2; // derivative 2 computed in u0: third coefficient (exponent 2) of the Taylor expansion

        void Init();

        /*
         * m: the value that the function g(u) should have in u=1
         * n: the value that the function g(u) should have in u=0
         * k: the translation value to have g(1)=m and g(0)=n
         * s: the slope value to have g(1)=m and g(0)=n
         */
        void EvalParameters(Value u0_, Value m_, Value n_);
}; // end ApproxLogisticLossFunction
} // end Regularization
#endif /* APPROX_LOGISTIC_LOSS_FUNCTION_H */
