#ifndef LOGISTIC_LOSS_FUNCTION_H
#define LOGISTIC_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"

namespace Regularization
{

/*
 * Logistic: log(1+e^[-s(x-k)]
 *
 */
class LogisticLossFunction : public LossFunction
{
    public:
        LogisticLossFunction(const Value k_, // translation value
                             const Value s_); // slope
        ~LogisticLossFunction();
        /*
         *
         */
        void Info() const;
        /*
         *
         */
        Value Eval(const Value value, const Value target) const;
        Value EvalDerivative(const Value value, const Value target) const;

        virtual std::string Name() const { return "LOGISTIC"; }
        virtual LossFunction* Clone() {
            return new LogisticLossFunction(k, s);
        }

    private:

        Value k;
        Value s;

        Value m; // value in u=1
        Value n; // value in u=0

        void SetParameters(Value m_, Value n_);

        Value Eval(const Value value) const;

}; // end LogisticLossFunction

} // end namespace Regularization

#endif /* LOGISTIC_LOSS_FUNCTION_H */
