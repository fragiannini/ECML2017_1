/*
 * train_runner_helper.cc
 *
 *  Created on: Dec 24, 2015
 *      Author: michi
 */

#include "train/train_runner_helper.h"

#include <sstream>
#include <string>

#if __ACTIVATE_OPENMP_TRAINER__ > 0 || __ACTIVATE_OPENMP_FUNCTIONS__ > 0 || __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#include <omp.h>
#endif

#include "classifier/classifier.h"
#include "classifier/collective_classifier.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix_utils.h"
#include "constraints/constraints_factory.h"
#include "classifier/test_utils/test_utils.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "data/FOL_knowledge_base.h"
#include "data/predicates.h"
#include "train/options.h"
#include "train/trainer.h"
#include "utils/file_utils.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/general.h"
#include "utils/gtl_utils.h"
#include "utils/math/math_utils.h"
#include "utils/string_utils.h"


// Input Files
DECLARE_string(input_dir);
DEFINE_string(training_data_file, "", "Training Data Set File");
DEFINE_string(validation_data_file, "", "Validation Data Set File");
DEFINE_string(test_data_file, "", "Test data files, comma separated");
DEFINE_string(predicates_file, "", "Predicates Definition File");
DEFINE_string(training_examples_file, "", "Training examples file");
DEFINE_string(validation_examples_file, "", "Validation Examples Set File");
DEFINE_string(test_examples_file, "", "Test examples files, comma separated");
DEFINE_string(rules_file, "", "FOL Rules Definition Files, comma separated");

// Train mode.
DEFINE_bool(transductive, false, "Transductive learning, all data available during training. "
                                 "Do not provide validation and test data.");
DEFINE_bool(collective_classification, false, "Collective classification: can use a initial classifier as priors.");
DEFINE_string(input_classifier_file, "",
              "Full path of where the input classifier is stored. "
              "If provided it will be used as initial classifier for train or classification. "
              "For collective classification, it will be used to provide the priors.");

// Parameters for cross-validation
DEFINE_string(lambda_labeled_values, "1", "Lambda value for the labeled part. "
        "This will overwrite the --lambda_labeled flag");
DEFINE_string(lambda_regularization_values, "1", "Lambda value for the regularization part. "
        "This will overwrite the --lambda_regularization flag");
DEFINE_string(lambda_constraint_values, "1", "Lambda value for the constraints part. "
        "This will overwrite the --lambda_constraint flag");

// Optimization
DEFINE_uint64(active_threads, 1, "OpenMP multi threading optimization: number of active threads inside a parallel region");

// Other application specific data loader.
DEFINE_bool(build_empirical_kernel_maps, false, "Build features from kernel maps.");
DEFINE_double(empirical_kernel_map_portion, 0.5,
              "Portion of patterns in the training set used for the empirical kernel map.");
DEFINE_string(empirical_kernel_map_portion_by_domain, "",
              "Comma separated list of domain:portion of patterns in the training "
              "set used for the empirical kernel map. When a domain is not specified "
              "the default FLAGS_empirical_kernel_map_portion will be used.");

// Input Files
DEFINE_string(input_dir, ".", "Directory of input files");

// Output Files.
DEFINE_string(output_model_file, "model.dat", "Filename where the classifier meta-params are stored.");
DEFINE_string(output_classifier_file, "classifier.dat", "Filename where the final classifier is stored. "
              "If empty, the classifier is not saved.");
DEFINE_string(output_classifier_dir, "", "Subdirectory where the final classifier is stored. "
              "If empty, the classifier is not saved.");
DECLARE_string(output_dir);

// Test
DEFINE_bool(run_eval_on_training_set, true, "Executes classification on Training Set at the end of training.");
DEFINE_string(test_type, "MULTIPREDICATE", "Classification test type: ARGMAX, MULTIPREDICATE or MULTIPREDICATEWITHARGMAX");
DECLARE_double(classification_threshold);

using namespace std;

namespace Regularization {
namespace TrainRunnerHelper {

Data::Data() : validation_data(NULL), test_data(NULL) { }
Data::~Data() {
    if (validation_data != NULL && validation_data != &training_data) {
        delete validation_data;
    }
    if (test_data != NULL && test_data != &training_data) {
        delete test_data;
    }
}

void LoadPredicatesOrDie(Data* data) {
    if (FLAGS_predicates_file.empty()) {
        return;
    }

    VMESSAGE(1, "Reading predicates from " << FLAGS_predicates_file);
    CHECK(!FLAGS_predicates_file.empty());
    vector<string> predicate_files;
    StringUtils::SplitToVector(FLAGS_predicates_file, &predicate_files, ',', true);
    data->predicates.LoadFromFile(FLAGS_input_dir + "/" + predicate_files[0], NULL, true);
    for (unsigned int f = 1; f < predicate_files.size(); ++f) {
        CHECK(data->predicates.LoadFromFile(FLAGS_input_dir + "/" + predicate_files[f],
                NULL, false));
    }
    VMESSAGE(1, "Predicates Info:\nNumber of predicates: " << data->predicates.Size() <<
            endl << data->predicates.ToString());
}

namespace {
// Utility function to load the examples in examples
void LoadExamples(const string& examples_files,
                  const Dataset& data, const Predicates& predicates,
                  Examples* examples) {
    if (examples_files.empty())  return;

    vector<string> files;
    StringUtils::SplitToVector(examples_files, &files, ',', true);
    VMESSAGE(1, "Reading examples from " << files[0]);
    CHECK(examples->LoadFromFile(
            FLAGS_input_dir + "/" + files[0], data, predicates, true));
    for (unsigned int f = 1; f < files.size(); ++f) {
        VMESSAGE(1, "Reading examples from " << files[f]);
        CHECK(examples->LoadFromFile(
                FLAGS_input_dir + "/" + files[f], data, predicates, false));
    }
}
}  // end namespace


void LoadTrainingDataOrDie(Data* data) {
    if (FLAGS_training_data_file.empty()) {
        return;
    }
    vector<string> files;
    StringUtils::SplitToVector(FLAGS_training_data_file, &files, ',', true);

    VMESSAGE(1, "Reading training data from " << files[0]);
    CHECK(data->training_data.LoadFromFile(FLAGS_input_dir + "/" + files[0]));
    for (unsigned int i = 1; i < files.size(); ++i) {
        Dataset dataset;
        VMESSAGE(1, "Reading training data from " << files[i]);
        CHECK(dataset.LoadFromFile(FLAGS_input_dir + "/" + files[i]));
        DatasetUtils::AddTo(dataset, &(data->training_data));
    }

    VMESSAGE(1, "Reading training examples from " << FLAGS_training_examples_file);
    LoadExamples(FLAGS_training_examples_file, data->training_data, data->predicates,
                 &data->training_examples);

    // Add the domain specific datasets, this will build datasets for n-ary predicates.
    data->training_data.BuildDomainDataset(data->predicates, data->training_examples);

    if (FLAGS_build_empirical_kernel_maps) {
        CHECK(FLAGS_transductive);
        EmpiricalKernelMap::Build(
                FLAGS_empirical_kernel_map_portion,
                FLAGS_empirical_kernel_map_portion_by_domain,
                data->options, &data->training_data);
    }
}

void LoadFOLKnowledgeOrDie(Data* data) {
    if (FLAGS_rules_file.empty()) {
        return;
    }
    VMESSAGE(1, "Reading rule files " << FLAGS_rules_file);
    vector<string> files;
    StringUtils::SplitToVector(FLAGS_rules_file, &files, ',', true);
    for (unsigned int f = 0; f < files.size(); ++f) {
        CHECK(data->FOL_KnowledgeBase.LoadKnowledgeBase(FLAGS_input_dir + "/" + files[f],
                data->training_data, data->predicates, f == 0 /* do not clear for f > 0*/ ));
    }

    VMESSAGE(1, "FOL KnowledgeBase Info:\nNumber of rules: " <<
            data->FOL_KnowledgeBase.Size() << endl << data->FOL_KnowledgeBase.ToString());
}

void LoadValidationDataOrDie(Data* data) {
    /******************************************
     * LOAD VALIDATION DATASET - IF PRESENT
     ******************************************/
    if (FLAGS_transductive) {
        CHECK_WITH_MESSAGE(FLAGS_validation_data_file.empty(),
                "No extra validation data should be provided in transductive mode");
        if (!FLAGS_validation_examples_file.empty()) {
            data->validation_data = &data->training_data;

            data->validation_examples.Reset(new Examples());
            VMESSAGE(1, "Reading validation examples from " <<  FLAGS_validation_examples_file);
            LoadExamples(FLAGS_validation_examples_file, *data->validation_data, data->predicates,
                         data->validation_examples.Get());

            if (data->options.GetCrossValidationIterations() > 0) {
                data->options.SetCrossValidation(data->validation_data,
                        data->validation_examples.Get());
            }
        }
    } else if (!FLAGS_validation_data_file.empty() && !FLAGS_validation_examples_file.empty()) {
        VMESSAGE(1, "Reading validation data from " << FLAGS_validation_data_file);
        data->validation_data = new Dataset(FLAGS_input_dir + "/" + FLAGS_validation_data_file);

        data->validation_examples.Reset(new Examples());
        VMESSAGE(1, "Reading validation examples from " <<  FLAGS_validation_examples_file);
        LoadExamples(FLAGS_validation_examples_file, *data->validation_data, data->predicates,
                     data->validation_examples.Get());

        data->validation_data->BuildDomainDataset(data->predicates, *data->validation_examples);

        if (data->options.GetCrossValidationIterations() > 0) {
            data->options.SetCrossValidation(data->validation_data,
                    data->validation_examples.Get());
        }
    }
}

void LoadTestDataOrDie(Data* data) {
    /******************************************
     * LOAD TEST DATASET - IF PRESENT
     ******************************************/
    if (FLAGS_transductive) {
        CHECK_WITH_MESSAGE(FLAGS_test_data_file.empty(),
                "No extra test data should be provided in transductive mode");
        if (!FLAGS_test_examples_file.empty()) {
            data->test_data = &data->training_data;

            data->test_examples.Reset(new Examples());
            VMESSAGE(1, "Reading test examples from " <<  FLAGS_test_examples_file);
            LoadExamples(FLAGS_test_examples_file, *data->test_data, data->predicates,
                         data->test_examples.Get());
        }
    } else if (!FLAGS_test_data_file.empty() && !FLAGS_test_examples_file.empty()) {
        vector<string> data_files;
        StringUtils::SplitToVector(FLAGS_test_data_file, &data_files, ",", true);
        CHECK(!data_files.empty());
        VMESSAGE(1, "Reading test data from " << data_files[0]);
        CHECK(data->test_data = new Dataset(FLAGS_input_dir + "/" + data_files[0]));
        for (unsigned int i = 1; i < data_files.size(); ++i) {
            VMESSAGE(1, "Reading test data from " << data_files[i]);
            Dataset new_data(FLAGS_input_dir + "/" + data_files[i]);
            CHECK(DatasetUtils::AddTo(new_data, data->test_data));
        }

        data->test_examples.Reset(new Examples());
        VMESSAGE(1, "Reading test examples from " << FLAGS_test_examples_file);
        LoadExamples(FLAGS_test_examples_file, *data->test_data, data->predicates,
                     data->test_examples.Get());

        data->test_data->BuildDomainDataset(data->predicates, *data->test_examples);
    }
}

void LoadData(Data* data) {
    /***************************************************************************
     * LOAD INPUT FILES
     **************************************************************************/
    VMESSAGE(0, "Reading input data");
    LoadPredicatesOrDie(data);
    LoadTrainingDataOrDie(data);
    LoadFOLKnowledgeOrDie(data);
    LoadValidationDataOrDie(data);
    LoadTestDataOrDie(data);
}

void GetCrossvalidationParams(const Data& data,
        vector<Value>* lambdas_labeled,
        vector<Value>* lambdas_regularization,
        vector<Value>* lambdas_constraint) {
    /**********************************************
     * SPLIT RANGE PARAMETERS for MODEL-SELECTION
     **********************************************/
    StringUtils::SplitToVectorByType(
            FLAGS_lambda_labeled_values, lambdas_labeled, ",", 0);
    StringUtils::SplitToVectorByType(
            FLAGS_lambda_regularization_values, lambdas_regularization, ",", 0);
    StringUtils::SplitToVectorByType(
            FLAGS_lambda_constraint_values, lambdas_constraint, ",", 0);
    if (lambdas_labeled->size() > 1 || lambdas_regularization->size() > 1 ||
        lambdas_constraint->size() > 1) {
        // Multiple train configurations, this must be done to select the best
        // model on a validation set:
        CHECK_NE_NULL_WITH_MESSAGE(data.validation_data,
                "Specify a validation set when running over multiple train configurations.");
        CHECK_GT_WITH_MESSAGE(static_cast<int>(data.validation_examples->Size()), 0,
                "Specify a non-empty validation set when running over multiple train configurations.");

    }
}

namespace {
struct BestModelInfo {
    std::string model_name;
    TestUtils::Stats metric2result;
};

// Runtime setup of the openmp parallelization.
// No-op if parallelization is not enabled at compile time.
void MaybeSetUpOmp() {
#if __ACTIVATE_OPENMP_TRAINER__ > 0 || __ACTIVATE_OPENMP_FUNCTIONS__ > 0 || __ACTIVATE_OPENMP_CLASSIFIER__ > 0
    omp_set_num_threads(FLAGS_active_threads);
    omp_set_nested(false);
#endif
}
}  // end namespace

// Returns the best classifier.
BaseClassifier* RunTrain(const Data& data, std::string *output_summary, TrainOptions* best_options) {
    // To be sure that the input is not overwritten.
    CHECK_NE_WITH_MESSAGE(FLAGS_output_dir, FLAGS_input_dir,
            "Input and output directories are the same: " + FLAGS_input_dir);

    // Maybe setup of the parallelization.
    MaybeSetUpOmp();

    // parameters for model selection.
    std::vector<Value> lambdas_labeled;
    std::vector<Value> lambdas_regularization;
    std::vector<Value> lambdas_constraint;
    GetCrossvalidationParams(
            data, &lambdas_labeled, &lambdas_regularization, &lambdas_constraint);

    // Map of best results in model-selection
    // stats metric -> result
    BestModelInfo best_model_info;

    const std::string output_base_dir = data.options.GetOutputDir();

    // Select test type
    const TestUtils::TestType testType = TestUtils::TestTypeFromString(FLAGS_test_type);

    ScopedPtr<Classifier> input_classifier(NULL);
    if (!FLAGS_input_classifier_file.empty()) {
        VMESSAGE(0, "Reading classifier from " << FLAGS_input_classifier_file);
        input_classifier.Reset(new Classifier(FLAGS_input_classifier_file,
                                              data.predicates,
                                              data.training_data,
                                              data.training_examples,
                                              data.options));
        VMESSAGE(0, "Finished reading classifier");
    }

    if (data.options.GetMaxIterations() <= 0 || lambdas_labeled.empty() ||
        lambdas_regularization.empty() || lambdas_constraint.empty()) {
        // No train to perform.
        VMESSAGE(0, "No train! Returning the input classifier if available.");
        best_options->Copy(data.options);
        best_options->SetModelOptions(
               (lambdas_labeled.empty() ? 1.0 : lambdas_labeled[0]),
               (lambdas_regularization.empty() ? 1.0f : lambdas_regularization[0]),
               (lambdas_constraint.empty() ? 1.0f : lambdas_constraint[0]),
               "");
        return (input_classifier.Get() == NULL ? NULL : input_classifier.Release());
    }

    ScopedPtr<BaseClassifier> best_classifier(NULL);
    TestUtils::Stats best_classifier_test_stats;

    // counter of model configurations
    int counter = 0;
    for (unsigned int i = 0; i < lambdas_labeled.size(); ++i) {
        for (unsigned int j = 0; j < lambdas_regularization.size(); ++j) {
            for (unsigned int z = 0; z < lambdas_constraint.size(); ++z) {
                // in case of error, this check permits to skip the
                // configurations of the grid already tested
                counter++;

                /**************************************************************************
                 * SETUP
                 **************************************************************************/
                 // settings for this configuration
                const std::string exp_output_dir = output_base_dir +
                        "/ll" + StringUtils::ToString(lambdas_labeled[i]) +
                        "-lr" + StringUtils::ToString(lambdas_regularization[j]) +
                        "-lc" + StringUtils::ToString(lambdas_constraint[z]);
                FileUtils::MakePathOrDie(exp_output_dir);

                TrainOptions options;
                options.Copy(data.options);
                options.SetModelOptions(
                        lambdas_labeled[i], lambdas_regularization[j], lambdas_constraint[z],
                        exp_output_dir);

                VMESSAGE(0,
                        "\n##########################################################################\n" <<
                        "Lambda_labeled = " << lambdas_labeled[i] <<
                        "\tLambda_regularization = " << lambdas_regularization[j] <<
                        "\tLambda_constraint = " << lambdas_constraint[z] <<
                        "\tOutput Directory: " << exp_output_dir <<
                        "\n##########################################################################");

                VMESSAGE(0, "Building the Classifier");
                BaseClassifier* classifier = NULL;
                if (FLAGS_collective_classification) {
                    classifier = new CollectiveClassifier(
                            input_classifier.Get(),
                            data.predicates,
                            data.FOL_KnowledgeBase,
                            *(data.test_data),
                            (data.training_examples.Size() > 0 ?
                             &data.training_examples : NULL));
                } else {
                    if (input_classifier.Get() == NULL) {
                        classifier = new Classifier(data.predicates,
                                                    data.training_data,
                                                    data.training_examples,
                                                    options);
                    } else {
                        classifier = new Classifier(*input_classifier);
                    }
                }
                VMESSAGE(1, "End building the Classifier");
                /**************************************************************************
                 * END SETUP
                 **************************************************************************/

                /**************************************************************************
                 * TRAINING
                 **************************************************************************/
                if (options.GetMaxIterations() > 0) {
                    // Build the trainer
                    VMESSAGE(0, "Building the trainer");
                    Trainer trainer(
                            classifier, data.predicates, data.FOL_KnowledgeBase, options,
                            &data.training_data, &data.training_examples);
                    VMESSAGE(1, "End building the trainer");

                    // Start training
                    VMESSAGE(0, "Start the training phase");
                    trainer.Train();
                    VMESSAGE(1, "End of the training phase");
                }
                /**********************************************************
                 * END TRAINING
                 **********************************************************/

                /**********************************************************
                 * TEST
                 **********************************************************/
                std::ostringstream model_name_os;
                model_name_os << "# model ll" << lambdas_labeled[i] <<"-lr" << lambdas_regularization[j] <<
                        "-lc" << lambdas_constraint[z];
                const std::string& model_name = model_name_os.str();
                const std::string results_dir = exp_output_dir + "/results/";

                if (FLAGS_run_eval_on_training_set && data.training_data.Size() > 0) {
                    VMESSAGE(0, "Start test on training set. Results in " << results_dir + "train_results.dat");
                    TestUtils::Stats training_stats;
                    TestUtils::PrintTest(*classifier, data.training_data,
                            results_dir + "train_results.dat",
                            results_dir + "train_summary_th" +
                            StringUtils::ToString(FLAGS_classification_threshold) + ".dat",
                            results_dir + "train_roc_curve.dat",
                            results_dir + "train_pr_curve.dat",
                            options, model_name, testType,
                            &data.training_examples, output_summary, &training_stats);
                    VMESSAGE(1, "End test on training set.");
                }

                TestUtils::Stats test_stats;
                if (data.test_data != NULL && data.test_examples.Get() !=  NULL) {
                    VMESSAGE(0, "Start test on test set. Results in " << results_dir + "test_results.dat");
                    TestUtils::PrintTest(*classifier, *data.test_data,
                            results_dir + "test_results.dat",
                            results_dir + "test_summary_th" +
                            StringUtils::ToString(FLAGS_classification_threshold) + ".dat",
                            results_dir + "test_roc_curve.dat",
                            results_dir + "test_pr_curve.dat",
                            options, model_name, testType,
                            data.test_examples.Get(), output_summary, &test_stats);
                    VMESSAGE(1, "End test on test set.");
                }

                if (data.validation_data != NULL) {
                    VMESSAGE(0, "Start test on validation set. Results in " << results_dir +
                             "validation_results.dat");
                    TestUtils::Stats val_stats;
                    TestUtils::PrintTest(*classifier, *data.validation_data,
                            results_dir + "validation_results.dat",
                            results_dir + "validation_summary_th" +
                            StringUtils::ToString(FLAGS_classification_threshold) + ".dat",
                            results_dir + "validation_roc_curve.dat",
                            results_dir + "validation_pr_curve.dat",
                            options, model_name, testType,
                            data.validation_examples.Get(), output_summary, &val_stats);
                    VMESSAGE(1, "End test on validation set.");

                    // compare and select the best model
                    const std::string& metric = options.GetMetric();
                    if (best_classifier.Get() == NULL ||
                        best_model_info.metric2result.size() == 0 ||
                        best_model_info.metric2result[metric] < val_stats[metric] ||
                        (best_model_info.metric2result[metric] == val_stats[metric] &&
                         best_model_info.metric2result["Precision"] < val_stats["Precision"])) {
                        std::ostringstream modelname;
                        modelname << "ll" << lambdas_labeled[i] <<"-lr" << lambdas_regularization[j] <<
                                "-lc" << lambdas_constraint[z];
                        best_model_info.model_name = modelname.str();
                        best_model_info.metric2result = val_stats;
                        VMESSAGE(2, "New best classifier for configuration " << best_model_info.model_name);
                        best_classifier.Reset(classifier);
                        best_options->Copy(options);
                        best_classifier_test_stats = test_stats;
                    } else {
                        delete classifier;
                    }
                } else {
                    // No Validation, last classifier is kept as best. This
                    // happens only if a single train configuration is allowed.
                    best_classifier.Reset(classifier);
                }
                /**********************************************************
                 * END TEST
                 **********************************************************/
            }  // for in lambda_constraint
        }      // for in lambda_regularization
    }          // for in lambda_labeled

    /*******************************************
     * PRINT RESULTS OF MODEL SELECTION
     *******************************************/
    if (data.validation_data != NULL) {
        *output_summary += StringUtils::StrCat("# best model ", best_model_info.model_name, "\n");
        VPRINTLN(1, "***************************************************");
        VMESSAGE(0, "\tBest Results on validation set (" << data.options.UseMicroStatistics() << ")");
        const std::string val_stats_string = StringUtils::MapToString(
                best_model_info.metric2result, " ", " ", "\n");
        VPRINT(0, val_stats_string);
        *output_summary += val_stats_string;
        VPRINTLN(0, "model:" << best_model_info.model_name);
        VPRINTLN(1, "***************************************************");
        if (!best_classifier_test_stats.empty()) {
            VPRINTLN(1, "***************************************************");
            VMESSAGE(0, "\tResults on test (selected by cross-validation) (" << data.options.UseMicroStatistics() <<")");
            const std::string test_stats_string = StringUtils::MapToString(best_classifier_test_stats, " ", " ", "\n");
            VPRINT(0, test_stats_string);
            *output_summary += test_stats_string;
            VPRINTLN(0, "model:" << best_model_info.model_name);
            VPRINTLN(1, "***************************************************");
        }
    }

    // Directory of the best model in model selection
    best_options->Save(output_base_dir + "/" + FLAGS_output_model_file);
    CHECK_NE_NULL(best_classifier.Get());
    if (!FLAGS_output_classifier_file.empty()) {
        const std::string best_classifier_filename =
                output_base_dir + "/" + FLAGS_output_classifier_file;
        VMESSAGE(0, "Saving best classifier in " << best_classifier_filename);
        CHECK(best_classifier->SaveToFile(best_classifier_filename));
        VMESSAGE(1, "End saving best classifier");
    }
    if (!FLAGS_output_classifier_dir.empty()) {
        const std::string best_classifier_dirname =
                output_base_dir + "/" + FLAGS_output_classifier_dir;
        VMESSAGE(0, "Saving best classifier in directory " << best_classifier_dirname);
        CHECK(best_classifier->SaveToDir(best_classifier_dirname));
        VMESSAGE(1, "End saving best classifier");
    }
    return best_classifier.Release();
}

void RunConstraintVerification(
        const Data& data, const TrainOptions& options, const BaseClassifier* classifier) {
    bool has_constraints_to_verify = false;
    for (int i = 0; i < data.FOL_KnowledgeBase.Size(); i++) {
        if (data.FOL_KnowledgeBase.Get(i).GetRuleType() == FOLFormula::VERIFY) {
            has_constraints_to_verify = true;
            break;
        }
    }

    if (has_constraints_to_verify) {
        TestUtils::ConstraintsValue values;
        Trainer::ConstraintsSet verify_constraint_set;
        ConstraintsFactory::BuildConstraints(
                classifier, data.FOL_KnowledgeBase, data.predicates,
                data.training_data, data.training_examples,
                FOLFormula::VERIFY, options.GetConstraintsLossFunction(),
                &verify_constraint_set);
        TestUtils::VerifyConstraints(verify_constraint_set, NULL);
    }
}

void RunCollectiveClassificationAfterTrain(const Data& data, const TrainOptions& best_options,
        const BaseClassifier* best_classifier, std::string* output_summary) {
    VMESSAGE(1, "Start Collective Classification");

    CHECK(FLAGS_transductive);
    CHECK_NE_NULL(best_classifier);

    const TestUtils::TestType testType = TestUtils::TestTypeFromString(FLAGS_test_type);

    *output_summary += "# collective classification";

    // TODO(michi): deal with model selection in cc.
    TrainOptions cc_train_options;
    cc_train_options.Copy(best_options);

    // Adjust the cc options.
    cc_train_options.SetIterations(
            0, (cc_train_options.GetSecondPassMaxIterations() > 0 ?
                cc_train_options.GetSecondPassMaxIterations() :
                cc_train_options.GetMaxIterations()));
    cc_train_options.SetLearningRate(
            cc_train_options.GetSecondPassLearningRate() > 0 ?
                    cc_train_options.GetSecondPassLearningRate() :
                    cc_train_options.GetLearningRate());

    const std::string output_base_dir = data.options.GetOutputDir();
    const std::string exp_output_dir = output_base_dir + "/cc" +
            "/ll" + StringUtils::ToString(cc_train_options.GetLambdaLabeled()) +
            "-lr" + StringUtils::ToString(cc_train_options.GetLambdaRegularization()) +
            "-lc" + StringUtils::ToString(cc_train_options.GetSecondPassLambdaConstraints());
    FileUtils::MakePathOrDie(exp_output_dir);

    cc_train_options.SetModelOptions(cc_train_options.GetLambdaLabeled(),
            cc_train_options.GetLambdaRegularization(),
            cc_train_options.GetSecondPassLambdaConstraints(),
            exp_output_dir);

    // Build the classifier.
    ScopedPtr<CollectiveClassifier> cc_classifier(
            new CollectiveClassifier(
                    best_classifier,
                    data.predicates, data.FOL_KnowledgeBase, data.training_data,
                    &data.training_examples));

    const std::string results_dir = exp_output_dir + "/results";

    // Build the trainer
    Trainer cctrainer(
            cc_classifier.Get(), data.predicates, data.FOL_KnowledgeBase, cc_train_options,
            &data.training_data, &data.training_examples);
    // start the training
    cctrainer.Train();

    // Collect the results.
    BaseClassifier::ResultsSet results;
    cc_classifier->Classify(data.training_data, &results);

    VMESSAGE(1, "Collective Classification results saved to " <<
             results_dir + "/train_results.dat");
    CHECK(TestUtils::PrintResults(results, &data.training_examples,
                                  results_dir + "/train_results.dat"));

    if (data.test_examples.Get() != NULL) {
        const std::string model_name = StringUtils::StrCat(
                "ll", cc_train_options.GetLambdaLabeled(),
                "-lr", cc_train_options.GetLambdaRegularization(),
                "-lc", cc_train_options.GetLambdaConstraints());

        VMESSAGE(1, "Start Collective Classification test on test set.");
        TestUtils::Stats test_stats;
        TestUtils::PrintTest(
                StringUtils::StrCat(results_dir, "/test_results.dat"),
                StringUtils::StrCat(results_dir, "/test_summary_th",
                                    FLAGS_classification_threshold, ".dat"),
                StringUtils::StrCat(results_dir, "/test_roc_curve.dat"),
                StringUtils::StrCat(results_dir, "/test_pr_curve.dat"),
                results, cc_train_options, model_name, testType,
                data.test_examples.Get(), output_summary,
                &test_stats);
    }
}

}  // end TrainRunnerHelper

}  // end Regularization
