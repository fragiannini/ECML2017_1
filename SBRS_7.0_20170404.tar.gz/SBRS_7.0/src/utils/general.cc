/*
 * general.cc
 *
 *  Created on: May 6, 2009
 *      Author: michi
 */

#include "utils/general.h"

#include <cstdlib>
#include <fstream>
#include <pthread.h>
#include "utils/gflags/gflags/gflags.h"
#include "utils/system.h"  // for GetStackTrace()


DEFINE_bool(logtostdout, true, "Logging on stdout.");
DEFINE_bool(logtostderr, false, "Logging on stderr.");
DEFINE_string(logtofile, "", "If not empty, logging to this file. ");
// Verbosity
DEFINE_int32(verbose, 1, "Verbose level, -1 keeps the default");

namespace Logging {
static pthread_mutex_t mutex_logging = PTHREAD_MUTEX_INITIALIZER;

namespace {
static std::ofstream of;
bool populated_log_streams = false;

inline void __PopulateLogStreams() {
    if (populated_log_streams)  return;

    // Before the call to CHECK below to avoid recursive calls to this function.
    populated_log_streams = true;

    if (!FLAGS_logtofile.empty()) {
        of.open(FLAGS_logtofile.c_str());
        CHECK(of.good());
    }
}

inline void __CloseLogStreams() {
    if (!FLAGS_logtofile.empty()) {
        of.close();
    }
}
}  // end unamed namespace

void ResetLogStreams() {
    pthread_mutex_lock(&mutex_logging);
    // Before the call to CHECK below to avoid recursive calls to this function.
    populated_log_streams = false;
    __CloseLogStreams();
    __PopulateLogStreams();
    pthread_mutex_unlock(&mutex_logging);
}

void __PrintToLogStreams(const std::string& s) {
    pthread_mutex_lock(&mutex_logging);
    __PopulateLogStreams();

    if (FLAGS_logtostdout)
        std::cout << s << std::flush;
    if (FLAGS_logtostderr)
        std::cerr << s << std::flush;
    if (of.good())
        of << s << std::flush;
    pthread_mutex_unlock(&mutex_logging);
}

}  // end namespace Logging

void Exit(const int error_num)
{
    Logging::__PrintToLogStreams(SystemUtils::GetStackTrace());
    Logging::__CloseLogStreams();
    exit(error_num);
}

int GetVerboseLevel()
{
    return FLAGS_verbose;
}

