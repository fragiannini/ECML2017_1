/*
 * utils/general.h
 *
 *  Created on: May 6, 2009
 *      Author: michi
 */

#ifndef GENERAL_H
#define GENERAL_H

#include <ctime>
#include <iostream>
#include <sstream>
#include <string>


/* DECLARE_int32(verbose); */

// do not move it to system.h to avoid circular dependencies.
void Exit(const int error_num = 1);

// The default verbose/debug level.
int GetVerboseLevel();  // { return FLAGS_verbose; }

/* #define __DEBUG__LEVEL__ 0
inline int GetDebugLevel() {
    return __DEBUG__LEVEL__;
} */

namespace Logging {
// Please do not call this directly. Use the logging macros below.
// TODO(michi): this is visible in the header because called by the logging and checks.
//              Fix this.
void __PrintToLogStreams(const std::string& s);

// Reset the logging streams. This should not called directly.
// Only exception is when programmatically changing the file logging location,
// which needs to re-initalize the file stream.
void ResetLogStreams();
}  // end namespace Logging

// Fatal error, abort.
// ******************************************************************* //
// Template versions, these would be better because of strong type checking.
// The only issue with them is that the __FILE__ and __LINE__ variables will
// refer to the function code and not the caller as needed to easyly debug the
// error. So, we stick to the old MACRO based version.

template<typename T>
inline void __CHECK(const T& s, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (!s) {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << std::string(": ") << s << std::string(" ")
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str()) ;
        Exit();
    }
}

template<typename T>
inline void __CHECK_GT(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a <= b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a>b which is " << a << ">" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_LT(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a >= b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a<b which is " << a << "<" << b
           << " does not hold" << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_GE(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a < b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a>=b which is " << a << ">=" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_LE(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a > b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a<=b which is " << a << "<=" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_EQ(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a != b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a==b which is " << a << "==" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_NE(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a == b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a!=b which is " << a << "!=" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_NE_NULL(const T& a, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a == NULL)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a!=NULL which is does not hold as a is == NULL. "
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_EQ_NULL(const T& a, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a != NULL)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a==NULL which is does not hold as a is != NULL. "
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_IN_RANGE(const T& a, const T& b, const T& c, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a <= b || a >= c)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " b < a < c which is " << b << "<" << a << "<" << c
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_INE_RANGE(const T& a, const T& b, const T& c, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a < b || a > c)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " b <= a <= c which is " << b << "<=" << a << "<=" << c
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

// The internal functions are called via a macro to allow accessing to the
// file, function and line number. Switch to those as soon as the type errors
// have been fixed.
#define CHECK(s) { __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_EQ(a,b) { __CHECK_EQ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_NE(a,b) { __CHECK_NE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_NE_NULL(a) { __CHECK_NE_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_EQ_NULL(a) { __CHECK_EQ_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_GT(a,b) { __CHECK_GT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_LT(a,b) { __CHECK_LT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_GE(a,b) { __CHECK_GE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_LE(a,b) { __CHECK_LE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_IN_RANGE(a,b,c) { __CHECK_IN_RANGE((a), (b), (c), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define CHECK_INE_RANGE(a,b,c) { __CHECK_INE_RANGE((a), (b), (c), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_WITH_MESSAGE(s, p) { __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_EQ_WITH_MESSAGE(a,b,p) { __CHECK_EQ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_NE_WITH_MESSAGE(a,b,p) { __CHECK_NE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_GT_WITH_MESSAGE(a,b,p) { __CHECK_GT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_LT_WITH_MESSAGE(a,b,p) { __CHECK_LT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_GE_WITH_MESSAGE(a,b,p) { __CHECK_GE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_LE_WITH_MESSAGE(a,b,p) { __CHECK_LE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define CHECK_NE_NULL_WITH_MESSAGE(a,p) { __CHECK_NE_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }


// ******************************************************************* //
// Fatal error, abort.
// ******************************************************************* //
#define FAULT(s) { std::ostringstream os;                         \
  os << "Error: in function "                                     \
     << __PRETTY_FUNCTION__ << ", file " << __FILE__ << " line "  \
     << __LINE__ << ": " << s << std::endl;                       \
  Logging::__PrintToLogStreams(os.str()); Exit(); }

// ******************************************************************* //
// Print a warning
// ******************************************************************* //
#define WARN(s) { std::ostringstream os;                       \
  os << "Warning: in function " << __PRETTY_FUNCTION__         \
     << ", file " << __FILE__ << " line " << __LINE__ << ": "  \
     << s << std::endl;                                        \
     Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print a message
// ******************************************************************* //
#define MESSAGE(s) { std::ostringstream os;                      \
  os << "Message at time:" << std::time(NULL)                    \
     << " in file " << __FILE__ << " line " << __LINE__ << ": "  \
     << s << std::endl;                                          \
     Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print a message if the verbose level is high enough.
// ******************************************************************* //
#define VMESSAGE(level, s) { if (level <= GetVerboseLevel()) {   \
  std::ostringstream os;                                                \
  os << "Message at time:" << std::time(NULL)                           \
     <<  " in file " << __FILE__ << " line " << __LINE__ << ": " << s   \
     << std::endl;                                                      \
     Logging::__PrintToLogStreams(os.str()); } }

// ******************************************************************* //
// Print this to the logs (no new line is inserted)
// ******************************************************************* //
#define PRINT(s) { std::ostringstream os; os << s; Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print this to the logs (a new line is inserted)
// ******************************************************************* //
#define PRINTLN(s) { std::ostringstream os; os << s << std::endl; Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print this to the logs (no new line is inserted)
// ******************************************************************* //
#define VPRINT(level, s) {  if (level <= GetVerboseLevel()) { \
  std::ostringstream os; os << s;                                    \
  Logging::__PrintToLogStreams(os.str()); } }

#define VPRINTLN(level, s) {  if (level <= GetVerboseLevel()) { \
  std::ostringstream os; os << s << std::endl;                         \
  Logging::__PrintToLogStreams(os.str()); } }

#define DPRINT(level, s) {  if (level <= GetDefaultDebugLevel()) { \
  std::ostringstream os; os << s;                                  \
  Logging::__PrintToLogStreams(os.str()); } }

#define DPRINTLN(level, s) {  if (level <= GetDefaultDebugLevel()) { \
  std::ostringstream os; os << s << std::endl;                       \
  Logging::__PrintToLogStreams(os.str());}

#endif /* GENERAL_H */
