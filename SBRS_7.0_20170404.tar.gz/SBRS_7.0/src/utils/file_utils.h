/*
 * file_utils.h
 *
 *  Created on: Aug 15, 2015
 *      Author: michi
 */

#ifndef FILE_UTILS_H_
#define FILE_UTILS_H_

#include <string>

namespace FileUtils {
std::string DirName(const std::string& full_path);
bool MakePath(const std::string& full_path);
void MakePathOrDie(const std::string& full_path);

// Returns true if the passed path is a directory.
bool IsPathDir(const std::string& path);
}  // end FileUtils

#endif /* FILE_UTILS_H_ */
