/*
 * system.h
 *
 *  Created on: Nov 19, 2015
 *      Author: michi
 */

#ifndef SYSTEM_H_
#define SYSTEM_H_

#include <string>


namespace SystemUtils {
std::string Cmdline(const int argc, char** argv);

// Get the stack trace.
std::string GetStackTrace();

// Computes the average Load of the system
double GetLoadAvg();
}  // end SystemUtils
#endif /* SYSTEM_H_ */
