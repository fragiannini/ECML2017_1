/*
 * parse_utils.h
 *
 *  Created on: Jan 6, 2017
 *      Author: michi
 */

#ifndef __PARSE_UTILS_HH_
#define __PARSE_UTILS_HH_

#include <string>
#include <vector>


namespace ParseUtils {

struct ParseTree {
    std::pair<int, int> root;
    std::string root_str;  // for debug
    std::vector<std::pair<int, int> > connectives;
    std::vector<std::string> connectives_str;  // for debug

    std::vector<ParseTree> subtrees;
    std::string ToString() const;
    void Print() const;
};

ParseTree GetParseTree(
        const std::string& norm_s,
        const char token_start='[', const char token_end=']',
        const bool recursive=true);
} // end namespace ParseUtils

#endif  // __PARSE_UTILS_HH_
