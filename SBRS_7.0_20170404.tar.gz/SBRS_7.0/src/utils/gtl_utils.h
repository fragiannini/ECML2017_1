
/*
 * utils.h
 *
 *  Created on: 19/nov/2015
 *      Author: michi
 */

#ifndef GTL_UTILS_H
#define GTL_UTILS_H

#include <queue>
#include <vector>
#include "utils/general.h"


template <class T>
class NonCopyable
{
    protected:
        NonCopyable()
        {
        }

        ~NonCopyable()
        {
        } // Protected non-virtual destructor

    private:
        NonCopyable(const NonCopyable&);
        T& operator=(const T&);
};

template<typename T>
class ScopedPtr : private NonCopyable<T>
{
    public:
        // Constructor assign p to p_ private variable. Now we own the object.
        // no automatic conversion will be done
        explicit ScopedPtr(T* p = NULL) : p_(p)
        {
        }

        // Destructor will delete the object.

        ~ScopedPtr()
        {
            // Delete the object being pointed by this ScopedPtr.
            if (p_)
                delete p_;
        }

        inline void Reset(T* p)
        {
            // Check that the passed pointer is not the same!
            if (p_ != p)
            {
                // Delete the pointer we are holding before assigning the new one.
                if (p_ != NULL)
                    delete p_;

                p_ = p;
            }
        }

        inline T& operator*() const
        {
            return *p_;
        }

        inline T* operator->() const
        {
            if (p_ != NULL)
                return p_;

            FAULT("De-referecing a NULL pointer");
            return NULL;
        }

        inline T* Get() const
        {
            return p_;
        }

        // Assign the pointer to the external caller.
        // Pointer is not owned anymore and nulled inside the class.
        // Warning: do not call dereferencing operators on a released scoped pointer.
        inline T* Release()
        {
            T* p = p_;
            p_ = NULL;
            return p;
        }

    private:
        T* p_;
};

template<typename T>
class ScopedArr : private NonCopyable<T>
{
    public:
        // Constructor assign p to p_ private variable. Now we own the object.

        explicit ScopedArr(T* p = NULL) : p_(p)
        {
        }

        // Destructor will delete the object.

        inline ~ScopedArr() {
            if (p_)  delete[] p_;
            p_ = NULL;
        }

        inline void Reset(T* p) {
            // Check that the passed pointer is not the same!
            if (p_ != p) {
                if (p_)  delete[] p_;
                p_ = p;
            }
        }

        inline T operator[](const int i) const
        {
            return p_[i];
        }
        inline T& operator[](const int i) {
            return p_[i];
        }

        inline T* Get() {
            return p_;
        }

        inline const T* const Get() const {
            return p_;
        }

    private:
        T* p_;
};

/*
 * Singleton Class, non-thread safe.
 */
template<class T>
class Singleton
{
    public:

        inline static T* Get() {
            if (obj != NULL) {
                return obj;
            } else {
                obj = new T;
                return obj;
            }
        }

    private:
        static T* obj;

        Singleton()
        {
        };

};

///*
// * New implementation thread-safe of Singleton.
// * This version of Singleton thread-safe ensure that only one
// * instance of the object is created but it doesn't ensure that this
// * instance could be used by two different thread simultaneously
// */
//static pthread_mutex_t mutex_level = PTHREAD_MUTEX_INITIALIZER;
//
//template<class T>
//class Singleton
//{
//    public:
//
//        static T* Get()
//        {
//            /*
//             * without external if() every time Get() is called, it locks and unlocks the mutex.
//             * Mutex lock and unlock has an overhead associated with it.
//             * Note that we do not need thread synchronization after the object
//             * has been constructed and obj has been initialized. One solution
//             * for optimization is to check obj before acquiring the lock.
//             */
//            if (!obj)
//            {
//                pthread_mutex_lock(&mutex_level);
//
//                if (!obj)
//                {
//                    obj = new T;
//                }
//
//                pthread_mutex_unlock(&mutex_level);
//            }
//
//            return obj;
//        }
//
//    private:
//        static T* obj;
//
//        Singleton()
//        {
//        };
//
//};
//
//template <class T> T* Singleton<T>::obj = NULL;

// Use TopN<T> or TopN<T, std::greater<T> > to get the n max elements.
// Use TopN<T, std::less<T> > to get the n min elements.
template<typename T, typename C=std::greater<T> >
class TopN {
private:
    typedef std::priority_queue<T, std::vector<T>, C> Queue;
    Queue pq;  // top element is the minimum
    C comparator;
    int n;

public:
    TopN(const int n_) : n(n_) {
        CHECK_GT(n, 0);
    }

    // Returns true if the element has been inserted to the topN set.
    inline bool Push(const T& el) {
        if(pq.size() < n || comparator(el, pq.top())) {
            if(pq.size() >= n) {
                pq.pop();
            }
            pq.push(el);
            return true;
        }
        return false;
    }

    inline void Clear() {
        pq.clear();
    }

    // Get the topN elements by clearing the queue.
    void Get(std::vector<T>* top) {
        top->clear();
        top->reserve(pq.size());
        while(!pq.empty()) {
            top->push_back(pq.top());
            pq.pop();
        }
    }
};
#endif  /* GTL_UTILS_H */
