/*
 * stl_utils.h
 *
 *  Created on: 13/giu/2011
 *      Author: claudio
 */

#ifndef STL_UTILS_H
#define STL_UTILS_H

#include <map>


namespace std {

template<typename V>
void DeallocVectorOfPointers(V* vec)
{
    for (typename V::iterator i = vec->begin(); i != vec->end(); ++i)
        if (*i != NULL)
        {
            delete *i;
            *i = NULL;
        }
}

template<typename M>
void DeallocMapOfPointers(M* map_)
{
    for (typename M::iterator i = map_->begin(); i != map_->end(); ++i)
        if (i->second != NULL)
        {
            delete i->second;
            i->second = NULL;
        }
}

// Handy one line container of pairs O(n) lookup. With one single copy of the value.
template <typename Container, typename K, typename V>
inline bool Find(const Container & c,
                 const K& key,
                 const V& default_value,
                 V* value) {
    typename Container::const_iterator iter = c.begin();
    for (; iter != c.end(); ++iter) {
        if (iter->first == key) {
            *value = iter->second;
            return true;
        }
    }
    return false;
}

// Handy one line map O(log n) lookup. Return by reference to possibly avoid to
// copy the value.
// NOTE: Until when the output reference is used, the map and default_value
// should not be destroyed.
template <typename K, typename V>
inline const V& Find(const std::map<K, V>& m,
                     const K& key,
                     const V& default_value) {
    typename std::map<K, V>::const_iterator iter = m.find(key);
    if (iter == m.end())  return default_value;
    return iter->second;
}

// Handy one line map lookup. With one single copy of the value.
template <typename K, typename V>
inline bool Has(const std::map<K, V>& m, const K& key) {
    typename std::map<K, V>::const_iterator iter = m.find(key);
    return (iter != m.end());
}


// Handy one line map O(log n) lookup. With one single copy of the value.
// Specialization for maps of the above container.
template <typename K, typename V>
inline bool Find(const std::map<K, V>& m,
                 const K& key,
                 const V& default_value,
                 V* value) {
    typename std::map<K, V>::const_iterator iter = m.find(key);
    if (iter == m.end()) {
        *value = default_value;
        return false;
    }
    *value = iter->second;
    return true;
}

}  // end namespace std
#endif  /* STL_UTILS_H */
