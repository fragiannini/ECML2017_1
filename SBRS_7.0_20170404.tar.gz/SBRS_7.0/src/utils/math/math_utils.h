/*
 * utils.h
 *
 *  Created on: 13/giu/2011
 *      Author: claudio
 */

#ifndef MATH_UTILS_H
#define MATH_UTILS_H

#include <sys/time.h> // linux: for timeval seed
#include <cstdlib>
#include <cmath>

#include "utils/general.h"


// It does not belong to here, but I did not see fit to add a file only because
// of this function. Move to a math.h file when we will create one.
namespace Math
{
// Reseed according to the passed value.
inline void RandSeed(const unsigned int seed)
{
    srand(seed);
}
// Reseed according to the current time using both seconds and microseconds
inline void RandSeed()
{
    /* initialize random seed: */
    timeval t1;
    gettimeofday(&t1, NULL);
    RandSeed(t1.tv_usec * t1.tv_sec);
}

template <typename T>
inline T Rand(const T min_num, const T max_num)
{
    CHECK_GE(max_num, min_num);
    const T diff = max_num - min_num;
    return min_num + diff * (static_cast<double>(rand()) / RAND_MAX);
}

template <typename T>
inline T Min(const T a, const T b)
{
    return (a <= b ? a : b);
}

template <typename T>
inline T Min(const T a, const T b, const T c)
{
    return Min(Min(a, b), c);
}

template <typename T>
inline T Min(const T a, const T b, const T c, const T d)
{
    return Min(Min(a, b, c), d);
}

template <typename T>
inline T Max(const T a, const T b)
{
    return (a >= b ? a : b);
}

template <typename T>
inline T Max(const T a, const T b, const T c)
{
    return Max(Max(a, b), c);
}

template <typename T>
inline T Max(const T a, const T b, const T c, const T d)
{
    return Max(Max(a, b, c), d);
}

template <typename T>
inline T Sign(const T a) {
    if (a > static_cast<T>(0))
        return static_cast<T>(1);

    if (a < static_cast<T>(0))
        return static_cast<T>(-1);

    return static_cast<T>(0);
}
}  // end namespace Math

#endif  /* MATH_UTILS_H */
