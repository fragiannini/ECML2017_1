/*
 * math_symmetric_matrix.h
 *
 *  Created on: May 19, 2009
 *      Author: michi
 */

#ifndef MATH_SYMMETRIC_MATRIX_H_
#define MATH_SYMMETRIC_MATRIX_H_

#include "utils/math/math_matrix.h"

namespace Math
{
// A standard symmetric Matrix. Provides all basic functionalities
// plus the implementation of basic matrix operations like transposition,
// sum, product, etc.

template < typename I = DefaultMatrixIndex, typename T = double >
class SymmetricMatrix : public BaseMatrix<I, T>
{
    private:

        I ysize; // is equal to ysize
        I size; // (ysize ^ 2) / 2 + ysize / 2 cached for speed

        // The data in the cells
        T** data;

    public:

        SymmetricMatrix() : ysize(0), size(0), data(NULL)
        {
        }

        SymmetricMatrix(const I ysize_):
            ysize(0), size(0), data(NULL)
        {
            this->Init(ysize_);
        }

        SymmetricMatrix(const SymmetricMatrix<I, T>& matrix)
        {
            this->Copy(matrix);
        }

        virtual ~SymmetricMatrix()
        {
            this->Clear();
        }

        void Copy(const SymmetricMatrix<I, T>& matrix)
        {
            this->Clear();
            I i, j;

            for (i = 0; i < ysize; ++i)
            {
                for (j = 0; j < (ysize - i); ++j)
                {
                    data[i][j] = matrix.Get(i, j);
                }
            }
        }

        virtual void Init(const I ysize_)
        {
            this->Clear();
            ysize = ysize_;
            size = (((ysize*ysize) / 2.0) + (ysize / 2.0));

            /* Index is unsigned
            if (ysize < 0)
            {
                WARN("Can not generate a matrix with a number of row " << ysize);
                return;
                } */

            if (ysize > static_cast<I>(0))
            {
                data = new T*[ysize];
                for (I i = 0; i < ysize; ++i)
                {
                    data[i] = new T[ysize - i];
                    memset(data[i], 0, sizeof (T) * (ysize - i));
                }
            }
        }

        // Initialization and reset methods.
        virtual void Clear()
        {
            if (data != NULL)
            {

                for (I i = 0; i < ysize; ++i)
                    if (data[i] != NULL)
                        delete[] data[i];

                delete[] data;
            }

            ysize = static_cast<I>(0);
            size = static_cast<I>(0);
            data = NULL;
        }

        // Creates a random matrix with values between min and max.
        virtual void Rand(T min, T max)
        {
            Math::RandSeed();

            for (I i = 0; i < ysize; ++i)
                for (I j = 0; j < (ysize - i); ++j)
                    data[i][j] = Math::Rand(min, max);
        }

        inline const I GetYSize() const
        {
            return ysize;
        }

        inline const I Size() const
        {
            return size;
        }

        inline void Set(const I i1, const I i2, T val)
        {
            CHECK_GE_WITH_MESSAGE(i2, i1, "Matrix is triangular, it can be set only on the upper triangle.");
            data[i1][i2 - i1] = val;
        }

        virtual void SetAll(const T val)
        {
            I i, j;

            for (i = 0; i < ysize; ++i)
            {
                if (val == static_cast<T> (0)) // do it fast when possible
                {
                    memset(data[i], 0, (ysize - i) * sizeof (T));
                }

                else
                {
                    for (j = 0; j < (ysize - i); ++j)
                        data[i][j] = val;
                }
            }
        }

        virtual void SetRow(const I i1, const Math::Vector<T>& row)
        {
            CHECK_EQ(static_cast<I>(row.Size()), ysize);
            for (I i = 0; i < i1; ++i)
                data[i][i1] = row.Get(i);

            for (I i = i1; i < row.Size(); ++i)
                data[i1][i] = row.Get(i);
        }

        inline T Get(const I i1, const I i2) const
        {
            if (i1 > i2)
                return data[i2][i1 - i2];

            return data[i1][i2 - i1];
        }

        inline bool Get(const I i1, const I i2, T* value) const
        {
            // Safe version of get, returns false if the indexes are not valid.
            if (i1 >= ysize || i2 >= ysize)
                return false;
            *value = this->Get(i1, i2);
            return true;
        }
        // end Inlined

        // Like Get(i) but returns a copy of the row.
        virtual const Vector<T>* GetRow(const I r) const
        {
            Vector<T>* V = new Vector<T > (ysize);
            for (I c = 0; c < r; ++c)
                V->Set(c, this->Get(c, r));

            for (I c = r; c < (ysize - r); ++c)
                V->Set(c, this->Get(r, c));

            return V;
        }

        // Like Get(i) but returns a copy of the row.

        virtual bool GetRow(const I r, Math::Vector<T>* row) const
        {
            if (row->Size() != ysize)
                row->Init(ysize);

            for (I c = 0; c < r; ++c)
                row->Set(c, data[c][r]);

            for (I c = r; c < (ysize - r); ++c)
                row->Set(c, data[r][c]);

            return true;
        }

        // Returns a copy of the column.

        virtual const Vector<T>* GetColumn(const I c) const
        {
            return this->GetRow(c);
        }

        // Add m to the matrix.
        virtual void AddInPlace(const SymmetricMatrix<I, T>& m)
        {
            CHECK_EQ(m.GetYSize(), this->GetYSize());
            for (I i = 0; i < ysize; ++i)
                for (I j = 0; j < (ysize - i); ++j)
                    data[i][j] += m.Get(i, j);
        }

        // Sub m to the matrix.
        virtual void SubInPlace(const SymmetricMatrix<I, T>& m)
        {
            CHECK_EQ(m.GetYSize(), this->GetYSize());

            for (I i = 0; i < ysize; ++i)
                for (I j = 0; j < (ysize - i); ++j)
                    data[i][j] -= m.Get(i, j);
        }

        // Multiply the current matrix by a scalar.
        // The matrix is updated in place.
        virtual void MultiplyInPlace(T val)
        {
            for (I i = 0; i < ysize; ++i)
                for (I j = 0; j < (ysize - i); ++j)
                    data[i][j] *= val;
        }

        virtual T GetMaxRowSum() const {
            T max_sum = std::numeric_limits<T>::min();
            for (I i = 0; i < ysize; ++i) {
                T sum = 0;
                for (I j = 0; j < ysize; ++j) {
                    sum += this->Get(i, j);
                }
                if (sum > max_sum)
                    max_sum = sum;
            }
            return max_sum;
        }

        // I/O
        bool Load(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str());

            if (!ifs.good())
            {
                WARN("Could not open the file " << filename);
                return false;
            }

            return this->LoadFromStream(ifs);
        }

        bool LoadBinary(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str(), std::ios::binary);

            if (!ifs.good())
            {
                WARN("Could not open the file " << filename);
                return false;
            }

            return this->LoadBinaryFromStream(ifs);
        }

        virtual bool Equals(const SymmetricMatrix<I, T>& m) const
        {
            // Sizes must match
            if (this->GetYSize() != m.GetYSize())
            {
                return false;
            }

            // All elements must match
            for (I i = 0; i < ysize; ++i)
            {
                for (I j = 0; j < (ysize - i); ++j)
                {
                    if (data[i][j] != m.Get(i, j))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        //        /** LU Decomposition
        //           @return     Structure to access L, U, vector of pivots piv and its sign.
        //           Use GetL and GetU to get the decomposition from the returned matrix.
        //         */
        //        Matrix<T>* LUDecomposition(I* piv, int* pivsign) const
        //        {
        //            // Use a "left-looking", dot-product, Crout/Doolittle algorithm.
        //            Matrix<T>* lu = new Matrix<T > (*this);
        //            I m = lu->GetYSize();
        //            I n = lu->GetXSize();
        //
        //            for (I i = 0; i < m; i++)
        //            {
        //                piv[i] = i;
        //            }
        //
        //            *pivsign = 1;
        //            T* LUcolj = new T[m];
        //            memset(LUcolj, 0, sizeof (T) * m);
        //
        //            // Outer loop.
        //            for (I j = 0; j < n; j++)
        //            {
        //                // Make a copy of the j-th column to localize references.
        //                for (I i = 0; i < m; i++)
        //                {
        //                    LUcolj[i] = lu->Get(i, j);
        //                }
        //
        //                // Apply previous transformations.
        //                for (I i = 0; i < m; i++)
        //                {
        //                    T* LUrowi = lu->GetMutable(i);
        //                    // Most of the time is spent in the following dot product.
        //                    I kmax = std::min(i, j);
        //                    double s = 0.0;
        //
        //                    for (I k = 0; k < kmax; k++)
        //                    {
        //                        s += LUrowi[k] * LUcolj[k];
        //                    }
        //
        //                    LUrowi[j] = LUcolj[i] -= s;
        //                }
        //
        //                // Find pivot and exchange if necessary.
        //                I p = j;
        //
        //                for (I i = j + 1; i < m; i++)
        //                {
        //                    if (fabs(LUcolj[i]) > fabs(LUcolj[p]))
        //                    {
        //                        p = i;
        //                    }
        //                }
        //
        //                if (p != j)
        //                {
        //                    for (I k = 0; k < n; k++)
        //                    {
        //                        double t = lu->Get(p, k);
        //                        lu->Set(p, k, lu->Get(j, k));
        //                        lu->Set(j, k, t);
        //                    }
        //
        //                    I k = piv[p];
        //                    piv[p] = piv[j];
        //                    piv[j] = k;
        //                    *pivsign = -*pivsign;
        //                }
        //
        //                // Compute multipliers.
        //                if (j < m && lu->Get(j, j) != static_cast<T> (0.0))
        //                    for (I i = j + 1; i < m; i++)
        //                        lu->Set(i, j, lu->Get(i, j) / lu->Get(j, j));
        //            }
        //
        //            delete[] LUcolj;
        //            lu->SetIsLU(true);
        //            return lu;
        //        }
        //
        //        /** Return lower triangular factor
        //           @return     L
        //         */
        //        virtual Matrix<T>* GetL() const
        //        {
        //            CHECK((this->IsLU()));
        //            Matrix<T>* lmatrix = new Matrix(this->GetYSize(), this->GetXSize());
        //
        //            for (I i = 0; i < this->GetYSize(); i++)
        //            {
        //                for (I j = 0; j < this->GetXSize(); j++)
        //                {
        //                    if (i > j)
        //                    {
        //                        lmatrix->Set(i, j, this->Get(i, j));
        //                    }
        //
        //                    else if (i == j)
        //                    {
        //                        lmatrix->Set(i, j, static_cast<T> (1.0));
        //                    }
        //
        //                    else
        //                    {
        //                        lmatrix->Set(i, j, static_cast<T> (0.0));
        //                    }
        //                }
        //            }
        //
        //            return lmatrix;
        //        }
        //
        //        /** Return upper triangular factor
        //            @return     U
        //         */
        //        virtual Matrix<T>* GetU() const
        //        {
        //            CHECK((this->IsLU()));
        //            Matrix<T>* umatrix = new Matrix<T > (this->GetXSize(), this->GetXSize());
        //
        //            for (I i = 0; i < this->GetXSize(); i++)
        //            {
        //                for (I j = 0; j < this->GetXSize(); j++)
        //                {
        //                    if (i <= j)
        //                    {
        //                        umatrix->Set(i, j, this->Get(i, j));
        //                    }
        //
        //                    else
        //                    {
        //                        umatrix->Set(i, j, static_cast<T> (0.0));
        //                    }
        //                }
        //            }
        //
        //            return umatrix;
        //        }
        //
        //        /** Get a submatrix.
        //           @param r    Array of row indices.
        //           @param i0   Initial column index
        //           @param i1   Final column index
        //           @return     A(r(:),j0:j1)
        //           Used by LU decomposition to compute the inverse
        //         */
        //        virtual Matrix<T>* SubMatrix(const I* r, I r_size,
        //                                     I j0, I j1) const
        //        {
        //            SymmetricMatrix<T>* submatrix = new Matrix(r_size, j1 - j0 + 1);
        //
        //            for (I i = 0; i < r_size; i++)
        //                for (I j = j0; j <= j1; j++)
        //                    submatrix->Set(i, j - j0, this->Get(r[i], j));
        //
        //            return submatrix;
        //        }
        //
        //        // Compute the determinant of a matrix.
        //
        //        double Determinant() const
        //        {
        //            CHECK((this->GetXSize() == this->GetYSize()));
        //            I* piv = new I[this->GetYSize()];
        //            int pivsign = 0;
        //            Math::Matrix<T>* lu = this->LUDecomposition(piv, &pivsign);
        //            double det = static_cast<double> (pivsign);
        //
        //            for (I j = 0; j < this->GetYSize(); j++)
        //                det *= lu->Get(j, j);
        //
        //            delete lu;
        //            delete[] piv;
        //            return det;
        //        }
        //
        //        // determines if the matrix is singular and therefore not invertible.
        //
        //        virtual bool IsSingular() const
        //        {
        //            CHECK((this->GetXSize() == this->GetYSize()));
        //
        //            if (!is_lu)
        //            {
        //                // Already lu, just check if the diagonal has a zero element.
        //                for (I i = 0; i < this->GetXSize(); i++)
        //                {
        //                    if (this->Get(i, i) == 0)
        //                        return true;
        //                }
        //            }
        //
        //            else
        //            {
        //                // Check the determinant.
        //                return (this->Determinant() == 0.0);
        //            }
        //
        //            return false;
        //        }
        //
        //        Matrix<T>* SolveLU(const Matrix<T>& matrix,
        //                           const I* piv, int pivsign) const
        //        {
        //            CHECK_WITH_MESSAGE((this->IsLU()),
        //                               "Can not apply SolveLU to a non LU decomposed matrix");
        //
        //            if (this->IsSingular())
        //            {
        //                WARN("Can not process singular LU matrix");
        //                return NULL;
        //            }
        //
        //            I m = this->GetYSize();
        //            I n = this->GetXSize();
        //            // Copy right hand side with pivoting
        //            I nx = matrix.GetXSize();
        //            Matrix<T>* submatrix = matrix.SubMatrix(piv, m, 0, nx - 1);
        //
        //            // Solve L*Y = B(piv,:)
        //            for (I k = 0; k < n; k++)
        //            {
        //                for (I i = k + 1; i < n; i++)
        //                {
        //                    for (I j = 0; j < nx; j++)
        //                    {
        //                        submatrix->Set(i, j,
        //                                       submatrix->Get(i, j) - submatrix->Get(k, j) *
        //                                       this->Get(i, k));
        //                    }
        //                }
        //            }
        //
        //            // Solve U*X = Y;
        //            for (I k = n - 1; k >= 0; k--)
        //            {
        //                for (I j = 0; j < nx; j++)
        //                {
        //                    submatrix->Set(k, j, submatrix->Get(k, j) / this->Get(k, k));
        //                }
        //
        //                for (I i = 0; i < k; i++)
        //                {
        //                    for (I j = 0; j < nx; j++)
        //                    {
        //                        submatrix->Set(i, j,
        //                                       submatrix->Get(i, j) - submatrix->Get(k, j) *
        //                                       this->Get(i, k));
        //                    }
        //                }
        //
        //                if (k == 0)
        //                    break; // needed because k is unsigned
        //            }
        //
        //            return submatrix;
        //        }
        //
        //        virtual Matrix<T>* Solve(const Matrix<T>& matrix) const
        //        {
        //            CHECK((this->GetYSize() == this->GetXSize()));
        //            CHECK((matrix.GetYSize() == matrix.GetXSize()));
        //            I* piv = new I[matrix.GetYSize()];
        //            int pivsign = 0;
        //            Matrix<T>* lu = LUDecomposition(piv, &pivsign);
        //            Matrix<T>* lu_solved = lu->SolveLU(matrix, piv, pivsign);
        //
        //            if (lu_solved == NULL)
        //            {
        //                WARN("Can not solve the matrix!");
        //            }
        //
        //            delete lu;
        //            delete[] piv;
        //            return lu_solved;
        //        }
        //
        //        // Computes the inverse of a matrix. Returns NULL if the matrix is singular.
        //
        //        virtual Matrix<T>* Inverse() const
        //        {
        //            CHECK_WITH_MESSAGE((this->GetYSize() == this->GetXSize()),
        //                               "Needed a square matrix to invert");
        //            Matrix<T>* identity = IdentityMatrixFactory(this->GetYSize());
        //            Matrix<T>* inverse = this->Solve(*identity);
        //            delete identity;
        //            return inverse;
        //        }

        // Load a symmetric matrix in the following format:
        // 1 2 3 4
        // 5 6 7
        // 8 9
        // 10
        // where the dense format is
        // 1 2 3 4
        // 2 5 6 7
        // 3 6 8 9
        // 4 7 9 10

        virtual bool LoadFromStream(std::istream& is)
        {
            this->Clear();
            std::string line;
            I ysize_;
            is >> ysize_;
            this->Init(ysize_);
            getline(is, line); // read the remaining portion of the line
            I num_line = 0;
            I read_elements = 0;

            while (!is.eof())
            {
                getline(is, line);

                if (line.empty())
                    continue; // skip empty lines

                std::vector<std::string> tokens;
                StringUtils::SplitToVector(line, &tokens, " ", false);

                if (static_cast<I> (tokens.size()) != (ysize_ - num_line))
                {
                    WARN("Can not process line: " << line << " expecting " <<
                         (ysize_ - num_line) << " elements. Found " << tokens.size());
                    continue;
                }

                for (I i = 0; i < (ysize_ - num_line); ++i)
                {
                    T value;
                    if (!StringUtils::ReadElement(tokens[i], &value))
                    {
                        WARN("Can not process token: " << tokens[i] << " in line " << line);
                        continue;
                    }

                    // This is a valid element, add it to the matrix.
                    this->Set(num_line, i+num_line, value);
                    ++read_elements;
                }

                ++num_line;
            }

            // Returns true if all elements have been successfully read.
            CHECK_EQ(read_elements, size);
            return (read_elements == size);
        }

        virtual bool LoadBinaryFromStream(std::istream& is)
        {
            this->Clear();
            I ysize_ = 0;
            is.read((char*)&ysize_, sizeof(ysize_));
            if (ysize_ == 0) {
                WARN("Can not load an empty matrix.");
                return false;
            }
            this->Init(ysize_);
            T value = 0;
            for (I i = 0; i < ysize; ++i) {
                for (I j = 0; j < (ysize - i); ++j) {
                    if (is.eof()) {
                        WARN("End of stream found, can not load the matrix.");
                        return false;
                    }
                    is.read((char*)&value, sizeof(value));
                    this->Set(i, j + i, value);
                }
            }
            return true;
        }

        // Save the matrix to the stream.
        virtual bool SaveToStream(std::ostream& os) const
        {
            os << ysize << std::endl;

            for (I i = 0; i < ysize; ++i)
            {
                for (I j = 0; j < ysize - i; ++j)
                {
                    if (j != ysize - 1)
                        os << data[i][j] << ' ';

                    else
                        os << data[i][j];
                }

                os << std::endl;
            }

            return true;
        }

        virtual std::string ToString() const
        {
            std::ostringstream os;
            this->SaveToStream(os);
            return os.str();
        }
}; // end SymmetricMatrix
} // end Math

#endif /* MATH_SYMMETRIC_MATRIX_H_ */
