#ifndef MATH_VECTOR_H_
#define MATH_VECTOR_H_

#include <cmath>
#include <cstring>
#include <fstream>
#include <set>
#include <vector>
#include <algorithm>
#include <utility>  // for std::swap in C++-11
#include "utils/gtl_utils.h"
#include "utils/math/math_utils.h"
#include "utils/string_utils.h"


namespace Math
{

typedef unsigned long VectorIndex;

template < typename I = int, typename T = double >
class BaseVector
{
    public:
        virtual void Clear() = 0;
        // For efficiency let's not declare those in the virtual interface,
        // so that they can be inlined. May be reconsider this is a second moment
        // if inheritance is absolutely needed.
        // virtual void Set(const I& i1, const T& val) = 0;
        // virtual const T& Get(const I& i1) const = 0;
        // virtual bool Get(const I& i1, T* value) const = 0;
        // virtual VectorIndex Size() const = 0;

        virtual ~BaseVector() { }
        virtual bool Load(const std::string& filename) = 0;
        virtual bool Save(const std::string& filename) const;
        virtual void Print() const;

    private:
        virtual bool SaveToStream(std::ostream& os) const = 0;
};

template <typename I, typename T>
bool BaseVector<I, T>::Save(const std::string& filename) const
{
    std::ofstream ofs (filename.c_str ());

    if (!ofs.is_open ())
    {
        WARN ("Could not open the file " << filename);
        return false;
    }

    return this->SaveToStream (ofs);
}

template <typename I, typename T>
void BaseVector<I, T>::Print() const
{
    this->SaveToStream (std::cout);
}

template <typename T = double>
class Vector : public BaseVector<VectorIndex, T> {
    private:
        VectorIndex size;
        std::vector<T> data;
        bool all_zero;

        // OPTIMIZATION
        // Allows to perform operation quickly seeing the vector as sparse when it has few non zero values.
        typedef std::set<VectorIndex> NonZeroIndexSet;
        std::set<VectorIndex> non_zero_indexes;
        int non_zero_indexes_count;
        bool non_zero_indexes_enabled;
#if __ACTIVATE_OPENMP_TRAINER__ > 0 || __ACTIVATE_OPENMP_FUNCTIONS__ > 0 || __ACTIVATE_OPENMP_CLASSIFIER__ > 0
        // Remove concurrent changes to the non-zero indexes.
        static const bool DEFAULT_USE_NON_ZERO_INDEXES = false;
#else
        static const bool DEFAULT_USE_NON_ZERO_INDEXES = true;
#endif
        static const int MAX_NON_ZERO_INDEX = 10;
        // Using a relative threshold would make more sense, however this needs to perform
        // one extra floating point operation at each call of UseNonZeroIndexes().
        // Check if this brings too much performance penalty.
        // static const double MAX_NON_ZERO_INDEX_PORTION = 0.05;
        static const int MIN_SIZE_FOR_NON_ZERO_INDEXES = 200;
        void InitNonZeroIndexes() {
            non_zero_indexes_count = (DEFAULT_USE_NON_ZERO_INDEXES ? 0 : -1);
            non_zero_indexes_enabled = DEFAULT_USE_NON_ZERO_INDEXES;
            non_zero_indexes.clear();
        }
        inline bool UseNonZeroIndexes() const {
            return (non_zero_indexes_enabled &&
                    non_zero_indexes_count >= 0 &&
                    non_zero_indexes_count < MAX_NON_ZERO_INDEX &&
                    // non_zero_indexes_count < MAX_NON_ZERO_INDEXES_PORTION * this->Size() &&
                    size >= MIN_SIZE_FOR_NON_ZERO_INDEXES);
        }
        inline void AddNonZeroIndex(const VectorIndex i) {
            if (!non_zero_indexes_enabled || non_zero_indexes_count < 0)  return;
            if (non_zero_indexes_count == MAX_NON_ZERO_INDEX) {
                non_zero_indexes_count = -1;  // disable
                return;
            }
            if (non_zero_indexes.find(i) == non_zero_indexes.end()) {
                non_zero_indexes.insert(i);
                ++non_zero_indexes_count;
            }
        }

        inline static bool AscendingComparison(const T& a, const T& b)
        {
            return a < b;
        }

        inline static bool  DescendingComparison(const T& a, const T& b)
        {
            return a > b;
        }

    public:
        // Constructors.
        Vector() : size (0), all_zero(false) {
            InitNonZeroIndexes();
        }

        ~Vector()
        {
            this->Clear();
        }

        Vector (VectorIndex size_) : size(0), all_zero(false)
        {
            InitNonZeroIndexes();
            Init(size_);
        }

        Vector(VectorIndex size_, const T value) : size(0), all_zero(false)
        {
            InitNonZeroIndexes();
            Init(size_);
            std::fill(data.begin(),data.end(), value);
            if (value == 0)
                all_zero = true;
        }

        Vector(const Vector<T>& vec) : size(0), all_zero(vec.all_zero) {
            this->Copy(vec);
        }

        // Construct from an std vector;
        Vector (const std::vector<T>& vec) : size(0), all_zero(false) {
            InitNonZeroIndexes();
            this->Init(vec.size());
            for (unsigned int i = 0; i < vec.size(); ++i) {
                this->Set(i, vec[i]);
            }
        }

        virtual void Copy(const Vector<T>& vec)
        {
            if (vec.Size() == static_cast<VectorIndex>(0))
            {
                this->Clear();
                return;
            }

            Init(vec.Size());
            std::copy(vec.data.begin(), vec.data.end(), data.begin());
            all_zero = vec.all_zero;
            non_zero_indexes_count = vec.non_zero_indexes_count;
            non_zero_indexes = vec.non_zero_indexes;
            non_zero_indexes_enabled = vec.non_zero_indexes_enabled;
        }

        Vector<T>& operator=(const Vector<T>& vec)
        {
            this->Copy(vec);
            return *this;
        }

        virtual void Clear()
        {
            data.clear();
            size = static_cast<VectorIndex>(0);
            all_zero = false;
            InitNonZeroIndexes();
        }

        virtual void Init(const VectorIndex size_) {
            if (this->Size() == size_) {
                if (!all_zero) {  // else already all set to zero.
                    std::fill(data.begin(), data.end(), static_cast<VectorIndex>(0));
                }
            } else {
              this->Clear();
              size = size_;
              if (size > static_cast<VectorIndex>(0)) {
                  data.resize(size);
                  std::fill(data.begin(), data.end(), static_cast<VectorIndex>(0));
              }
            }
            all_zero = true;
        }

        friend void swap(Math::Vector<T>& a, Math::Vector<T>& b) {
            using std::swap;  // bring in swap for built-in types
            swap(a.size, b.size);
            swap(a.data, b.data);
            swap(a.all_zero, b.all_zero);
            swap(a.non_zero_indexes, b.non_zero_indexes);
            swap(a.non_zero_indexes_count, b.non_zero_indexes_count);
            swap(a.non_zero_indexes_enabled, b.non_zero_indexes_enabled);
        }

        // Creates a random vector with values between min and max.
        virtual void Rand(const T min, const T max)
        {
            Math::RandSeed();
            for (VectorIndex i = 0; i < size; ++i)
                this->Set(i, Math::Rand(min, max));
            if (size > 0)
                all_zero = false;
        }

        inline void SetAll(const T val) {
            if (val == static_cast<T>(0) && all_zero)
                return;  // vector is already reset.

            std::fill(data.begin(), data.end(), val);
            if (val == static_cast<T>(0)) {
                all_zero = true;
                non_zero_indexes.clear();
                if (non_zero_indexes_enabled)
                    non_zero_indexes_count = 0;
            } else {
                all_zero = false;
                non_zero_indexes_count = -1;
            }
        }

        /*
         * Non virtual methods, aiming at speed. ATTENTION: subclassers.
         */
        inline VectorIndex Size() const
        {
            return size;
        }

        inline void SetUseNonZeroIndexes(const bool use) {
            if (all_zero && use) {
                non_zero_indexes_count = 0;
                non_zero_indexes_enabled = true;
            } else if (!all_zero && use) {
                WARN("Initialization of non zero indexes can be done only on a zero-ed vector");
            } else {
                non_zero_indexes_enabled = false;
                non_zero_indexes_count = -1;
            }
        }

        inline void Set(const VectorIndex i, const T val)
        {
            data[i] = val;
            if (val != static_cast<T>(0)) {
                if (all_zero) {
                    all_zero = false;
                }
                if (UseNonZeroIndexes()) {
                    AddNonZeroIndex(i);
                }
            }
        }

        inline void Add(const VectorIndex i, const T val)
        {
            this->Set(i, data[i] + val);
        }

        inline void Mult(const VectorIndex i, const T val)
        {
            // this->Set(i, data[i] * val);  // right now it is consistent with just the simpler
            data[i] *= val;
        }

        inline T First() const
        {
            return data[0];
        }
        inline T Last() const
        {
            return data[this->Size() - 1];
        }

        // Unsafe but fast and handy get.
        inline T Get(const VectorIndex i) const
        {
            return data[i];
        }

        // Safe version of the above
        inline bool Get(const VectorIndex i, T* value) const {
          if (i >= size)
            return false;

          *value = data[i];
          return true;
        }

        inline const T& operator[](const VectorIndex i) const
        {
            return data[i];
        }

        inline T& operator[](const VectorIndex i)
        {
            return data[i];
        }

        inline const T* const GetData() const
        {
            return data.data();
        }

        /*
         * Basic vector operations.
         */
        virtual double Dist(const Vector<T>& vec) const
        {
            double dist = 0.0;
            for (VectorIndex i = 0; i < vec.Size(); ++i)
                dist += (this->Get(i) - vec.Get(i)) * (this->Get(i) - vec.Get(i));

            return sqrt(dist);
        }

        virtual double Norm2() const
        {
            double mod = 0.0;
            if (UseNonZeroIndexes()) {
                for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
                     iter != non_zero_indexes.end(); ++iter) {
                    mod += this->Get(*iter) * this->Get(*iter);
                }
            } else {
                for (VectorIndex i = 0; i < this->Size(); ++i)
                    mod += this->Get(i) * this->Get(i);
            }
            return sqrt(mod);
        }

        virtual double Norm1() const {
            return this->AbsSum();
        }

        virtual double AbsAvg() const {
            if (this->Size() == 0)  return 0;
            return this->AbsSum() / this->Size();
        }

        virtual double Avg() const {
            if (this->Size() == 0)  return 0;
            return this->Sum() / this->Size();
        }

        virtual T Sum() const
        {
            if (all_zero)  return 0;

            T sum = static_cast<T>(0.0);
            if (UseNonZeroIndexes()) {
                for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
                     iter != non_zero_indexes.end(); ++iter) {
                    sum += this->Get(*iter);
                }
            } else {
                for (VectorIndex i = 0; i < this->Size(); ++i)
                    sum += this->Get(i);
            }

            return sum;
        }

        virtual T AbsSum() const
        {
            if (all_zero)  return 0;

            T sum = static_cast<T> (0.0);
            if (UseNonZeroIndexes()) {
                for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
                     iter != non_zero_indexes.end(); ++iter) {
                    sum += std::abs(this->Get(*iter));
                }
            } else {
                for (VectorIndex i = 0; i < this->Size(); ++i)
                    sum += std::abs(this->Get(i));
            }

            return sum;
        }

        virtual void AddInPlace(const Vector<T>& vec) {
          if (vec.all_zero)  return;
          CHECK_EQ(this->Size(), vec.Size());

          if (vec.UseNonZeroIndexes()) {
              for (NonZeroIndexSet::const_iterator iter = vec.non_zero_indexes.begin();
                   iter != vec.non_zero_indexes.end(); ++iter) {
                  this->Set(*iter, this->Get(*iter) + vec.Get(*iter));
              }
          } else {
              for (VectorIndex i = 0; i < vec.Size(); ++i)
                  this->Set(i, this->Get(i) + vec.Get(i));
          }
        }

        virtual void AddInPlace(const T val)
        {
            for (VectorIndex i = 0; i < this->Size(); ++i)
                this->Set(i, this->Get(i) + val);
        }

        virtual void SubInPlace(const Vector<T>& vec)
        {
            CHECK_EQ (this->Size(), vec.Size());
            if (vec.all_zero)  return;
            if (vec.UseNonZeroIndexes()) {
                for (NonZeroIndexSet::const_iterator iter = vec.non_zero_indexes.begin();
                        iter != vec.non_zero_indexes.end(); ++iter) {
                    this->Set(*iter, this->Get(*iter) - vec.Get(*iter));
                }
            } else {
                for (VectorIndex i = 0; i < vec.Size(); ++i)
                    this->Set(i, this->Get(i) - vec.Get(i));
            }
        }

        virtual void AbsInPlace() {
            if (this->all_zero)  return;
            if (this->UseNonZeroIndexes()) {
                for (NonZeroIndexSet::const_iterator iter = this->non_zero_indexes.begin();
                     iter != this->non_zero_indexes.end(); ++iter) {
                    this->Set(*iter, std::abs(this->Get(*iter)));
                }
            } else {
                for (VectorIndex i = 0; i < this->Size(); ++i) {
                    this->Set(i, std::abs(this->Get(i)));
                }
            }
        }

        virtual void Abs(Vector<T>* vec) const {
            vec->Copy(*this);
            vec->AbsInPlace();
        }

        virtual Vector<T> Abs() const {
            Vector<T> vec(*this);
            vec.AbsInPlace();
            return vec;
        }

        // Get a new vector with the first n elements of this.
        Vector<T> GetFirst(const VectorIndex n) const {
            const VectorIndex vec_size = Math::Min(n, this->Size());
            Vector<T> vec(vec_size);
            if (!all_zero) {
                for (VectorIndex i = 0; i < vec_size; ++i) {
                    vec.Set(i, this->Get(i));
                }
            }
            return vec;
        }

        // Gets a new vector in the specified range, avoids to copy on return.
        void GetRange(const VectorIndex first, const VectorIndex size, Vector<T>* vec) const {
            const VectorIndex vec_size = Math::Min(size, this->Size());
            CHECK_GE(vec_size, static_cast<VectorIndex>(0));
            vec->Init(vec_size);
            if (!all_zero) {
                for (VectorIndex i = first; i < vec_size; ++i) {
                    vec->Set(i, this->Get(first + i));
                }
            }
        }

        // Gets a new vector in the specified range, handier but slower version of the above.
        Vector<T> GetRange(const VectorIndex first, const VectorIndex size) const {
            Vector<T> vec;
            this->GetRange(first, size, &vec);
            return vec;
        }

        // Gets a new vector with only the topN elements and all the others set to 0.
        void KeepMaxN(const VectorIndex n, Vector<T>* vec) const {
            vec->Init(this->Size());
            typedef std::pair<T, VectorIndex> ValueIndexPair;
            TopN<ValueIndexPair, std::greater<ValueIndexPair> > topn(n);
            if (!all_zero) {
                for (VectorIndex i = 0; i < this->Size(); ++i) {
                    topn.Push(std::make_pair(this->Get(i), i));
                }
                std::vector<ValueIndexPair> topn_vec;
                topn.Get(&topn_vec);
                for (unsigned int i = 0; i < topn_vec.size(); ++i) {
                    vec->Set(topn_vec[i].second, topn_vec[i].first);
                }
            }
        }
        // Gets a new vector with only the topN elements and all the others set to 0.
        Vector<T> KeepMaxN(const VectorIndex n) const {
            Vector<T> vec;
            this->KeepMaxN(n, &vec);
            return vec;
        }

        // Gets a new vector with only the minN elements and all the others set to 0.
        void KeepMinN(const VectorIndex n, Vector<T>* vec) const {
            vec->Init(this->Size());
            typedef std::pair<T, VectorIndex> ValueIndexPair;
            TopN<ValueIndexPair, std::less<ValueIndexPair> > topn(n);
            if (!all_zero) {
                for (VectorIndex i = 0; i < this->Size(); ++i) {
                    topn.Push(std::make_pair(this->Get(i), i));
                }
                std::vector<ValueIndexPair> topn_vec;
                topn.Get(&topn_vec);
                for (unsigned int i = 0; i < topn_vec.size(); ++i) {
                    vec->Set(topn_vec[i].second, topn_vec[i].first);
                }
            }
        }

        // Gets a new vector with only the minN elements and all the others set to 0.
        Vector<T> KeepMinN(const VectorIndex n) const {
            Vector<T> vec;
            this->KeepMinN(n, &vec);
            return vec;
        }

        // Gets a new vector where all values below value are zeros.
        void GetWithZeroValuesBelow(const T value, Vector<T>* vec) const {
            vec->Copy(*this);
            if (all_zero)  return;
            for (VectorIndex i = 0; i < this->Size(); ++i) {
                if (vec->Get(i) < value) {
                    vec->Set(i, 0);
                }
            }
        }

        // Gets a new vector where all values below value are zeros.
        Vector<T> GetWithZeroValuesBelow(const T value) const {
            Vector<T> vec;
            this->GetWithZeroValuesBelow(value, &vec);
            return vec;
        }

        // Gets a new vector where all values below value are zeros.
         void GetWithZeroValuesAbove(const T value, Vector<T>* vec) const {
             vec->Copy(*this);
             if (all_zero)  return;
             for (VectorIndex i = 0; i < this->Size(); ++i) {
                 if (vec->Get(i) > value) {
                     vec->Set(i, 0);
                 }
             }
         }

         // Gets a new vector where all values below value are zeros.
         Vector<T> GetWithZeroValuesAbove(const T value) const {
             Vector<T> vec;
             this->GetWithZeroValuesAbove(value, &vec);
             return vec;
         }
        virtual void NormalizeInPlace() {
            if (all_zero)  return;

            const T norm = static_cast<T>(this->Norm2());
            if (norm < static_cast<T>(1e-6)) {  // to avoid numeric problems
                return;
            }

            const double norm_factor = 1.0 / norm;
            for (VectorIndex i = 0; i < this->Size(); ++i) {
                this->Set(i, this->Get(i) * norm_factor);
            }
        }

        virtual void MultiplyInPlace(const T val) {
            if (all_zero)  return;
            for (VectorIndex i = 0; i < this->Size(); ++i)
                this->Set(i, val * this->Get(i));
        }

        virtual void Sign() {
            for (VectorIndex i = 0; i < this->Size(); ++i) {
                if (this->Get(i) > 0.0)
                    this->Set(i, 1.0);
                else if (this->Get(i) == 0.0)
                    this->Set(i, 0.0);
                else
                    this->Set(i, -1.0);
            }
        }

        virtual double Sign(const VectorIndex i) {
            if (this->Get(i) > 0.0)
                return static_cast<double>(1);
            if (this->Get(i) == 0.0)
                return static_cast<double>(0);
            return static_cast<double>(-1);
        }

        virtual void MultiplyInPlace(const Vector<T>& vec);

        virtual void PowInPlace(const T& val);

        virtual bool Load(const std::string& filename);

        // I/O
        virtual bool SaveToStream(std::ostream& os) const;
        virtual std::string ToString() const;
        virtual bool LoadFromStream(std::istream& is);
        // Same as above but print the vector as index:value pairs (only elements with non default T() values are printed).
        virtual bool SaveToStreamAsSparse(std::ostream& os) const;
        virtual std::string ToStringAsSparse() const;

        // Sorting
        virtual void Sort(bool (*comparison)(const T& a, const T& b))
        {
            std::sort(data.begin(), data.end(), comparison);
        }

        virtual void AscendingSort()
        {
            std::sort(data.begin(), data.end(), AscendingComparison);
        }

        virtual void DescendingSort()
        {
            std::sort(data.begin(), data.end(), DescendingComparison);
        }

        virtual std::pair<VectorIndex, T> Max() const;
        virtual std::pair<VectorIndex, T> Min() const;
        virtual T MaxValue() const;
        virtual T MinValue() const;
        virtual T MaxAbsValue() const;
        virtual T MinAbsValue() const;
        virtual bool HasNonZeroValue() const {
            return !this->all_zero;
        }
}; // end Vector

template <typename T>
void Vector<T>::PowInPlace(const T& val) {
    if (all_zero || val == static_cast<T>(1.0)) {
        return;
    }
    for (VectorIndex i = 0; i < this->Size(); ++i)
        this->Set(i, std::pow(this->Get(i), val));
}

template <typename T>
void Vector<T>::MultiplyInPlace(const Vector<T>& vec) {
    if (all_zero)  return;
    CHECK_EQ (this->Size(), vec.Size());

    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            this->Set(*iter, vec.Get(*iter) * this->Get(*iter));
        }
    } else {
        for (VectorIndex i = 0; i < this->Size(); ++i)
            this->Set(i, vec.Get(i) * this->Get(i));
    }
}

// I/O
template <typename T>
bool Vector<T>::Load(const std::string& filename)
{
    this->Clear();
    std::ifstream ifs(filename.c_str ());

    if (!ifs.is_open())
    {
        WARN ("Could not open the file " << filename);
        return false;
    }

    bool ret = this->LoadFromStream(ifs);
    ifs.close();
    return ret;
}

template <typename T>
bool Vector<T>::LoadFromStream(std::istream& is)
{
    this->Clear ();
    std::string line;
    VectorIndex size_;
    is >> size_;
    this->Init(size_);
    getline (is, line); // read the remaining portion of the line
    VectorIndex read_elements = 0;

    while (!is.eof ())
    {
        getline (is, line);

        if (line.empty ())
            continue; // skip empty lines

        std::vector<std::string> tokens;
        StringUtils::SplitToVector(line, &tokens, "\t", false);

        for (VectorIndex i = 0; i < tokens.size (); ++i) {
            T value;
            if (!StringUtils::ReadElement(tokens[i], &value)) {
                WARN ("Can not process token: " << tokens[i] << " in line " << line);
                continue;
            }

            // This is a valid element, add it to the matrix.
            this->Set(read_elements, value);
            ++read_elements;
        }
    }

    // Returns true if all elements have been successfully read.
    return (read_elements == this->Size());
}

// Save the matrix to the stream.

template <typename T>
bool Vector<T>::SaveToStream(std::ostream& os) const
{
    os << size << " ["; //std::endl;

    for (VectorIndex i = 0; i < size; ++i)
    {
        if (i != size - 1)
            os << data[i] << '\t'; // std::scientific <<std::setprecision(10) <<

        else
            os << data[i] << "]" << std::endl;
    }

    return true;
}

template <typename T>
bool Vector<T>::SaveToStreamAsSparse(std::ostream& os) const {
    for (VectorIndex i = 0; i < size; ++i) {
        if (data[i] != T()) {
            os << i << ":" << data[i] << ' ';
        }
    }
    os << std::endl;
    return true;
}

template<typename T>
std::string Vector<T>::ToStringAsSparse() const {
    std::ostringstream os;
    this->SaveToStreamAsSparse(os);
    return os.str();
}

template<typename T>
std::string Vector<T>::ToString() const {
    std::ostringstream os;
    this->SaveToStream(os);
    return os.str();
}

template<typename T>
std::pair<Math::VectorIndex, T> Vector<T>::Max() const {
    if (this->Size() == 0)
        return std::pair<Math::VectorIndex, T>(0, T());

    std::pair<VectorIndex, T> ret = std::make_pair(0, this->Get(0));

    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            if (this->Get(*iter) > ret.second)
                ret = std::make_pair(*iter, this->Get(*iter));
        }
    } else {
        for (VectorIndex i = 1; i < this->Size(); ++i)
            if (this->Get(i) > ret.second)
                ret = std::make_pair(i, this->Get(i));
    }


    return ret;
}

template<typename T>
T Vector<T>::MaxValue() const
{
    if (this->Size() == 0)
        return 0;

    T ret = this->Get(0);

    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            if (this->Get(*iter) > ret)
                ret = this->Get(*iter);
        }
    } else {
        for (VectorIndex i = 1; i < this->Size(); ++i)
            if (this->Get(i) > ret)
                ret = this->Get(i);
    }

    return ret;
}

template<typename T>
std::pair<Math::VectorIndex, T> Vector<T>::Min() const
{
    if (this->Size() == 0)
        return std::pair<Math::VectorIndex, T>(0, 0.0);

    std::pair<VectorIndex, T> ret = std::make_pair(0, this->Get(0));
    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            if (this->Get(*iter) > ret.second)
                ret = std::make_pair(*iter, this->Get(*iter));
        }
    } else {
        for (VectorIndex i = 1; i < this->Size(); ++i)
            if (this->Get(i) < ret.second)
                ret = std::make_pair(i, this->Get(i));
    }


    return ret;
}

template<typename T>
T Vector<T>::MinValue() const {
    if (this->Size() == 0)
        return 0;

    T ret = this->Get(0);

    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            if (this->Get(*iter) > ret)
                ret = this->Get(*iter);
        }
    } else {
        for (VectorIndex i = 1; i < this->Size(); ++i)
            if (this->Get(i) < ret)
                ret = this->Get(i);
    }

    return ret;
}

template<typename T>
T Vector<T>::MinAbsValue() const {
    if (this->Size() == 0)
        return 0;

    T ret = std::abs(this->Get(0));

    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            const T val = std::abs(this->Get(*iter));
            if (val < ret)
                ret = val;
        }
    } else {
        for (VectorIndex i = 1; i < this->Size(); ++i) {
            const T val = std::abs(this->Get(i));
            if (val < ret)
                ret = val;
        }
    }

    return ret;
}

template<typename T>
T Vector<T>::MaxAbsValue() const {
    if (this->Size() == 0)
        return 0;

    T ret = std::abs(this->Get(0));

    if (UseNonZeroIndexes()) {
        for (NonZeroIndexSet::const_iterator iter = non_zero_indexes.begin();
             iter != non_zero_indexes.end(); ++iter) {
            const T val = std::abs(this->Get(*iter));
            if (val > ret)
                ret = val;
        }
    } else {
        for (VectorIndex i = 1; i < this->Size(); ++i) {
            const T val = std::abs(this->Get(i));
            if (val > ret)
                ret = val;
        }
    }
    return ret;
}
} // end Math

#endif // MATH_VECTOR_H_
