/*
 * math_sparse_vector.h
 *
 *  Created on: May 19, 2009
 *      Author: michi
 */

#ifndef MATH_SPARSE_VECTOR_H_
#define MATH_SPARSE_VECTOR_H_

#include "utils/math/math_vector.h"

namespace Math
{

template < typename I = VectorIndex, typename T = double >
class SparseVector : public BaseVector<I, T>
{
    private:
        typedef std::map<I, T > DataContainer;
        DataContainer data;

    public:
        // An element of the vector. Used to insert or read elements from it.

        struct Element
        {
            I i;
            T value;
            bool valid;

            Element(I i_, T value_, bool valid_) :
                i(i_), value(value_), valid(valid_)
            {
            }

            Element(bool valid_) : valid(valid_)
            {
            }

            Element() : valid(false)
            {
            }
        };
        typedef struct Element Element;
        // Allows iterating through a sparse matrix. Use like this:
        // SparseVector<I, T> V;
        // SparseVector<I, T>::Iterator iter(V);
        // while (iter.HasNext()) {
        //   SparseVector<I, T>::Element e = iter.GetNext();
        //   Do something with e
        // }

        class Iterator
        {
            private:
                typename DataContainer::const_iterator iter;
                const SparseVector<I, T>* svector;

            public:

                Iterator(const SparseVector<I, T>& svector_)
                {
                    svector = &svector_;
                    iter = svector->data.begin();
                }

                inline Element GetNext()
                {
                    if (this->HasNext())
                    {
                        Element e(iter->first, iter->second, true);
                        ++iter;
                        return e;
                    }

                    return Element(false);
                }

                inline void Rewind()
                {
                    iter = svector->data.begin();
                }

                inline bool HasNext() const
                {
                    return (iter != svector->data.end());
                }
        };
        friend class Iterator;

        SparseVector()
        {
        }

        // Converter constructor from Dense to Sparse Vector.
        // Only non zero elements are added.
        SparseVector(const Vector<T>& vector_)
        {
            for (VectorIndex i = 0; i < vector_.Size(); i++) {
                if (vector_.Get(i) != 0) {
                   Element el(i, vector_.Get(i), true);
                   this->Add(el);
                 }
            }
        }

        SparseVector(const SparseVector& svector_)
        {
            this->Copy(svector_);
        }

        virtual ~SparseVector()
        {
        }

        void Copy(const SparseVector<I, T>& svector_)
        {
            this->Clear();
            Iterator iter(svector_);

            while (iter.HasNext())
            {
                Element el = iter.GetNext();
                this->Set(el);
            }
        }

        virtual void Init()
        {
            this->Clear();
        }

        virtual void Clear()
        {
            data.clear();
        }

        // Inlined for speed, remove if inheritance is used.
        inline VectorIndex Size() const
        {
            return data.size();
        }

        inline void Set(I i, T val)
        {
            data[i] = val;
        }

        inline void Set(const Element& el)
        {
            CHECK(el.valid);
            data[el.i] = el.value;
        }

        inline bool Has(I i) const
        {
            typename DataContainer::const_iterator diter = data.find(i);
            return (diter != data.end());
        }

        inline bool Get(I i, T* value) const
        {
            typename DataContainer::const_iterator diter = data.find(i);

            if (diter == data.end())
                return false;

            *value = diter->second;
            return true;
        }

        inline const T GetCopy(I i) const
        {
            // Unsafe but fast
            typename DataContainer::const_iterator diter = data.find(i);
            return diter->second;
        }

        inline T Get(I i) const
        {
            // Unsafe but fast
            typename DataContainer::const_iterator diter = data.find(i);
            return diter->second;
        }

        inline void Add(I i1, T val)
        {
            data[i1] += val;
        }

        inline void Add(const Element& el)
        {
            CHECK(el.valid);
            data[el.i] += el.value;
        }

        inline void Sub(I i1, T val)
        {
            data[i1] -= val;
        }

        inline void Sub(const Element& el)
        {
            CHECK(el.valid);
            data[el.i] -= el.value;
        }
        // end Inlined.

        virtual void AddInPlace(const SparseVector<I, T>& svector_)
        {
            Iterator iter(svector_);

            while (iter.HasNext())
                this->Add(iter.GetNext());
        }

        virtual void SubInPlace(const SparseVector<I, T>& svector_)
        {
            Iterator iter(svector_);

            while (iter.HasNext())
                this->Sub(iter.GetNext());
        }

        virtual void AddInPlace(const Vector<T>& vector_)
        {
            for (VectorIndex i = 0; i < vector_.Size(); ++i)
            {
                typename DataContainer::const_iterator diter = data.find(i);

                if (diter != data.end())
                    this->Add(Element(i, diter->second, true));
            }
        }

        virtual void SubInPlace(const Vector<T>& vector_)
        {
            VectorIndex i;

            for (i = 0; i < vector_.Size(); ++i)
            {
                typename DataContainer::const_iterator diter = data.find(i);

                if (diter != data.end())
                    this->Sub(Element(i, diter->second, true));
            }
        }

        virtual void MultiplyInPlace(const T& val)
        {
            for (typename DataContainer::iterator diter = data.begin();
                    diter != data.end(); ++diter)
            {
                diter->second *= val;
            }
        }

        virtual void PowInPlace(const T& val)
        {
            for (typename DataContainer::iterator diter = data.begin();
                 diter != data.end(); ++diter) {
                diter->second = std::pow(diter->second, val);
            }
        }

        virtual bool Load(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str());

            if (!ifs.is_open())
            {
                WARN("Could not open the file " << filename);
                return false;
            }

            this->LoadFromStream(ifs);
            ifs.close();
            return true;
        }

        virtual bool SaveToStream(std::ostream& os) const
        {
            for (typename DataContainer::const_iterator iter = data.begin();
                    iter != data.end(); ++iter)
            {
                if (iter == data.begin())
                    os << iter->first << ':' << iter->second;

                else
                    os << '\t' << iter->first << ':' << iter->second;
            }

            os << std::endl;
            return true;
        }

        virtual bool LoadFromStream(std::istream& is)
        {
            this->Clear();
            std::string line;

            while (!is.eof())
            {
                getline(is, line);

                if (line.empty())
                    continue; // skip empty lines

                std::map<I, T> pairs;
                StringUtils::ReadPairs<I, T > (line, &pairs, " ", ":");

                for (typename std::map<I, T>::const_iterator iter = pairs.begin();
                        iter != pairs.end(); ++iter)
                {
                    this->Set(iter->first, iter->second);
                }
            }

            return true;
        }

        virtual std::string ToString() const
        {
            std::ostringstream os;
            this->SaveToStream(os);
            return os.str();
        }
}; // end SparseVector
} // end Math
#endif /* MATH_SPARSE_VECTOR_H_ */
