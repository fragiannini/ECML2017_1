/*
 * file_utils.cc
 *
 *  Created on: Aug 15, 2015
 *      Author: michi
 */

#include "utils/file_utils.h"

#include "utils/general.h"

// for file system stuff
#include <sys/stat.h>
#include <sys/types.h>

//to read and write directories
#include <dirent.h>

#include <sstream>

namespace FileUtils {

std::string DirName(const std::string& full_path) {
    const std::size_t pos = full_path.rfind('/');
    if (pos == std::string::npos) {
        return "";
    }
    return full_path.substr(0, pos);
}

void MakePathOrDie(const std::string& full_path) {
    CHECK(MakePath(full_path));
}

bool MakePath(const std::string& full_path)
{
  struct stat st;
  std::string remaining_path = full_path;

  // Directory already there, nothing to do.
  if (stat(remaining_path.c_str(), &st) == 0) {
      return true;
  }

  mkdir(full_path.c_str(), 0777);  // easy attempt: try to build the requested folder
  if (stat(full_path.c_str(), &st) == 0) {
      return true;
  }

  VMESSAGE(1, "Building path: " << full_path);
  std::string built_path;
  size_t slash = remaining_path.find('/');
  if (slash == 0) {
      built_path = "/";
      remaining_path = remaining_path.substr(1);
      slash = remaining_path.find('/');
  }

  // Recursively build the subdirectories.
  while (slash != std::string::npos) {
      const std::string subdir = remaining_path.substr(0, slash);
      if (subdir == "..") {
          WARN("Not supported building paths with ..");
          return false;
      }
      if (subdir != ".") {
          built_path += subdir;
          if (stat(built_path.c_str(), &st) != 0) {
              VMESSAGE(3, "Building path: " << built_path);
              mkdir(built_path.c_str(), 0777);
              if (stat(built_path.c_str(), &st) != 0) {
                  WARN("Unable to create the directory " << full_path << " at path: " << built_path);
                  return false;
              }
          }
          built_path += '/';
      }
      remaining_path = remaining_path.substr(slash + 1);
      slash = remaining_path.find('/');
  }

  if (!remaining_path.empty()) {
      // No more "/", last path portion, build it.
      built_path += remaining_path;
      VMESSAGE(3, "Building path: " << built_path);
      mkdir(built_path.c_str(), 0777);
  }

  // Final check that the directory is available.
  if (stat(full_path.c_str(), &st) != 0) {
    WARN("Unable to create the directory " << full_path);
    return false;
  }

  return true;
}

bool IsPathDir(const std::string& path) {
    struct stat info;
    if (stat(path.c_str(), &info) != 0) {
        return false;
    }
    return (info.st_mode & S_IFDIR);
}

}  // end FileUtils
