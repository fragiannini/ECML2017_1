/*
 * string_utils.h
 *
 *  Created on: May 6, 2009
 *      Author: michi
 */

#ifndef STRING_UTILS_HH_
#define STRING_UTILS_HH_

#include <deque>
#include <iostream>
#include <map>
#include <set>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "utils/general.h"

namespace std {

/*
 * To print a std::pair to a stream.
 * Requires to have declared to be using the std namespace.
 */
template<typename K, typename V>
ostream& operator<<(ostream& os, std::pair<K, V> pair_)
{
    os << pair_.first << "::" << pair_.second;
    return os;
}
}

namespace StringUtils {
// Return true if the string starts with char c. Trims front spaces if trim_spaces=true.
bool StartsWith(const std::string& str, const char c, const bool trim_spaces=true);
bool StartsWith(const std::string& str, const std::string& prefix, const bool trim_spaces=true);

template<typename Type>
Type ReadElementOrDie(std::istream& is)
{
    Type el;
    CHECK(static_cast<bool>(is >> el));
    return el;
}

template<typename Type>
Type ReadElementOrDie(const std::string& token)
{
    std::istringstream iss(token);
    Type el;
    CHECK(static_cast<bool>(iss >> el));
    return el;
}

template<typename Type>
Type ReadElementOrDie(std::istream& is, char sep) {
  std::string str;
  std::getline(is, str, sep);
  return ReadElementOrDie<Type>(str);
}

template<typename Type>
bool ReadElement(const std::string& token, Type* key)
{
    std::istringstream iss(token);
    return static_cast<bool>(iss >> *key);
}

template<typename T>
std::string ToString(const T t) {
    std::ostringstream os;
    if (!static_cast<bool>(os << t)) {
        WARN("Can not convert to string type");
        return "";
    }
    return os.str();
}

// Template specialization, this is implemented in the .cc
template<>
bool ReadElement<std::string>(const std::string& token, std::string* key);

template <typename T>
bool ToFile(const T& s, const std::string& file) {
    std::ofstream os(file.c_str());
    if (!os.good())  return false;
    os << s;
    return true;
}

template <typename T>
void ToFileOrDie(const T& s, const std::string& file) {
    CHECK(ToFile(s, file));
}

template <typename T>
bool AppendToFile(const T& s, const std::string& file) {
    std::ofstream os(file.c_str(), std::ios_base::app);
    if (!os.good())  return false;
    os << s;
    return true;
}

template <typename T>
void AppendToFileOrDie(const T& s, const std::string& file) {
    CHECK(AppendToFile(s, file));
}

// Super fast and ugly version that split a c_str directly in place. Not tested!!!
void SplitToDeque(char* const input, const char sep, std::deque<char*>* output);

void SplitToDeque(const std::string& input,
                   std::deque<std::string>* vec,
                   const char sep,
                   bool skipNullStrings);

void SplitToVector(const std::string& input,
                   std::vector<std::string>* vec,
                   const char sep,
                   bool skipNullStrings);

void SplitToVector(const std::string& input,
                   std::vector<std::string>* vec,
                   const std::string& sep,
                   bool skipNullStrings = false);

// As splitToVector but creates a vector of objects of type T.
// Use splitToVector directly if T==string. Use template specialization to
// do this in a cleaner way.

template<typename T>
void SplitToVectorByType(const std::string& input,
                         std::vector<T>* vec,
                         const std::string& sep,
                         bool skipNullStrings = false)
{
    vec->clear();
    std::vector<std::string> str_vec;
    StringUtils::SplitToVector(input, &str_vec, sep, skipNullStrings);

    // Convert strings to T
    for (unsigned int i = 0; i < str_vec.size(); ++i)
    {
        std::istringstream is(str_vec[i]);
        T field;

        if (!(is >> field))
        {
            WARN("Can not read " << str_vec[i]);
            continue;
        }

        vec->push_back(field);
    }
}

// As SplitToVectorByType but creates a set of objects of type T.
// Use SplitToVector directly if T==string. Use template specialization to
// do this in a cleaner way.

template<typename T>
void SplitToSetByType(const std::string& input,
                      std::set<T>* set_,
                      const std::string& sep,
                      bool skipNullStrings = false)
{
    set_->clear();
    std::vector<std::string> str_vec;
    StringUtils::SplitToVector(input, &str_vec, sep, skipNullStrings);

    // Convert strings to T
    for (unsigned int i = 0; i < str_vec.size(); ++i)
    {
        std::istringstream is(str_vec[i]);
        T field;

        if (!(is >> field))
        {
            WARN("Can not read " << str_vec[i]);
            continue;
        }

        set_->insert(field);
    }
}

// As SplitToMapByType but creates a map of objects of type T.
// Use splitToVector directly if T==string. Use template specialization to
// do this in a cleaner way.
// Splits input using sep first, obtaining one substring for each entry to
// insert. Each substring is resplit using sep1, obtaining a (key, value) pair.
// If the value is not provided (but only the key in any entry, the parameter
// default_value is used to determine the default value for that entry.

template<typename K, typename T>
void SplitToMapByType(const std::string& input,
                      std::map<K, T>* map_,
                      const std::string& sep,
                      const std::string& sep1,
                      const T& default_value,
                      bool skipNullStrings = false)
{
    map_->clear();
    std::vector<std::string> str_vec;
    StringUtils::SplitToVector(input, &str_vec, sep, skipNullStrings);

    // Convert strings to T
    for (unsigned int i = 0; i < str_vec.size(); ++i)
    {
        K key;
        T value;
        std::vector<std::string> entry;
        StringUtils::SplitToVector(str_vec[i], &entry, sep1, false);

        if (entry.size() == 1)
        {
            std::istringstream is(str_vec[i]);

            if (!(is >> key))
            {
                WARN("Can not read " << str_vec[i].c_str());
                continue;
            }

            value = default_value;
        }

        else if (entry.size() == 2)
        {
            std::istringstream is(entry[0]);

            if (!(is >> key))
            {
                WARN("Can not read key " << entry[0].c_str() << " in " << str_vec[i].c_str());
                continue;
            }

            is.clear();
            is.str(entry[1]);

            if (!(is >> value))
            {
                WARN("Can not read value " << entry[1].c_str() << " in " << str_vec[i].c_str());
                continue;
            }
        }

        else
        {
            WARN("Can not read " << str_vec[i].c_str());
            continue;
        }

        map_->insert(make_pair(key, value));
    }
}

// Splits a string using sep into a vector of tokens.
// Each vector is subsequently re-split using sep1.
// The result is a vector< vector<T> >

template<typename T>
void SplitToVectorOfVectorsByType(
    const std::string& input,
    std::vector<std::vector<T> >* vec,
    const std::string& sep,
    const std::string& sep1,
    bool skipNullStrings = false)
{
    vec->clear();
    std::vector<std::string> str_vec;
    StringUtils::SplitToVector(input, &str_vec, sep, skipNullStrings);

    // Convert strings to T
    for (unsigned int i = 0; i < str_vec.size(); ++i)
    {
        std::vector<T> single_vec;
        StringUtils::SplitToVectorByType(
            str_vec[i], &single_vec, sep1, skipNullStrings);
        vec->push_back(single_vec);
    }
}

// Splits a string using sep into a vector of tokens.
// Each vector is subsequently re-split using sep1.
// The result is a vector< set<T> >

template<typename T>
void SplitToVectorOfSetsByType(
    const std::string& input,
    std::vector< std::set<T> >* vec,
    const std::string& sep,
    const std::string& sep1,
    bool skipNullStrings = false)
{
    vec->clear();
    std::vector<std::string> str_vec;
    StringUtils::SplitToVector(input, &str_vec, sep, skipNullStrings);

    // Convert strings to T
    for (unsigned int i = 0; i < str_vec.size(); ++i)
    {
        std::set<T> single_set;
        StringUtils::SplitToSetByType(str_vec[i], &single_set, sep1, skipNullStrings);
        vec->push_back(single_set);
    }
}

// Splits a string using sep into a vector of tokens.
// Each entry is subsequently re-split using sep1.
// Each resulting element is split using sep2 obtaining a (key, value) pair.
// If the value is not provided (but only the key in any entry, the parameter
// default_value is used to determine the default value for that entry.
// The result is a vector< map<K, T> >

template<typename K, typename T>
void SplitToVectorOfMapsByType(
    const std::string& input,
    std::vector< std::map<K, T> >* vec,
    const std::string& sep,
    const std::string& sep1,
    const std::string& sep2,
    const T& default_value,
    bool skipNullStrings = false)
{
    vec->clear();
    std::vector<std::string> str_vec;
    StringUtils::SplitToVector(input, &str_vec, sep, skipNullStrings);

    // Convert strings to T
    for (unsigned int i = 0; i < str_vec.size(); ++i)
    {
        std::map<K, T> single_map;
        StringUtils::SplitToMapByType(str_vec[i], &single_map, sep1, sep2,
                                      default_value, skipNullStrings);
        vec->push_back(single_map);
    }
}

template<typename Key, typename Value>
bool ReadPair(const std::string& token, Key* key, Value* value, const std::string& sep = ":")
{
    std::vector<std::string> fields;
    SplitToVector(token, &fields, sep, false);
    if (fields.size() != 2) {
        WARN("Wrong token passed to ReadPair " << token << " no separator " << sep << " found");
        return false;
    }

    std::istringstream iss(fields[0]);
    bool ret = static_cast<bool>(iss >> *key);
    std::istringstream iss1(fields[1]);
    ret = ret && static_cast<bool>(iss1 >> *value);
    return ret;
}

template<typename Key, typename Value>
bool ReadPair(const std::string& token, Key* key, Value* value, const char sep = ':')
{
    std::vector<std::string> fields;
    StringUtils::SplitToVector(token, &fields, sep, false);
    if (fields.size() != 2) {
        WARN("Wrong token passed to ReadPair " << token << " no separator " << sep << " found");
        return false;
    }

    std::istringstream iss(fields[0]);
    bool ret = static_cast<bool>(iss >> *key);
    std::istringstream iss1(fields[1]);
    ret = ret && static_cast<bool>(iss1 >> *value);
    return ret;
}

template<typename Key, typename Value>
bool ReadPairs(const std::string& token,
               std::map<Key, Value>* pairs,
               const std::string& sep1 = ",",
               const std::string& sep2 = ":") {
    bool ret = true;
    pairs->clear();
    std::vector<std::string> fields;
    SplitToVector(token, &fields, sep1, false);

    for (unsigned int i = 0; i < fields.size(); ++i)
    {
        std::pair<Key, Value> apair;

        if (fields[i].find(sep2) != std::string::npos)
        {
            // Read one pair.
            ret &= ReadPair(fields[i], &(apair.first), &(apair.second), sep2);
        } else {
            // If only one element is provided, the key assumed to be the
            // default returned by the constructor..
            apair.first = Key();
            ret &= ReadElement(fields[i], &(apair.second));
        }

        pairs->insert(apair);
    }

    return ret;
}

template<typename T>
std::string CVectorToString(const T* vec, unsigned int length,
                            char sep = ' ', const std::string& last_sep = "\n")
{
    if (length == 0)
        return last_sep;

    std::ostringstream oss;

    for (unsigned int i = 0; i < length - 1; ++i)
        oss << vec[i] << sep;

    oss << vec[length - 1];
    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T>
std::string ContainerToString(const T& vec, const std::string& sep = " ", const std::string& last_sep = "\n")
{
    std::ostringstream oss;
    for (typename T::const_iterator iter = vec.begin(); iter != vec.end(); ++iter) {
        if (iter == vec.begin())
            oss << *iter;
        else
            oss << sep << *iter;
    }
    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T1, typename T2>
std::string DefaultPairToStringPrinter(const std::pair<T1, T2>& p) {
    std::ostringstream oss;
    oss << p.first << " " << p.second;
    return oss.str();
}

// Like above but with a printer function for each element.
// Example:
// vector<pair<int, float> > vec;
// string s = StringUtils::ContainerToString(
//     vec, StringUtils::DefaultPairToStringPrinter<int, float>, "\n");
template<typename T>
std::string ContainerToString(
        const T& vec, std::string (*ElementToStringPrinter)(const typename decltype(vec)::type&),
        const std::string& sep = " ", const std::string& last_sep = "\n") {
    std::ostringstream oss;
    for (typename T::const_iterator iter = vec.begin(); iter != vec.end(); ++iter) {
        const std::string str = ElementToStringPrinter(*iter);
        if (iter == vec.begin()) {
            oss << str;
        } else {
            oss << sep << str;
        }
    }
    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T>
std::string VectorToString(const std::vector<T>& vec, const std::string& sep = " ", const std::string& last_sep = "\n")
{
    if (vec.size() == 0)
        return last_sep;

    std::ostringstream oss;
    for (unsigned int i = 0; i < vec.size() - 1; ++i)
        oss << vec[i] << sep;
    oss << vec[vec.size() - 1];

    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T>
std::string SetToString(const std::set<T>& vec, const std::string& sep = " ", const std::string& last_sep = "\n")
{
    std::ostringstream oss;
    for (typename std::set<T>::const_iterator iter = vec.begin();
            iter != vec.end(); ++iter) {
        if (iter == vec.begin())
            oss << *iter;
        else
            oss << sep << *iter;
    }

    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T, typename V>
std::string MapToString(const std::map<T, V>& vec,
        const std::string& sep = " ", const std::string& sep1 = ":", const std::string& last_sep = "\n") {
    std::ostringstream oss;

    for (typename std::map<T, V>::const_iterator iter = vec.begin();
            iter != vec.end(); ++iter) {
        if (iter != vec.begin())  oss << sep;
        oss << iter->first << sep1 << iter->second;
    }

    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T, typename V>
std::string MultimapToString(const std::multimap<T, V, std::greater<T> >& vec,
        const std::string& sep = " ", const std::string& sep1 = ":", const std::string& last_sep = "\n") {
    std::ostringstream oss;

    for (typename std::map<T, V>::const_iterator iter = vec.begin();
            iter != vec.end(); ++iter) {
        if (iter != vec.begin())  oss << sep;
        oss << iter->first << sep1 << iter->second;
    }
    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T, typename V>
std::string MultimapToString(const std::multimap<T, V>& vec,
        const std::string& sep = " ", const std::string& sep1 = ":", const std::string& last_sep = "\n") {
    std::ostringstream oss;

    for (typename std::map<T, V>::const_iterator iter = vec.begin();
            iter != vec.end(); ++iter) {
        if (iter != vec.begin())  oss << sep;
        oss << iter->first << sep1 << iter->second;
    }
    if (!last_sep.empty())
        oss << last_sep;
    return oss.str();
}

template<typename T>
bool FromString(const std::string& input, T* output, bool failIfLeftoverChars = true)
{
    std::istringstream iss(input);
    char c;

    if (!(iss >> *output) || (failIfLeftoverChars && iss.get(c)))
    {
        //WARN("Error: the input value contains a char");
        return false;
    }

    return true;
}

bool IsAlphaNumeric(const std::string&);
bool IsAlphaNumericOrInSet(const std::string&, const std::string&);
int SubstringCounter(const std::string&, const std::string&);
int CharCounter(const std::string&, const char);
int CharsCounter(const std::string&, const std::string&);
bool HasChar(const std::string&, const char c);
bool HasChars(const std::string&, const std::string& chars);

std::string ReShuffleStringsOfFile (const std::string&, const std::string&, const std::string&);

void Replace(const char in, const char out, std::string* s);
std::string Replace(const char in, const char out, const std::string& s);

void Replace(const std::string& in, const std::string& out, std::string* s);
std::string Replace(const std::string& in, const std::string& out, const std::string& s);

void Delete(const char in, std::string* s);  // slow, not optimized

// Simple and fast string concatenation of any stream-able type.
template<typename T1, typename T2>
std::string StrCat(const T1& a) {
    std::ostringstream os;
    os << a;
    return os.str();
}

template<typename T1, typename T2>
std::string StrCat(const T1& a, const T2& b) {
    std::ostringstream os;
    os << a << b;
    return os.str();
}

template<typename T1, typename T2, typename T3>
std::string StrCat(const T1& a, const T2& b, const T3& c) {
    std::ostringstream os;
    os << a << b << c;
    return os.str();
}

template<typename T1, typename T2, typename T3, typename T4>
std::string StrCat(const T1& a, const T2& b, const T3& c, const T4& d) {
    std::ostringstream os;
    os << a << b << c << d;
    return os.str();
}

template<typename T1, typename T2, typename T3, typename T4, typename T5>
std::string StrCat(const T1& a, const T2& b, const T3& c, const T4& d, const T5& e) {
    std::ostringstream os;
    os << a << b << c << d << e;
    return os.str();
}

template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
std::string StrCat(const T1& a, const T2& b, const T3& c, const T4& d, const T5& e, const T6& f) {
    std::ostringstream os;
    os << a << b << c << d << e << f;
    return os.str();
}

template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
std::string StrCat(const T1& a, const T2& b, const T3& c, const T4& d, const T5& e, const T6& f, const T7& g) {
    std::ostringstream os;
    os << a << b << c << d << e << f << g;
    return os.str();
}

template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
std::string StrCat(const T1& a, const T2& b, const T3& c, const T4& d, const T5& e, const T6& f, const T7& g, const T8& h) {
    std::ostringstream os;
    os << a << b << c << d << e << f << g << h;
    return os.str();
}

bool RemoveDuplicatedSpaces(std::string* s);
// Handy version ofg the above, which should be preferred when most
// inputs do not need modifications, because the extra string copy
// is avoided in that case.
std::string RemoveDuplicatedSpaces(const std::string& s);

bool RemoveSpacesAtStartAndEndOfString(std::string* s);
// Handy version ofg the above, which should be preferred when most
// inputs do not need modifications, because the extra string copy
// is avoided in that case.
std::string RemoveSpacesAtStartAndEndOfString(const std::string& s);

} // end namespace StringUtils

#endif  // STRING_UTILS_HH_
