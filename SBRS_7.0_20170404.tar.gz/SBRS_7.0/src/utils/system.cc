/*
 * system.cc
 *
 *  Created on: Nov 19, 2015
 *      Author: michi
 */

#include "utils/system.h"

#include <cstdlib>
#include <cstdio>
#include <string>

#ifndef _WIN32
#include <execinfo.h> // for backtrace and backtrace_symbols
#include <unistd.h>  // for getloadavg
#endif
#include "utils/general.h"


namespace SystemUtils {

std::string Cmdline(const int argc, char** argv) {
    std::string cmdline = argv[0];
    for (int i = 1; i < argc; ++i) {
        cmdline += " " + std::string(argv[i]);
    }
    return cmdline;
}

std::string GetStackTrace()
{
    std::string s;
#ifndef _WIN32
    void* callstack[128];
    int frames = backtrace(callstack, 128);
    // backtrace_symbols_fd(callstack, frames, 2);
    char** strs = backtrace_symbols(callstack, frames);
    for (int i = 0; i < frames; ++i) {
        s += std::string(strs[i]) + std::string("\n");
    }
    free(strs);
#endif
    return s;
}

// Average Load of the system
double GetLoadAvg() {
#ifndef _WIN32
    // NOTE: num_element it can be 1, 2 and 3 depending on if you evaluate the average load at 1, 5 and 15 minutes
    double loadAverageVector[3];

    if (getloadavg(loadAverageVector, 3) == -1)
    {
        WARN("Error: unable to detect the average load of the system");
        return 1;
    }

    double averageLoad = 0.0;
    for (int i = 0; i < 3; ++i) {
        averageLoad += loadAverageVector[i];
    }
    return averageLoad / 3.0;
#else
    return 1,0;
#endif

}

}  // end SystemUtils

