/*
 * parse_utils.cc
 *
 *  Created on: Jan 6, 2017
 *      Author: michi
 */

#include "utils/parse_utils.h"

#include <deque>
#include <iostream>
#include <stack>
#include <string>
#include <vector>

#include "utils/general.h"


using namespace std;

namespace ParseUtils {

ParseTree GetParseTree(
        const string& norm_s,
        const char token_start, const char token_end,
        const bool recursive) {
    CHECK_NE(token_start, token_end);

    ParseTree tree;
    tree.root.first = 0;
    tree.root.second = norm_s.length();
    tree.root_str = norm_s.substr(tree.root.first, tree.root.second - tree.root.first);

    stack<int> parse_stack;
    int connective_start = -1;
    for (unsigned int i = 0; i < norm_s.length(); ++i) {
        if (norm_s[i] == token_start) {
            parse_stack.push(i);

            if (connective_start >= 0) {
                tree.connectives.push_back(make_pair(connective_start, i));
                const string connective_str =
                        norm_s.substr(connective_start, i - connective_start);
                tree.connectives_str.push_back(connective_str);
                connective_start = -1;
            }
        } else if (norm_s[i] == token_end) {
            if (parse_stack.empty()) {
                FAULT("Wrong expression parse of " << norm_s << " : " <<
                      token_end << " not being opened by corresponding " << token_start);
            }
            const int start_index = parse_stack.top();
            parse_stack.pop();
            if (parse_stack.empty()) {
                tree.subtrees.push_back(ParseTree());
                const string subtree_str = norm_s.substr(start_index + 1, i - start_index - 1);
                ParseTree* subtree = &(tree.subtrees.back());
                if (recursive) {
                    *subtree = GetParseTree(subtree_str, token_start, token_end, recursive);
                } else {
                    subtree->root.first = start_index + 1;
                    subtree->root.second = i;
                    subtree->root_str = subtree_str;
                }
            }
        } else if (parse_stack.empty()) {
            if (connective_start < 0)  connective_start = i;
        }
    }
    if (connective_start >= 0) {
        tree.connectives.push_back(make_pair(connective_start, norm_s.length()));
        tree.connectives_str.push_back(norm_s.substr(connective_start));
    }

    return tree;
}

void ParseTree::Print() const {
    cout << ToString() << endl;
}

std::string ParseTree::ToString() const {
    ostringstream os;
    unsigned int connective_index = 0;
    unsigned int subtree_index = 0;
    CHECK_EQ(connectives.size(), connectives_str.size());
    while (connective_index < connectives.size() || subtree_index < subtrees.size()) {
        if (subtree_index >= subtrees.size() ||
            (connective_index < connectives.size() &&
             connectives[connective_index].first < subtrees[subtree_index].root.first)) {
            os << connectives_str[connective_index];
            ++connective_index;
        } else if (subtree_index < subtrees.size()) {
            os << "[" << subtrees[subtree_index].root_str << "]";
            ++subtree_index;
        }
    }
    for (unsigned int i = 0; i < subtrees.size(); ++i) {
        os << subtrees[i].ToString();
    }
    os << endl;
    return os.str();
}

} // end ParseUtils namespace
