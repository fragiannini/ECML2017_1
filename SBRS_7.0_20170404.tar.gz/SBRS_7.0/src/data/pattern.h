/*
 * File:   pattern.h
 * Author: Tore
 *
 * Created on 12 novembre 2010, 10.07
 */

#ifndef PATTERN_H
#define PATTERN_H

#include <string>
#include <map>
#include <vector>
#include "utils/general.h"
#include "data/basic_data_types.h"


namespace Regularization
{

/**
 * Class to represent an input pattern.
 **/
class Pattern
{
public:
    /**
     * Constructors
     **/
    Pattern()
    {
    }

    Pattern(const std::string& name_, const std::string& domain_) : name(name_), domain(domain_)
    {
    }

    /**
     * Copy
     **/
    virtual Pattern* Clone() const = 0;

    /**
     * Destructor
     **/
    virtual ~Pattern()
    {
    }

    /**
     * Return the size of the feature space
     **/
    virtual Index GetSize() const = 0;

    /**
     * Return the name of the pattern
     **/
    inline const std::string& GetName() const
    {
        return name;
    }

    /**
     * Return the domain of the pattern
     **/
    inline const std::string& GetDomain() const
    {
        return domain;
    }

    /**
     * Return the name of the pattern
     **/
    inline void SetName(const std::string& name_)
    {
        name = name_;
    }

    /**
     * Return the domain of the pattern
     **/
    inline void SetDomain(const std::string& domain_)
    {
        domain = domain_;
    }

    /************************************************************
     * Other functions.
     ************************************************************/
    /**
     * Clear the pattern
     **/
    virtual void Clear() = 0;

    virtual bool Equals(const Pattern* pattern) const = 0;

    virtual Value EuclideanDist(const Pattern* p) const = 0;
    virtual Value DotProduct(const Pattern* p) const = 0;
    virtual Value CosineSimilarity(const Pattern* p) const = 0;
    virtual Value Mod() const = 0;
    /**
     * Copy the pattern content into a vector of features.
     * Size is the size of each unary-pattern. If size is zero the vector
     * will be allocated to accomodate the highest available feature ID.
     * The feature ID must be a postive integer.
     **/
    virtual void ToVector(std::vector<Value>* vec, int size) const = 0;
    virtual void ToSparseVector(
            std::vector<std::pair<Index, Value> >* vec, const Index max_index) const = 0;
    virtual FeatureIndex MaxFeatureId() const = 0;

    /************************************************************
     * I/O
     ************************************************************/
    virtual bool Save(std::ostream& os) const = 0;
    virtual bool Load(std::istream& is) = 0;
    std::string ToString() const;
    virtual void Print() const;

protected:
    // I/O of the common parts.
    virtual bool SaveInfo(std::ostream& os) const;
    virtual bool LoadInfo(std::istream& is);

    // Utility function called by Copy in derived classes
    virtual void CopyInfo(const Pattern* pattern);

private:
    /**
     * Name of the pattern
     **/
    std::string name;
    /**
     * Domain of the pattern
     **/
    std::string domain;
}; // end Pattern

/**
 * Class to represent an input DensePattern.
 **/
class DensePattern : public Pattern
{
private:
    /**
     * The feature representation of the pattern.
     **/
    typedef std::vector<Value> DataContainer;
    DataContainer data;

public:

    /**
     * Constructors.
     **/
    DensePattern()
    {
        this->Clear();
    }

    DensePattern(const std::string& name_, const std::string& domain_) : Pattern(name_, domain_)
    {
        this->Clear();
    }

    /**
     * Copy
     **/
    virtual Pattern* Clone() const;

    /**
     * Clear
     **/
    virtual void Clear();

    /**
     * Destructor
     **/
    virtual ~DensePattern()
    {
        this->Clear();
    }
    /**********************************************
     * Accessors and Mutators
     **********************************************/

    /**
     * Return the i-th feature of the pattern
     **/
    inline Value Get(const Index& i) const
    {
        return data[i];
    }

    /**
     * Adds an element at the end of the data container.
     */
    inline bool Add(Value value)
    {
        data.push_back(value);
        return true;
    }

    /**
     * Return the size of the feature space
     **/
    inline Index GetSize() const
    {
        return data.size();
    }

    inline const DataContainer& GetData() const {
        return data;
    }

    /************************************************************
     * Other functions.
     ************************************************************/
    /**
     * Check if two pattern are equals
     **/
    virtual bool Equals(const Pattern* pattern) const;

    virtual Value EuclideanDist(const Pattern* p) const;
    virtual Value DotProduct(const Pattern* p) const;
    virtual Value CosineSimilarity(const Pattern* p) const;
    virtual Value Mod() const;
    /**
     * Copy the pattern content into a vector of features.
     **/
    virtual void ToVector(std::vector<Value>* vec, int size) const;
    virtual void ToSparseVector(
            std::vector<std::pair<Index, Value> >* vec, const Index max_index) const;
    virtual FeatureIndex MaxFeatureId() const;

    virtual bool Save(std::ostream& os) const;
    virtual bool Load(std::istream& is);
}; // end DensePattern

/**
 * Class to represent an input SparsePattern.
 **/
class SparsePattern : public Pattern {
public:
    typedef FeatureIndex Key;

private:
    /**
     * The feature representation of the pattern.
     **/
    typedef std::vector<std::pair<FeatureIndex, Value> > DataContainer;
    DataContainer data;

public:

    /**
     * Constructors.
     **/
    class Iterator
    {
    private:
        SparsePattern::DataContainer::const_iterator iter;
        SparsePattern::DataContainer::const_iterator end;
        SparsePattern::DataContainer::const_iterator begin;

    public:

        Iterator(const SparsePattern& p)
        {
            this->Reset(p);
        }

        inline bool HasNext() const
        {
            return (iter != end);
        }

        inline const std::pair<FeatureIndex, Value>* GetNext() {
            if (HasNext()) {
                const std::pair<FeatureIndex, Value>* ret = &(*iter);
                ++iter;
                return ret;
            }

            return NULL;
        }

        // Faster but unsafe GetNext.
        inline void GetNext(FeatureIndex* key, Value* value)
        {
            *key = (iter->first);
            *value = (iter->second);
            ++iter;
        }

        void Reset(const SparsePattern& p)
        {
            end = p.data.end();
            begin = p.data.begin();
            iter = p.data.begin();
        }

        void Rewind()
        {
            iter = begin;
        }
    };
    friend class Iterator;

    SparsePattern()
    {
        this->Clear();
    }

    SparsePattern(const std::string& name_, const std::string& domain_) : Pattern(name_, domain_)
    {
        this->Clear();
    }

    /**
     * Copy
     **/
    virtual Pattern* Clone() const;

    /**
     * Clear
     */
    virtual void Clear();

    /**
     * Destructor
     **/
    virtual ~SparsePattern()
    {
        this->Clear();
    }
    /**********************************************
     * Accessors and Mutators
     **********************************************/
    /**
     * Adds an element at the end of the data container.
     */
    virtual bool Add(const FeatureIndex& i, Value value)
    {
        // Input features must be in increasing order to allow operations like
        // dot product via a linear scanning.
        if (!data.empty()) {
            CHECK_GT(i, data.back().first);
        }
        data.push_back(std::pair<FeatureIndex, Value>(i, value));
        return true;
    }

    /**
     * Return the size of the feature space
     **/
    inline Index GetSize() const
    {
        return data.size();
    }

    inline const DataContainer& GetData() const {
        return data;
    }
    /************************************************************
     * Other functions.
     ************************************************************/
    /**
     * Check if two pattern are equal
     **/
    virtual bool Equals(const Pattern* pattern) const;

    virtual Value EuclideanDist(const Pattern* p) const;
    virtual Value DotProduct(const Pattern* p) const;
    virtual Value CosineSimilarity(const Pattern* p) const;
    virtual Value Mod() const;
    /**
     * Copy the pattern content into a vector of features.
     **/
    virtual void ToVector(std::vector<Value>* vec, int size) const;
    virtual void ToSparseVector(
            std::vector<std::pair<Index, Value> >* vec, const Index max_index) const;
    virtual FeatureIndex MaxFeatureId() const;

    virtual bool Save(std::ostream& os) const;
    virtual bool Load(std::istream& is);
}; // end SparsePattern

/**
 * Class to represent an input anryDensePattern.
 **/
class NaryDensePattern : public Pattern
{
private:

    /**
     * The feature representation of the NaryPattern.
     **/
    typedef std::vector<const DensePattern*> PatternsContainer;
    PatternsContainer patternsContainer;

public:

    /**
     * Constructors.
     **/
    NaryDensePattern()
    {
        this->Clear();
    }

    NaryDensePattern(const std::string& name_, const std::string& domain_) : Pattern(name_, domain_)
    {
        this->Clear();
    }

    /**
     * Copy
     **/
    virtual Pattern* Clone() const;

    /**
     * Clear
     **/
    virtual void Clear();

    /**
     * Destructor
     **/
    virtual ~NaryDensePattern()
    {
        this->Clear();
    }
    /**********************************************
     * Accessors and Mutators
     **********************************************/

    /**
     * Return the i-th pattern
     **/
    inline const DensePattern* Get(const Index& i) const
    {
        return patternsContainer[i];
    }

    /**
     * Add a pattern to the NaryPattern
     **/
    inline bool Add(const DensePattern* pattern)
    {
        patternsContainer.push_back(pattern);
        return true;
    }

    /**
     * Return the size of the NaryPattern
     **/
    inline Index GetSize() const
    {
        return patternsContainer.size();
    }


    /************************************************************
     * Other functions.
     ************************************************************/
    /**
     * Check if two pattern are equal
     **/
    virtual bool Equals(const Pattern* pattern) const;

    virtual Value EuclideanDist(const Pattern* p) const;
    virtual Value DotProduct(const Pattern* p) const;
    virtual Value CosineSimilarity(const Pattern* p) const;
    virtual Value Mod() const;
    /**
     * Copy the pattern content into a vector of features.
     **/
    virtual void ToVector(std::vector<Value>* vec, int size) const;
    virtual void ToSparseVector(
            std::vector<std::pair<Index, Value> >* vec, const Index max_index) const;
    virtual FeatureIndex MaxFeatureId() const;

    virtual bool Save(std::ostream& os) const;
    virtual bool Load(std::istream& is);
}; // end NaryDensePattern

/**
 * Class to represent an input NarySparsePattern.
 **/
class NarySparsePattern : public Pattern
{
private:
    /**
     * The feature representation of the NaryPattern.
     **/
    typedef std::vector<const SparsePattern*> PatternsContainer;
    PatternsContainer patternsContainer;

public:

    /**
     * Constructors.
     **/
    NarySparsePattern()
    {
        this->Clear();
    }

    NarySparsePattern(const std::string& name_, const std::string& domain_) :
        Pattern(name_, domain_)
    {
        this->Clear();
    }

    /**
     * Copy
     **/
    virtual Pattern* Clone() const;

    /**
     * Clear
     **/
    virtual void Clear();

    /**
     * Destructor
     **/
    virtual ~NarySparsePattern()
    {
        this->Clear();
    }
    /**********************************************
     * Accessors and Mutators
     **********************************************/

    /**
     * Return the i-th pattern
     **/
    inline const SparsePattern* Get(const Index& i) const
    {
        return patternsContainer[i];
    }

    /**
     * Return the mutable i-th pattern
     **/
    inline SparsePattern* const GetMutable(const Index& i) {
        return const_cast<SparsePattern*>(patternsContainer[i]);
    }

    /**
     * Add a pattern to the NaryPattern
     **/
    inline bool Add(const SparsePattern* pattern)
    {
        patternsContainer.push_back(pattern);
        return true;
    }

    /**
     * Return the size of the NaryPattern
     **/
    inline Index GetSize() const
    {
        return patternsContainer.size();
    }

    /************************************************************
     * Other functions.
     ************************************************************/
    /**
     * Check if two pattern are equal
     **/
    virtual bool Equals(const Pattern* pattern) const;

    virtual Value EuclideanDist(const Pattern* p) const;
    virtual Value DotProduct(const Pattern* p) const;
    virtual Value CosineSimilarity(const Pattern* p) const;
    virtual Value Mod() const;
    /**
     * Copy the pattern content into a vector of features.
     * Size is the size of each unary-pattern. This means that the
     * resulting vector will be n-arity*size. The ID of the feature
     * must be a postive integer.
     **/
    virtual void ToVector(std::vector<Value>* vec, int size) const;
    virtual void ToSparseVector(
            std::vector<std::pair<Index, Value> >* vec, const Index max_index) const;
    virtual FeatureIndex MaxFeatureId() const;

    virtual bool Save(std::ostream& os) const;
    virtual bool Load(std::istream& is);
}; // end NarySparsePattern

/**
 * Class to represent an input DensePattern.
 **/
class MapPattern : public Pattern
{
public:

    /**
     * Constructors.
     **/
    MapPattern()
    {
        this->Clear();
    }

    MapPattern(const std::string& name_, const std::string& domain_) : Pattern(name_, domain_)
    {
    }

    /**
     * Copy
     **/
    virtual Pattern* Clone() const;

    /**
     * Clear
     **/
    virtual void Clear();

    /**
     * Destructor
     **/
    virtual ~MapPattern() {
    }

    /************************************************************
     * Other functions.
     ************************************************************/
    /**
     * Check if two pattern are equals
     **/
    virtual bool Equals(const Pattern* pattern) const;

    virtual Value EuclideanDist(const Pattern* p) const;
    virtual Value DotProduct(const Pattern* p) const;
    virtual Value CosineSimilarity(const Pattern* p) const;
    virtual Value Mod() const;
    virtual FeatureIndex MaxFeatureId() const;

    virtual bool Save(std::ostream& os) const;
    virtual bool Load(std::istream& is);
}; // end MapPattern
}
#endif /* PATTERN_H */
