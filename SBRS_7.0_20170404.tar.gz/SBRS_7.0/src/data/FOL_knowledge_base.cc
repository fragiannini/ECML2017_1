#include "data/FOL_knowledge_base.h"

#include <fstream>
#include <sstream>

#include "utils/gflags/gflags/gflags.h"
#include "utils/stl_utils.h"  // for DeallocVectorOfPointers
#include "utils/string_utils.h"


namespace Regularization {

/******************************
 * Copy constructors
 *****************************/
FOLKnowledgeBase::FOLKnowledgeBase(const FOLKnowledgeBase& FOL_KnowledgeBase) {
    for (Formulas::const_iterator it = FOL_KnowledgeBase.formulas.begin();
            it != FOL_KnowledgeBase.formulas.end(); ++it)
    {
        this->Add(*(*it)->Clone());
    }
}

/********************************
 * Destructors
 ********************************/
FOLKnowledgeBase::~FOLKnowledgeBase()
{
    this->Clear();
}

/**********************************************
 * Accessors and Mutators
 **********************************************/

/**
 * Add a formula to the knowledge base
**/
bool FOLKnowledgeBase::Add(const FOLFormula& formula) {
    formulas.push_back(&formula);
    return true;
}

/**
 * Clear all knowledge base
**/
void FOLKnowledgeBase::Clear() {
    std::DeallocVectorOfPointers(&formulas);
    formulas.clear();
}

/**
 * Check if a formula is already present in knowledge base
**/
bool FOLKnowledgeBase::HasFormula(const std::string& formula_str) const {
    for (int i = 0; i < this->Size(); ++i) {
        if (this->Get(i).GetName() == formula_str) {
            return true;
        }
    }

    return false;
}

/**
 * Check if a formula is already present in knowledge base
**/
bool FOLKnowledgeBase::HasFormula(const FOLFormula& formula) const {
    for (int i = 0; i < this->Size(); ++i) {
        if (this->Get(i).Equals(formula)) {
            return true;
        }
    }

    return false;
}

/**
 * Load from file
 **/
bool FOLKnowledgeBase::LoadKnowledgeBase(const std::string& filename, const Dataset& dataset,
                                         const Predicates& predicates, const bool clear) {
    std::ifstream ifs(filename.c_str());

    if (!ifs.is_open()) {
        WARN("Could not open the file " << filename);
        return false;
    }

    bool ret = this->LoadKnowledgeBaseFromStream(ifs, dataset, predicates, clear);
    ifs.close();
    return ret;
}

/**
 * Load from stream (rules)
 **/
bool FOLKnowledgeBase::LoadKnowledgeBaseFromStream(
        std::istream& is,
        const Dataset& dataset,
        const Predicates& predicates,
        const bool clear) {
    if (clear) {
        this->Clear();
    }

    std::string line;
    std::vector<std::string> ruleVector;
    unsigned int lineCounter = static_cast<int>(0);

    while (!is.eof()) {
        line.clear();
        ruleVector.clear();
        getline(is, line);
        lineCounter++;
        StringUtils::RemoveSpacesAtStartAndEndOfString(&line);

        // skip empty lines and carriage return
        if (line.empty()) {
            continue;
        }

        // skip comment line
        if (line.find('#') == 0) {
            continue;
        }

        // search for invalid character, the second parameter are valid ASCII symbols
        if (!StringUtils::IsAlphaNumericOrInSet(line, "=>-*[](),;:/+_ .")) {
            WARN("Invalid character used, see the rules file at line " << lineCounter <<
                 ":" << line);
            return false;
        }

        const int num_semicolomn = StringUtils::CharCounter(line, ';');
        if (num_semicolomn < 1 || num_semicolomn > 6) {
            WARN("Invalid number of ; see the rules file at line " << lineCounter <<
                 ":" << line);
            return false;
        }

        StringUtils::SplitToVector(line, &ruleVector, ";", false);

        // parser error; check the correct split of the line
        if (ruleVector.size() < 2 || ruleVector.size() > 7) {
            WARN("Wrong number of fields " << ruleVector.size() <<
                 " rewrite the FOL rule in appropriate form, see the file of the " <<
                 " rules at line " << lineCounter << ":" << line);
            return false;
        }

        // create new formula
        FOLFormula* formula = new FOLFormula(ruleVector[0]);
        // parameters setting
        const std::string rule_type = ruleVector[1];
        std::string quantifier_conversion_norm;
        std::string propositional_conversion_norm;
        std::string lambda;
        std::string priority;
        std::string optimization_predicate;

        if (ruleVector.size() >= 3) {
            quantifier_conversion_norm = ruleVector[2];
        }

        if (ruleVector.size() >= 4) {
            propositional_conversion_norm = ruleVector[3];
        }

        if (ruleVector.size() >= 5) {
            lambda = ruleVector[4];
        }

        if (ruleVector.size() >= 6) {
            priority = ruleVector[5];
        }

        if (ruleVector.size() >= 7) {
            optimization_predicate = ruleVector[6];
        }

        // split the PRENEX normal form in the vector of quantified variables and in the quantifier-free part (CNF)
        if (!formula->Load(ruleVector[0], predicates, optimization_predicate)) {
            WARN("Can not load the rule at line " << lineCounter << ":" << line);
            return false;
        }

        // set the parameters of the formula
        if (!formula->SetParameters(rule_type, quantifier_conversion_norm,
                                    propositional_conversion_norm, lambda, priority)) {
            WARN("Invalid type of FOL formula, see the file of rules at line " <<
                 lineCounter << ":" << line);
            return false;
        }

        // check if the FOL formula is already provided
        if (this->HasFormula(*formula)) {
            WARN("Formula " << formula->ToString() << " already inserted, see the " <<
                 "file of the rules at line " << lineCounter << ":" << line);
            return false;
        }

        // add the formula to the knowledge base
        CHECK_WITH_MESSAGE(this->Add(*formula), "Can not add the FOL formula");
    }

    return true;
}

/**
 * Save to a stream
 **/
bool FOLKnowledgeBase::SaveToStream(std::ostream& os) const
{
    if (this->Size() < 0) {
        return false;
    }  else if (this->Size() == 0) {
        os << "The knowledge base is empty" << std::endl;
    }
    bool ret = true;

    for (int i = 0; i < this->Size(); ++i) {
        const FOLFormula& formula = this->Get(i);
        ret &= formula.Save(os);
        os << std::endl;
    }

    return ret;
}

/**
 * Save to a file
 **/
bool FOLKnowledgeBase::Save(const std::string& filename) const
{
    std::ofstream ofs(filename.c_str());

    if (!ofs.is_open())
    {
        WARN("Could not open the file " << filename);
        return false;
    }

    return this->SaveToStream(ofs);
}

/**
 * Print FOL KnowledgeBase info to stdout
 **/
void FOLKnowledgeBase::Print() const {
    this->SaveToStream(std::cout);
}

/**
 * Print FOL KnowledgeBase info to stdout
 **/
std::string FOLKnowledgeBase::ToString() const
{
    std::ostringstream os;
    this->SaveToStream(os);
    return os.str();
}

}  // end Regularization
