#include "predicate.h"
#include "utils/general.h"
#include "utils/string_utils.h"


namespace Regularization {

Predicate::Predicate(const Function::ID& name_, const Domains& domains_,
          const std::string& predicateType_, const std::string& problemType_,
          const std::string& defaultTrueValue_) {
    name = name_;
    // store the input domains for the variables of the predicate
    domains = domains_;
    for (Domains::const_iterator iter = domains.begin(); iter != domains.end(); ++iter) {
        CHECK_EQ_WITH_MESSAGE(StringUtils::CharCounter(*iter, '_'), 0,
            "Domain names should not contain underscores, as the act as separators for domains of "
            "n-ary predicates");
    }
    domain_str = StringUtils::ContainerToString(domains, "_", "");
    CHECK(!domain_str.empty());

    // set the flags for predicate
    predicateType = Function::TypeFromStringOrDie(predicateType_);
    problemType = Predicate::ProblemTypeFromStringOrDie(problemType_);
    defaultTruthValue = Predicate::DefaultTruthValueFromStringOrDie(defaultTrueValue_);
}


std::string Predicate::ToString() const {
    std::ostringstream os;
    CHECK(this->Save(os));
    return os.str();
}

/**
 * Save to a stream
 **/
bool Predicate::Save(std::ostream& os) const
{
    os << "(" << StringUtils::VectorToString(domains, ",", "") << ");";
    os << Function::TypeToString(predicateType) << ";";
    os << Predicate::ProblemTypeToString(problemType) << ";";
    os << Predicate::DefaultTruthValueToString(defaultTruthValue) << std::endl;
    return true;
}

/**
 * Print to stdout
 **/
void Predicate::Print() const
{
    this->Save(std::cout);
}

}
