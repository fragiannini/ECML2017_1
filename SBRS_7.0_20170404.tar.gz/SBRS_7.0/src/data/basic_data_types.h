/*
 * basic_data_types.h
 *
 *  Created on: Dec 21, 2013
 *      Author: michi
 *
 *  Definitions of the basic data types to be used across the project.
 */

#ifndef BASIC_DATA_TYPES_H_
#define BASIC_DATA_TYPES_H_

#if __USE_BOOST_INT128__ > 0
#include <boost/multiprecision/cpp_int.hpp>
#include "data/uint128_std_support.h"
#elif __USE_GCC_INT128__ > 0
#include "data/uint128_std_support.h"
#endif

// By default we save memory at the expense of a lower numeric precision.
#ifndef __LOW_MEMORY_USAGE__
#define __LOW_MEMORY_USAGE__ 1
#endif

namespace Regularization {
#if __LOW_MEMORY_USAGE__ > 0
typedef float Value;
typedef unsigned int Index;
// This silently limits the number of features to 16000! This is too low for many applications.
// Use int whenever needed.
typedef short int FeatureIndex;
// typedef int FeatureIndex;
#else
typedef double Value;
typedef unsigned long Index;
typedef std::string FeatureIndex;
#endif

#if __USE_BOOST_INT128__ > 0
typedef boost::multiprecision::uint128_t LogicCardinalityIndex;
#elif __USE_GCC_INT128__ > 0
typedef __int128 LogicCardinalityIndex;
#else
typedef unsigned long long int LogicCardinalityIndex;
#endif
}  // end Regularization

#endif /* BASIC_DATA_TYPES_H_ */
