/*
 * File:   predicates.h
 * Author: Tore
 *
 * Created on 12 ottobre 2010, 14.40
 */

#ifndef PREDICATES_H
#define	PREDICATES_H

#include<map>

#include "classifier/functions/function.h"
#include "data/predicate.h"


namespace Regularization {

class Dataset;

/******************************************************************************
 * class for all predicates
 * predicate definition directive (PDD)
 * DEF name(d1,...,dn);{LEARN,GIVEN};{C,R};{T,F,DC}
 * (For instance DEF A(d1,d2,...,dn);LEARN|GIVEN;C|R;T|F|DC)
 ******************************************************************************/

/**
 * Collects a set of predicates.
 **/
class Predicates
{
    public:
        /**
         * The predicates. First element is the name of a predicate, the second one
         * is the correspondent class.
         **/
        typedef std::map<Function::ID, Predicate> PredicatesMap;

        /**
         * The vector contains the predicates that have the same domain. The pair is
         * the vector of the names of the predicates and the correspondent vector of
         * the domain.
         **/
        typedef std::vector<std::pair<std::vector<Function::ID>, std::vector<std::string> > > PerDomainPredicates;

        /*
         * The map of given predicates used in optimization. The first element is
         * the name of the predicate while the second its negation
         */
        typedef std::map<Function::ID, bool> GivenPredicatesOptimization;

        /*
         * The map of the predicates and their type. The key is the name of the
         * predicate while the value is the corresponding type of predicate
         */
        typedef std::map<Function::ID, Function::TYPE> PredicatesType;

        /********************************
         * Constructors.
         ********************************/
        Predicates();
        Predicates(const std::string& filename);

        /********************************
         * Destructors.
         ********************************/
        ~Predicates();

        /**********************************************
         * Accessors and Mutators
         **********************************************/

        /**
         * Clear the map of the predicates
         **/
        void Clear();

        /**
         * Returns the class predicate from the map PredicatesMap
         * safe version
         **/
        inline const Predicate* Get(const Function::ID& id) const
        {
            PredicatesMap::const_iterator iter = predicatesMap.find(id);
            if (iter == predicatesMap.end())
                return NULL;

            return &iter->second;
        }

        /**
         * Returns the class predicate from the map PredicatesMap
         * unsafe version
         **/
        inline Predicate* GetMutable(const Function::ID& id)
        {
            PredicatesMap::iterator iter = predicatesMap.find(id);

            if (iter == predicatesMap.end())
                return NULL;

            return &iter->second;
        }

        /**
         * Returns the vector of EqualPredicate
         **/
        inline const PerDomainPredicates& GetPerDomainPredicates() const
        {
            return per_domain_predicates;
        }

        /**
         * Returns the map of the predicates
         **/
        inline const PredicatesMap& GetPredicatesMap() const
        {
            return predicatesMap;
        }

        /**
         * Set the class predicate in the map PredicatesMap
         **/
        inline bool Set(const Function::ID& id, const Predicate& predicate)
        {
            predicatesMap[id] = predicate;
            return true;
        }

        /*
         * Set the association between the predicate and function
         */
        /* bool SetAssociaton(
            const Classifier::FunctionContainer& functionsContainer); */

        /********************************
         * Counters
         ********************************/

        /**
         * Return the size of the map
         **/
        inline int Size() const
        {
            return static_cast<int> (predicatesMap.size());
        }

        /**
         * Predicates Const Iterator.
         **/
        class Iterator
        {
            private:
                PredicatesMap::const_iterator iter;
                const Predicates* predicates;

            public:

                Iterator(const Predicates& p)
                {
                    predicates = &p;
                    iter = predicates->predicatesMap.begin();
                }

                inline bool HasNext() const
                {
                    return (iter != predicates->predicatesMap.end());
                }

                inline const Predicate* GetNext()
                {
                    if (HasNext())
                    {
                        const Predicate& ret = iter->second;
                        ++iter;
                        return &ret;
                    }

                    return NULL;
                }

                void Reset(const Predicates& p)
                {
                    iter = predicates->predicatesMap.begin();
                }
        };

        /*
         * Predicates mutable iterator
         */
        class MutableIterator
        {
            private:
                PredicatesMap::iterator iter;
                Predicates* predicates;

            public:

                MutableIterator(Predicates* p)
                {
                    predicates = p;
                    iter = predicates->predicatesMap.begin();
                }

                inline bool HasNext() const
                {
                    return (iter != predicates->predicatesMap.end());
                }

                inline Predicate* GetNext()
                {
                    if (HasNext())
                    {
                        Predicate* ret = &iter->second;
                        iter++;
                        return ret;
                    }

                    return NULL;
                }

                void Reset()
                {
                    iter = predicates->predicatesMap.begin();
                }
        };

        friend class Iterator;
        friend class MutableIterator;

        /***********************************************************
         * I/O
         ************************************************************/
        /**
         * Load predicates, if dataset=NULL is empty no consistency checks are enforced.
         **/
        bool LoadFromFile(const std::string& filename, const Dataset* dataset, const bool clear = true);
        bool LoadFromStream(std::istream& is, const Dataset* dataset, const bool clear = true);

        bool SaveToFile(const std::string& filename) const;
        bool SaveToStream(std::ostream& os) const;
        void Print() const;
        std::string ToString() const;

    protected:
        /*
         * Set the pre_domain_predicate predicate i.e. the predicates that share the same domain
         */
        bool SetPerDomainPredicate(const Function::ID& id);

        PredicatesMap predicatesMap;
        PerDomainPredicates per_domain_predicates;
}; // end Predicates

}  // end Regularization

#endif	/* PREDICATES_H */
