#include "data/FOL_formula.h"

#include <algorithm>  // for std::find()
#include <deque>
#include <sstream>

#include "data/dataset.h"
#include "data/predicates.h"
#include "utils/general.h"
#include "utils/parse_utils.h"
#include "utils/string_utils.h"


using namespace Regularization;

FOLFormula::FOLFormula(const std::string& name_) :
        name(name_),
        ruleType(LEARN),
        quantifier_conversion_norm(L1),
        propositional_conversion_norm(PRODUCT_TNORM),
        universallyQuantified(false),
        has_exists_n(false),
        lambda(0), priority(0) {
}

// Set the parameters of the formula
bool FOLFormula::SetParameters(const std::string& ruleType_, const std::string& quantifier_conversion_norm_,
        const std::string& propositional_conversion_norm_, const std::string& lambda_,
        const std::string& priority_) {
    // sets the flags
    if (ruleType_ == "LEARN") {
        ruleType = LEARN;
    } else if (ruleType_ == "VERIFY") {
        ruleType = VERIFY;
    } else {
        WARN("Error: invalid type of rule, see the file of rule for formula " << name << std::endl);
        return false;
    }

    // sets the flags
    if (quantifier_conversion_norm_ == "LINF") {
        quantifier_conversion_norm = LINF;
    } else if (quantifier_conversion_norm_ == "L1") {
        quantifier_conversion_norm = L1;
    } else if (quantifier_conversion_norm_ == "L2") {
        quantifier_conversion_norm = L2;
    } else {
        WARN("Error: invalid type of quantifier conversion norm " << quantifier_conversion_norm_ <<
             ", see the file of rule for formula " << name);
        return false;
    }

    // sets the flags
    if (propositional_conversion_norm_ == "PRODUCT_TNORM") {
        propositional_conversion_norm = PRODUCT_TNORM;
    } else if (propositional_conversion_norm_ == "MINIMUM_TNORM") {
        propositional_conversion_norm = MINIMUM_TNORM;
    } else if (propositional_conversion_norm_ == "LUKASIEWICZ_TNORM") {
        propositional_conversion_norm = LUKASIEWICZ_TNORM;
    } else if (propositional_conversion_norm_ == "WEAK_LUKASIEWICZ_TNORM") {
        propositional_conversion_norm = WEAK_LUKASIEWICZ_TNORM;
    } else {
        WARN("Unknown conversion norm " << propositional_conversion_norm_ <<
             ", see the file of rule for formula " << name);
        return false;
    }

    // set the lambda and the priority of the constraint
    if (!StringUtils::FromString<Value>(lambda_, &lambda)) {
        lambda = static_cast<Value>(1);
        WARN("Error: invalid value for lambda selected 1, see the file of rule for formula " << name);
        return false;
    }

    if (!StringUtils::FromString<unsigned int>(priority_, &priority)) {
        WARN("Error: invalid value for priority selected, see the file of rule for formula " << name);
        return false;
    }
    return true;
}

bool FOLFormula::Literal::Load(const std::string& str) {
    valid = false;  // init to false;

    // Remove all spaces.
    std::string normalized_str = StringUtils::RemoveSpacesAtStartAndEndOfString(str);

    if (StringUtils::CharCounter(normalized_str, '(') != 1) {
        WARN("Wrong number of (, wrong literal name " << normalized_str);
        return false;
    }
    if (StringUtils::CharCounter(normalized_str, ')') != 1) {
        WARN("Wrong number of ), wrong literal name " << normalized_str);
        return false;
    }

    const int pos1 = normalized_str.find('(');
    const int pos2 = normalized_str.find(')');
    if (pos1 >= pos2) {
        WARN("( should precede ), wrong literal name " << normalized_str);
        return false;
    }
    const std::string predicate_variables_str =
            normalized_str.substr(pos1 + 1, pos2 - pos1 - 1);
    StringUtils::SplitToVector(predicate_variables_str, &predicateVariables, ',', false);
    if (predicateVariables.empty()) {
        WARN("No predicate variables found in " << predicate_variables_str <<
             " wrong literal name " << normalized_str);

        return false;
    }

    std::set<std::string> inserted_variables;
    for (unsigned int i = 0; i < predicateVariables.size(); ++i) {
        if (predicateVariables[i].empty()) {
            WARN("Empty predicate variable name used in " << i <<
                 "-th literal variable from " << predicate_variables_str <<
                 " in literal definition " << normalized_str);
            return false;
        }
        if (!StringUtils::IsAlphaNumeric(predicateVariables[i])) {
            WARN("Invalid predicate variable name used in " << i <<
                 "-th literal variable from " << predicate_variables_str <<
                 " in literal definition " << normalized_str);
            return false;
        }
        if (inserted_variables.find(predicateVariables[i]) != inserted_variables.end()) {
            WARN("Variable " << predicateVariables[i] << " for predicate " <<
                 id << " already used, line " << normalized_str);
            return false;
        }

        // insert the variable in the set of the variables for the predicate
        inserted_variables.insert(predicateVariables[i]);
    }

    id = normalized_str.substr(0, pos1);
    if (id.empty()) {
        WARN("Empty literal name in literal definition " << normalized_str);
        return false;
    }
    // search for invalid character, the second parameter are valid ASCII symbols
    if (!StringUtils::IsAlphaNumericOrInSet(id, "./+_=>-*")) {
        WARN("Invalid character used in literal name " << id <<
             " in literal definition " << normalized_str);
        return false;
    }

    valid = true;
    return true;
}

std::string FOLFormula::Literal::ToString() const {
    if (!valid) return "";

    std::ostringstream os;
    os << id << "(" << StringUtils::VectorToString(predicateVariables, ",", "") << ")";
    return os.str();
}

std::string FOLFormula::PropositionalFormula::ToString() const {
    if (!valid) {
        return "";
    }

    std::ostringstream os;
    os << "[";
    const std::string logic_connective_str =
            logic_connective + (!logic_connective.empty() ? " " : "");
    if (literal.IsValid()) {
        os << logic_connective_str << literal.ToString();
    } else if (subformulas.size() == 1) {
        os << logic_connective_str << subformulas[0].ToString();
    } else {
        for (int i = 0; i < static_cast<int>(subformulas.size() - 1); ++i) {
            os << subformulas[i].ToString() << " " << logic_connective_str;
        }
        os << subformulas.back().ToString();
    }
    os << "]";
    return os.str();
}

bool FOLFormula::Literal::Equals(const FOLFormula::Literal& literal) const {
    if (this->valid != literal.valid) {
        return false;
    }
    if (this->id != literal.id ||
        this->predicateVariables.size() != literal.predicateVariables.size()) {
        return false;
    }

    for (unsigned int i = 0; i < this->predicateVariables.size(); ++i) {
        if (this->predicateVariables[i] != literal.predicateVariables[i]) {
            return false;
        }
    }

    return true;
}

bool FOLFormula::PropositionalFormula::Equals(const PropositionalFormula& formula) const {
    if (!literal.Equals(formula.GetLiteral()) ||
        logic_connective != formula.GetLogicConnective() ||
        subformulas.size() != formula.GetSubFormulas().size()) {
        return false;
    }
    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        if (!subformulas[i].Equals(formula.GetSubFormulas()[i])) {
            return false;
        }
    }
    return true;
}

void FOLFormula::PropositionalFormula::PopulateInvolvedIds() {
    if (literal.IsValid()) { ids.insert(literal.GetId()); }

    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        subformulas[i].PopulateInvolvedIds();
        ids.insert(subformulas[i].ids.begin(), subformulas[i].ids.end());
    }
}

void FOLFormula::PropositionalFormula::GetAllLiterals(std::vector<const Literal*>* literals) const {
    if (literal.IsValid()) {
        literals->push_back(&literal);
    }
    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        subformulas[i].GetAllLiterals(literals);
    }
}

void FOLFormula::PropositionalFormula::GetAllVariables(std::set<std::string>* variables) const {
    if (literal.IsValid()) {
        const std::vector<std::string>& literal_variables = literal.GetPredicateVariables();
        for (unsigned int v = 0; v < literal_variables.size(); ++v) {
            variables->insert(literal_variables[v]);
        }
    }
    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        subformulas[i].GetAllVariables(variables);
    }
}
bool FOLFormula::PropositionalFormula::Load(const std::string& str) {
    using namespace ParseUtils;
    using namespace StringUtils;

    valid = false;
    if ((CharsCounter(str, "[]") % 2) != 0) {
        WARN("Expression " << str << " has a non-even number of square brackets");
        return false;
    }
    if ((CharsCounter(str, "()") % 2) != 0) {
        WARN("Expression " << str << " has a non-even number of round brackets");
        return false;
    }

    std::string normalized_str = str;
    RemoveDuplicatedSpaces(&normalized_str);
    RemoveSpacesAtStartAndEndOfString(&normalized_str);
    Replace("[ ", "[", &normalized_str);
    Replace(" [", "[", &normalized_str);
    Replace("] ", "]", &normalized_str);
    Replace(" ]", "]", &normalized_str);

    const ParseTree parse_tree = GetParseTree(normalized_str, '[', ']', false);

    if (parse_tree.subtrees.size() == 0) {  // single literal
        if (StartsWith(normalized_str, "NOT", true)) {
            logic_connective = "NOT";
            normalized_str = RemoveSpacesAtStartAndEndOfString(normalized_str.substr(3));
        }
        if (!literal.Load(normalized_str)) {
            WARN("Wrong literal definition " << normalized_str);
            return false;
        }
        valid = true;
    } else if (parse_tree.subtrees.size() == 1) {
        if (static_cast<int>(parse_tree.connectives_str.size()) > 1) {
            WARN("Unexpected number of logic connectives in " << normalized_str);
            return false;
        }

        if (parse_tree.connectives_str.size() == 1) {
            logic_connective = RemoveSpacesAtStartAndEndOfString(
                    parse_tree.connectives_str[0]);
            if (logic_connective != "NOT") {
                WARN("Unexpected logic connective " << logic_connective << " in " <<
                     normalized_str);
                return false;
            }
        }

        subformulas.push_back(PropositionalFormula());
        if (!subformulas.back().Load(parse_tree.subtrees[0].root_str)) {
            WARN("Can not load subformula " << parse_tree.subtrees[0].root_str <<
                 " while parsing expression: " << normalized_str);
            return false;
        }

        valid = true;
    } else {
        // There are multiple subtrees. All correct connectives are binary and the expression
        // must start and end with a parse subtree.
        if (parse_tree.subtrees[0].root.first != 1) {   // Must start with [ and then the first parsed subtree.
            WARN("Expression " << normalized_str << " does not start by a parse subtree");
            return false;
        }
        if (parse_tree.subtrees.back().root.second !=
            static_cast<int>(normalized_str.length()) - 1) {
            // Must end with the first parsed subtree (and then a ]).
            WARN("Expression " << normalized_str << " does not end with a parse subtree " <<
                 parse_tree.subtrees.back().root.second << " " <<
                 static_cast<int>(normalized_str.length()) - 1);
            return false;
        }

        if (parse_tree.subtrees.size() - 1 != parse_tree.connectives_str.size()) {
            WARN("Expression " << normalized_str <<
                 " has an inconsistent number of subtrees and connectives");
            return false;
        }

        logic_connective = parse_tree.connectives_str[0];
        for (unsigned int i = 1; i < parse_tree.connectives_str.size(); ++i) {
            if (logic_connective != parse_tree.connectives_str[i]) {
                WARN("Logic connective " << parse_tree.connectives_str[i] <<
                     " differs from first connective" << logic_connective <<
                     " while parsing expression: " << normalized_str);
                return false;
            }
        }
        for (unsigned int i = 0; i < parse_tree.subtrees.size(); ++i) {
            subformulas.push_back(PropositionalFormula());
            if (!subformulas.back().Load(parse_tree.subtrees[i].root_str)) {
                WARN("Can not load subformula " << parse_tree.subtrees[i].root_str <<
                     " while parsing expression: " << normalized_str);
                return false;
            }
        }

        valid = true;
    }

    this->PopulateInvolvedIds();
    return valid;
}

/**
 * Split the PRENEX normal form in the vector of quantified variables and in the quantifier-free portion (propositional)
 **/
bool FOLFormula::Load(const std::string& rule,
                      const Predicates& predicates,
                      const std::string& optimization_predicate) {
    const std::string::size_type propositional_formula_start = rule.find('[');
    if (propositional_formula_start == std::string::npos) {
        WARN("Can not find start marked by '[' of the propositional formula at line " << rule);
        return false;
    }

    // set the vector of quantifiers and quantified variables
    if (!this->LoadQuantifiedVariables(rule.substr(0, propositional_formula_start))) {
        return false;
    }

    // set the quantifier-free portion (propositional) of the formula
    if (!this->LoadPropositionalFormula(rule.substr(propositional_formula_start), predicates)) {
        return false;
    }

    std::vector<const Literal*> literals;
    propositional_formula.GetAllLiterals(&literals);

    for (unsigned int i = 0; i < literals.size(); ++i) {
        const std::string id = literals[i]->GetId();
        const Predicate* predicate = predicates.Get(id);
        if (predicate == NULL) {
            WARN("Predicate " << literals[i]->GetId() << " not defined in the predicate definition at line " << rule);
            return false;
        }
        const std::vector<std::string>& variables = literals[i]->GetPredicateVariables();
        for (unsigned int v = 0; v < variables.size(); ++v) {
            const std::string& domain = predicate->GetDomain(v);
            VariablesDomains::const_iterator iter = variablesDomains.find(variables[v]);
            if (iter == variablesDomains.end()) {
                variablesDomains[variables[v]] = domain;
            } else if (iter->second != domain) {
                WARN("Variable " << variables[v] << " associated to multiple domains at line " << rule);
                return false;
            }
        }

        // check if the literal/predicate is given and add it to the map
        if (predicate->GetPredicateType() == Function::MAP_GIVEN && id == optimization_predicate) {
            givenLiteral = *(literals[i]);
        }
    }

    // check if the FOL Formula consists only of universal quantifier
    universallyQuantified = true;

    for (QuantifiedVariables::iterator it = quantifiedVariables.begin();
         it != quantifiedVariables.end(); ++it) {
        if (it->quantifier != forall) {
            universallyQuantified = false;
        }
        if (it->quantifier == exists_N) {
            // compute the value N automatically if it equal to 0
            CHECK_GT(it->quantifier_num, 0.0);
        }
    }

    // use given predicate/literal optimization
    if (givenLiteral.IsValid()) {
        const std::vector<std::string>& predicate_variables = givenLiteral.GetPredicateVariables();
        for (unsigned int i = 0; i < predicate_variables.size(); ++i) {
            if (predicate_variables[i] != quantifiedVariables[i].name) {
                WARN("The quantifier related to the variable " << predicate_variables[i] <<
                     " of the predicate " << givenLiteral.GetId() << " is not the outer one at line " << rule);
                return false;
            }
        }
    }

    return true;
}

/**
 * Set the vector of quantifiers and quantified variables
 **/
bool FOLFormula::LoadQuantifiedVariables(const std::string& quantifiedPortion_raw) {
    std::string quantifiedPortion = quantifiedPortion_raw;
    StringUtils::RemoveSpacesAtStartAndEndOfString(&quantifiedPortion);
    StringUtils::RemoveDuplicatedSpaces(&quantifiedPortion);

    // vector of quantifiers and quantified variables
    std::vector<std::string> quantifiersVector;
    StringUtils::SplitToVector(quantifiedPortion, &quantifiersVector, " ", 0);

    // parser error; check the correctness of the vector of quantified variables
    if (quantifiersVector.size() % 2 != 0) {
        WARN("Check the quantified portion of the formula");
        return false;
    }

    for (unsigned int i = 0; i < quantifiersVector.size() - 1; ++i) {
        // parser error; check if the second element is a variable
        if (quantifiersVector[i + 1].size() == 0) {
            WARN("Invalid quantified variable " << quantifiersVector[i + 1]);
            return false;
        }

        // parser error; check the name of variable
        for (unsigned j = 0; j < quantifiersVector[i + 1].size(); j++) {
            if (!islower(quantifiersVector[i + 1][j])) {
                WARN("Rewrite the variable " << quantifiersVector[i + 1] << " in lower case letters");
                return false;
            }
        }

        // parser error; check if a variable is already quantified
        for (unsigned l = 0; l < quantifiedVariables.size(); l++) {
            if (quantifiedVariables[l].name == quantifiersVector[i + 1]) {
                WARN("Variable " << quantifiersVector[i + 1] << " is already quantified");
                return false;
            }
        }

        if (quantifiersVector[i] == "forall") {
            quantifiedVariables.push_back(QuantifiedVariable(quantifiersVector[i + 1], forall, 0));
        } else if (quantifiersVector[i] == "exists") {
            quantifiedVariables.push_back(QuantifiedVariable(quantifiersVector[i + 1], exists, 1));
        } else if (quantifiersVector[i].find("_") != std::string::npos) {
            std::vector<std::string> exists_NVector;
            StringUtils::SplitToVector(quantifiersVector[i], &exists_NVector, "_", 0);
            // check the correctness of the exists_N quantifier
            double N = 0;

            if (exists_NVector.size() == 2 && exists_NVector[0] == "exists" &&
                StringUtils::FromString(exists_NVector[1], &N) && N > 0) {
                quantifiedVariables.push_back(QuantifiedVariable(quantifiersVector[i + 1], exists_N, N));
            } else {
                WARN("Invalid exists_N quantifier" << quantifiersVector[i]);
                return false;
            }
        } else {
            WARN("Invalid quantifier " << quantifiersVector[i]);
            return false;
        }

        ++i;
    }

    return true;
}

/**
 * Set the quantifier-free portion (propositional) of the formula
 **/
bool FOLFormula::LoadPropositionalFormula(
        const std::string& formula_str_raw, const Predicates& predicates) {
    if (formula_str_raw[0] != '[' && formula_str_raw.back() != ']') {
        WARN("Formula should be enclosed in [] at line " << formula_str_raw);
        return false;
    }
    // drop initial [ and last ]
    const std::string formula_str = formula_str_raw.substr(1, formula_str_raw.length() - 2);

    if (!propositional_formula.Load(formula_str)) {
        WARN("Wrong Formula at line " << formula_str);
        return false;
    }

    std::set<std::string> variables;
    propositional_formula.GetAllVariables(&variables);
    std::vector<const Literal*> literals;
    propositional_formula.GetAllLiterals(&literals);

    std::set<std::string> quantified_variables;
    for (QuantifiedVariables::const_iterator it = quantifiedVariables.begin();
         it != quantifiedVariables.end(); ++it) {
        if (variables.find(it->name) == variables.end()) {
            WARN("Quantified variable " << it->name << " is unused");
            return false;
        }
        quantified_variables.insert(it->name);
    }

    // parser error; check for unquantified variables
    for (std::set<std::string>::const_iterator it = variables.begin(); it != variables.end(); ++it) {
        if (quantified_variables.find(*it) == quantified_variables.end()) {
            WARN("Quantified variable " << *it << " is unquantified");
            return false;
        }
    }

    for (unsigned int i = 0; i < literals.size(); ++i) {
        const std::string& id = literals[i]->GetId();
        // parser error; check valid name of predicate in the definitions file
        if (predicates.Get(id) == NULL) {
            WARN("No predicate " << id << " defined, line " << formula_str);
            return false;
        }

        // parser error; check the consistency of the arity of the predicate
        if (static_cast<unsigned int>(literals[i]->GetPredicateVariables().size()) !=
            predicates.Get(id)->GetArity()) {
            WARN("Discrepancy in the arity of the literal " << id <<
                 " between the rules and the definitions, line " << formula_str);
            return false;
        }
    }
    return true;
}

/**
 * Print to stdout
 **/
void FOLFormula::Print() const {
    this->Save(std::cout);
}

std::string FOLFormula::ToString() const {
    std::ostringstream os;
    this->Save(os);
    return os.str();
}

/**
 * Save to a stream
 **/
bool FOLFormula::Save(std::ostream& os) const
{
    if (!this->propositional_formula.IsValid()) {
        return false;
    }

    bool ret = true;
    for (QuantifiedVariables::const_iterator it = quantifiedVariables.begin();
         it != quantifiedVariables.end(); ++it) {
        if (it->quantifier == forall) {
            os << "forall ";
        } else if (it->quantifier == exists) {
            os << "exists ";
        } else if (it->quantifier == exists_N) {
            os << "exists_" << it->quantifier_num << " ";
        }
        os << it->name << " ";
    }

    os << propositional_formula.ToString() << ";";

    if (ruleType == LEARN)
        os << "LEARN" << ";";

    else
        os << "VERIFY" << ";";

    if (quantifier_conversion_norm == LINF)
        os << "LINF" << ";";

    else if (quantifier_conversion_norm == L1)
        os << "L1" << ";";

    else
        os << "L2" << ";";

    if (propositional_conversion_norm == PRODUCT_TNORM) {
        os << "PRODUCT_TNORM" << std::endl;
    } else if (propositional_conversion_norm == MINIMUM_TNORM) {
        os << "MINIMUM_TNORM" << std::endl;
    } else if (propositional_conversion_norm == LUKASIEWICZ_TNORM) {
        os << "LUKASIEWICZ_TNORM" << std::endl;
    } else if (propositional_conversion_norm == WEAK_LUKASIEWICZ_TNORM) {
        os << "WEAK_LUKASIEWICZ_TNORM" << std::endl;
    } else {
        os << "UNKNOWN" << std::endl;
    }

    if (givenLiteral.IsValid()) {
        os << "GivenLiteral: " << givenLiteral.GetId() << ";";
    } else {
        os <<"No given literal;";
    }

    os << "Lambda:" << lambda << ";Priority:" << priority << std::endl;
    os << "Variable " << "Domain " << std::endl;

    for (VariablesDomains::const_iterator it = variablesDomains.begin();
         it != variablesDomains.end(); ++it) {
        os << it->first << " " << it->second << std::endl;
    }

    return ret;
}

bool FOLFormula::Equals(const FOLFormula& formula) const {
  return name == formula.name &&
         quantifiedVariables == formula.quantifiedVariables &&
         variablesDomains == formula.variablesDomains &&
         propositional_formula.Equals(formula.propositional_formula) &&
         ruleType == formula.ruleType &&
         quantifier_conversion_norm == formula.quantifier_conversion_norm &&
         propositional_conversion_norm == formula.propositional_conversion_norm &&
         givenLiteral.Equals(formula.givenLiteral) &&
         lambda == formula.lambda &&
         priority == formula.priority;
}
