#include "data/predicates.h"

#include <fstream>

#include "data/dataset.h"
#include "utils/stl_utils.h"
#include "utils/string_utils.h"


using namespace Regularization;

Predicates::Predicates() { }

Predicates::Predicates(const std::string& filename) {
    CHECK(this->LoadFromFile(filename, NULL));
}

Predicates::~Predicates() {
}

/*
 * Set the equal predicate i.e. the predicates that share the same domain
 */
bool Predicates::SetPerDomainPredicate(const Function::ID& id)
{
    const Predicate& predicate = *this->Get(id);
    for (PerDomainPredicates::iterator it = per_domain_predicates.begin();
         it != per_domain_predicates.end(); ++it) {
        bool value = true;
        // check the arity
        if (it->second.size() == predicate.GetArity()) {
            // check the domains
            for (unsigned int i = 0; i < predicate.GetArity(); ++i) {
                if (it->second[i] != predicate.GetDomain(i)) {
                    value = false;
                    break;
                }
            }

            // add the predicate to the vector
            if (value) {
                it->first.push_back(id);
                return true;
            }
        }
    }

    // there is no predicate with same domain
    std::vector<std::string> temp;
    temp.push_back(id);
    per_domain_predicates.push_back(std::make_pair(temp, predicate.GetDomains()));
    return true;
}

void Predicates::Clear() {
    predicatesMap.clear();
    per_domain_predicates.clear();
}

/**
 * Load from file (predicates)
 **/
bool Predicates::LoadFromFile(const std::string& filename, const Dataset* dataset, const bool clear)
{
    std::ifstream ifs(filename.c_str());
    if (!ifs.is_open()) {
        WARN("Could not open the file " << filename);
        return false;
    }
    return this->LoadFromStream(ifs, dataset, clear);
}

/**
 * Load from stream (predicates)
 **/
bool Predicates::LoadFromStream(std::istream& is, const Dataset* dataset, const bool clear) {
    // format
    // DEF NAME(domain1, domain2, ...);type;C|R[;default_val]
    if (clear) {
        this->Clear();
    }
    std::string line;
    std::vector<std::vector<std::string> > definitionVector;
    unsigned int lineCounter = static_cast<int>(0);

    while (!is.eof())
    {
        line.clear();
        definitionVector.clear();
        getline(is, line);
        lineCounter++;

        // skip empty lines and carriage return
        if (line.empty() || line.size() == 1)
            continue;

        // skip comment line
        if (StringUtils::StartsWith(line, '#', true)) {
            continue;
        }

        // parser error; search for invalid character, the second parameter are valid ASCII symbols
        if (!StringUtils::IsAlphaNumericOrInSet(line, ".+/*-(),;_ \r"))
        {
            WARN("Invalid character used, see the file of the definitions at line " <<
                 lineCounter << " line: " << line);
            return false;
        }

        // check the number of semicolons
        const int num_semicolons = StringUtils::CharCounter(line, ';');
        if (num_semicolons < 2 || num_semicolons > 4) {
            WARN("Invalid number of ';' see the file of the definitions file at line " <<
                  lineCounter <<  " line: " << line);
            return false;
        }

        // check the number of brackets
        if (StringUtils::CharsCounter(line, "()") != 2) {
            WARN("Invalid number of (), see the file of the definitions file at line " <<
                  lineCounter <<  " line: " << line);
            return false;
        }

        StringUtils::SplitToVectorOfVectorsByType(line, &definitionVector, " ", ";", 0);

        // parser error; check the correct split of the line 0->DEF 1->A(d1);LEARN;C;T
        if (definitionVector.size() != 2 || definitionVector[0].empty() ||
            definitionVector[0][0] != "DEF" ||
            definitionVector[1].size() > 5 || definitionVector[1].size() < 3) {
            WARN("Wrong predicate definition, see the file of the definitions at line " <<
                  lineCounter << " line: " << line);
            return false;
        }

        std::vector<std::vector<std::string> > tempVec;
        std::vector<std::string> domainVariables;
        // removes the brackets
        StringUtils::SplitToVectorOfVectorsByType(definitionVector[1][0], &tempVec, "(", ")", 0);
        if (static_cast<int>(tempVec.size()) < 2) {
            WARN("Wrong predicate definition in token " << definitionVector[1][0] <<
                 ", see the file of the definitions at line " << lineCounter << " line: " << line);
            return false;
        }

        const Function::ID& id = tempVec[0][0];
        if (!StringUtils::IsAlphaNumericOrInSet(id, ".+/*-_"))
        {
            WARN("Invalid character used in predicate name " + id +
                 " , see the file of the definitions at line " <<
                 lineCounter << " line: " << line);
            return false;
        }
        // parser error; predicate already defined
        if (predicatesMap.find(id) != predicatesMap.end()) {
            WARN("Predicate " << id << " repeated, see the file of the definitions at line " <<
                 lineCounter << " line: " << line);
            return false;
        }

        // finds the dimensionality, counting the commas
        StringUtils::SplitToVector(tempVec[1][0], &domainVariables, ",");
        const std::string& predicateType = definitionVector[1][1];
        const std::string& problemType = definitionVector[1][2];
        std::string defaultTrueValue = "DC";
        if (definitionVector[1].size() == 4) {
            defaultTrueValue = definitionVector[1][3];
        }

        if (dataset != NULL && dataset->Size() != static_cast<Index>(0)) {
            // check if the domain of the predicate has values in the file of data
            for (unsigned int l = 0; l < domainVariables.size(); ++l) {
                if (dataset->GetSizeForDomain(domainVariables[l]) == 0) {
                    WARN("Discrepancy between the domain " << domainVariables[l] <<
                         " of the predicate " << id << " and the correspondent domain in the" <<
                         " dataset, see the file of the definitions at line " << lineCounter <<
                         " line: " << line);
                    return false;
                }
            }
        }

        // set the name of the predicate and its flags
        Predicate predicate(id, domainVariables,
                predicateType, problemType, defaultTrueValue);
        CHECK_WITH_MESSAGE(this->Set(id, predicate), "Can not add the predicate");
        // set the vector of the predicate that have the same domain
        this->SetPerDomainPredicate(id);
    }

    return true;
}

/**
 * Save to a stream
 **/
bool Predicates::SaveToStream(std::ostream& os) const
{
    if (this->Size() < 0)
        return false;

    else if (this->Size() == 0)
        os << "No predicates are defined" << std::endl;

    bool ret = true;

    for (PredicatesMap::const_iterator it = predicatesMap.begin();
         it != predicatesMap.end(); ++it) {
        os << it->first;
        ret &= it->second.Save(os);
    }

    return ret;
}

/**
 * Save to a file
 **/
bool Predicates::SaveToFile(const std::string& filename) const
{
    std::ofstream ofs(filename.c_str());

    if (!ofs.is_open())
    {
        WARN("Could not open the file " << filename);
        return false;
    }

    return this->SaveToStream(ofs);
}

/*
 * Save into a string.
 */
std::string Predicates::ToString() const {
    std::ostringstream os;
    CHECK(this->SaveToStream(os));
    return os.str();
}

/**
 * Print predicate info to stdout
 **/
void Predicates::Print() const
{
    std::cout << "----------------------------------------" << std::endl;
    std::cout << "Predicates Info:" << std::endl;
    std::cout << "Number of predicates: " << this->Size() << std::endl;
    this->SaveToStream(std::cout);
    std::cout << std::endl << "----------------------------------------" << std::endl;
}

