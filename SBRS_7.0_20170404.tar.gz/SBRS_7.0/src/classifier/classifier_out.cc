#include "classifier/classifier_out.h"

#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>

#include "data/pattern.h"
#include "utils/string_utils.h"


using namespace std;

namespace Regularization {

/*******************************************************************
 * Clear the instance
 ******************************************************************/
void ClassifierOut::Clear() {
    this->winner_predicate.first = "";
    this->winner_predicate.second = static_cast<Value>(0);
    this->max_score.second = static_cast<Value> (std::numeric_limits<int>::min());
    this->min_score.second = static_cast<Value> (std::numeric_limits<int>::max());

    if (this->scores.size() > 0)
    {
        this->scores.clear();
    }
}
/**
 * Compute the winner predicate
 * In this case the winner predicate is the predicate with highest score
 **/
void ClassifierOut::ComputeWinnerPredicate()
{
    if (this->scores.empty()) {
        return;
    }
    this->winner_predicate.first = this->scores.begin()->first;
    this->winner_predicate.second = this->scores.begin()->second;

    for (FunctionsValues::const_iterator iter = this->scores.begin();
            iter != this->scores.end(); ++iter)
    {
        if (this->scores[iter->first] > this->winner_predicate.second)
        {
            this->winner_predicate.first = iter->first;
            this->winner_predicate.second = iter->second;
        }
    }
}

/**
 * Compute the extreme values
 **/
void ClassifierOut::ComputeExtremeValues()
{
    if (this->scores.empty()) {
        return;
    }
    this->max_score.first = this->scores.begin()->first;
    this->min_score.first = this->scores.begin()->first;
    this->max_score.second = this->scores.begin()->second;
    this->min_score.second = this->scores.begin()->second;

    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (this->scores[iter->first] > this->max_score.second)
        {
            this->max_score.first = iter->first;
            this->max_score.second = iter->second;
        }

        if (this->scores[iter->first] < this->min_score.second)
        {
            this->min_score.first = iter->first;
            this->min_score.second = iter->second;
        }
    }
}

/**
 * Get the i-th score
 **/
Value ClassifierOut::GetScore(const Function::ID& id) const {
    FunctionsValues::const_iterator iter = this->scores.find(id);
    CHECK_WITH_MESSAGE(iter != this->scores.end(),
            StringUtils::StrCat("Trying to access element ", id, " which has not a score "));
    return iter->second;
}

/**
 * Get score sum
 **/
Value ClassifierOut::GetSum() const
{
    Value sum = static_cast<Value>(0);

    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        sum += iter->second;
    }

    return sum;
}

/**
 * Get score abs sum
 **/
Value ClassifierOut::GetAbsSum() const
{
    Value sum = static_cast<Value>(0);

    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        sum += std::abs(static_cast<Value> (iter->second));
    }

    return sum;
}

/**
 * Get the score average
 **/
Value ClassifierOut::GetAverage() const
{
    if (this->scores.empty())
        return static_cast<Value>(0.0);

    return this->GetSum() / static_cast<Value> (this->scores.size());
}

/**
 * Get the output entropy (assumes to get as input a vector of probabilities)
 **/
Value ClassifierOut::GetEntropy() const
{
    if (this->scores.empty())
        return static_cast<Value>(0.0);

    if (this->HasHigher(1.0) || this->HasLower(0.0) || fabs(this->GetSum() - 1.0) > 0.00001)
    {
        WARN("Map of scores is not containing probabilities, can not compute entropy");
        return static_cast<Value>(0.0);
    }

    Value entropy = static_cast<Value>(0.0);

    for (FunctionsValues::const_iterator iter = this->scores.begin();
            iter != this->scores.end(); ++iter)
    {
        Value val = iter->second;
        entropy += val * std::log(val);
    }

    return entropy;
}

/**
 * Return true if a score is higher than score
 **/
bool ClassifierOut::HasHigher(const Value score) const
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second > score)
            return true;
    }

    return false;
}

/**
 * Return true if a score is lower than score
 **/
bool ClassifierOut::HasLower(const Value score) const
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second < score)
            return true;
    }

    return false;
}

/**
 * Return true if a score is equal to score
 **/
bool ClassifierOut::HasEqual(const Value score) const
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second == score)
            return true;
    }

    return false;
}

/**
 * Set the score value for a specified predicate
 **/
void ClassifierOut::Set(const Function::ID& id, const Value score)
{
    this->scores[id] = score;

    if (score > this->max_score.second)
    {
        this->max_score.first = id;
        this->max_score.second = score;
        this->winner_predicate.first = id;
        this->winner_predicate.second = score;
    }

    else if (score < this->min_score.second)
    {
        this->min_score.first = id;
        this->min_score.second = score;
    }
}

/**
 * I/O
 **/
std::string ClassifierOut::ToString() const
{
    ostringstream os;
    os << pattern->GetName() <<"\t";
    this->SaveScoresToStream(os);
    return os.str();
}

void ClassifierOut::Print() const
{
    cout << pattern->GetName() <<"\t";
    this->SaveScoresToStream(cout);
}

void ClassifierOut::SaveToStream(std::ostream& io) const
{
	io << pattern->GetName() <<"\t";
	this->SaveScoresToStream(io);
}

/**
 * I/O
 **/
void ClassifierOut::SaveScoresToStream(std::ostream& io) const
{
    if (this->scores.size() > 0)
    {
        unsigned int cnt = 0;
        for (FunctionsValues::const_iterator iter = this->scores.begin();
                iter != this->scores.end(); ++iter)
       {
            io << iter->first << ":" << setiosflags(ios::fixed) << iter->second << resetiosflags(ios::fixed);
            if (cnt < this->scores.size() - 1)
                io<< ",";
            ++cnt;
       }
    }
    else
    {
        io << "NO SCORES";
    }

    io << endl;
}
/*******************************************************************
 * Utility to manage with the scores
 *******************************************************************/

/**
 * Add v to each score
 **/
void ClassifierOut::Add(const Value v, bool resync)
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        this->Set(iter->first, this->GetScore(iter->first) + v);
    }

    if (resync)
    {
        this->Sync();
    }
}

/**
 * Add a classifier output
 **/
void ClassifierOut::Add(const ClassifierOut& classifier_out, const bool resync)
{
    FunctionsValues new_scores = classifier_out.GetScores();

    for (FunctionsValues::const_iterator iter = new_scores.begin(); iter != new_scores.end(); ++iter)
    {
        if (this->scores.find(iter->first) != this->scores.end())
        {
            this->Set(iter->first, this->GetScore(iter->first) + iter->second);
        }

        else
            this->scores[iter->first] = iter->second;
    }

    if (resync)
    {
        this->Sync();
    }
}

/**
 * Scale scores by factor s
 **/
void ClassifierOut::Scale(const Value s)
{
    for (FunctionsValues::iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        iter->second *= s;
    }

    this->Sync();
}

/**
 * Limit the scores to v
 **/
void ClassifierOut::Limit(const Value v)
{
    for (FunctionsValues::iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second > v)
        {
            iter->second = v;
        }
    }

    this->Sync();
}

/*******************************************************************
 * Merging two outputs
 *******************************************************************/

/**
 * Merge the list of classifier_outs into the classifier out (static)
 */

/*
ClassifierOut* ClassifierOut::Merge(const Classifier::ResultsSet& classifier_out_list)
{
    const Pattern& pattern = ;
    ClassifierOut* classifier_out = new ClassifierOut(pattern);

    // fill the classifier_out
    for (unsigned int i = 0; i < classifier_out_list.size(); ++i)
    {
        classifier_out->Add(*(classifier_out_list[i]), false);
    }
    classifier_out->Sync();

    return classifier_out;
}
*/

} // end namespace Regularization
