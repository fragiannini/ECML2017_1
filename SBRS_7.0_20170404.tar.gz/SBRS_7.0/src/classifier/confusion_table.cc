#include "data/dataset.h"
#include "data/examples.h"
#include "data/pattern.h"
#include "classifier/confusion_table.h"
#include "classifier/classifier_out.h"
#include <iomanip>

#include "utils/gflags/gflags/gflags.h"


using namespace Regularization;

/*
 * ConfusionTable constructor
 */
ClassificationStats::ClassificationStats(const BaseClassifier& classifier, const Examples* examples_, Value threshold_) :
    threshold(threshold_),
    examples(examples_) {
    BaseClassifier::LearnIterator iter(classifier);
    while (iter.HasNext()) {
        const std::pair<const std::string, LearnFunction*>* el = iter.GetNext();
        this->predicatesStatistics[el->first] = PredicateStatistics(el->first);
        argmax_confusion_table[el->first] = TableRow();
    }
}

ClassificationStats::ClassificationStats(const BaseClassifier::ResultsSet& results, const Examples* examples_, Value threshold_) :
    threshold(threshold_),
    examples(examples_)  {
    for (unsigned int i = 0; i < results.size(); ++i) {
        const ClassifierOut& classifier_out = results[i];
        const ClassifierOut::FunctionsValues& scores = classifier_out.GetScores();

        for (ClassifierOut::FunctionsValues::const_iterator iter = scores.begin();
             iter != scores.end(); ++iter) {
            this->predicatesStatistics[iter->first] = PredicateStatistics(iter->first);
            argmax_confusion_table[iter->first] = TableRow();
        }
    }
    this->Add(results);
}

ArgmaxClassificationStats::ArgmaxClassificationStats(
        const BaseClassifier& classifier_, const Examples* examples_, const Value threshold_) :
    ClassificationStats(classifier_, examples_, threshold_) { }
ArgmaxClassificationStats::ArgmaxClassificationStats(
        const BaseClassifier::ResultsSet& results, const Examples* examples_, const Value threshold_) :
    ClassificationStats(results, examples_, threshold_) { }

/**
 * Add a set of results to the table
 **/
void ClassificationStats::Add(const BaseClassifier::ResultsSet& results) {
    for (unsigned int i = 0; i < results.size(); ++i) {
        const ClassifierOut& classifier_out = results[i];
        const Pattern* pattern = classifier_out.GetPattern();
        const std::string& pattern_name = pattern->GetName();

        // Check if a pattern is labeled. If not skip it.
        if (examples->IsSupervised(pattern_name)) {
            this->Add(classifier_out);
        }
    }
}

// Add a result pair to the table
void ClassificationStats::Add(const ClassifierOut& result)
{
    const ClassifierOut::FunctionsValues& scores = result.GetScores();
    const Pattern* pattern = result.GetPattern();

    for (ClassifierOut::FunctionsValues::const_iterator iter = scores.begin();
         iter != scores.end(); ++iter) {
        Value target = 0.0;
        if (!examples->IsSupervised(iter->first, pattern->GetName(), &target))
            continue; // nothing can be said

        // The table should be correctly initialized.
        CHECK(predicatesStatistics.find(iter->first) != predicatesStatistics.end());
        CHECK(argmax_confusion_table.find(iter->first) != argmax_confusion_table.end());

        // Populate the score2target stats to later compute the AUC scores.
        globalStatistics.score2target.insert(std::make_pair(iter->second, target));
        predicatesStatistics[iter->first].score2target.insert(
                std::make_pair(iter->second, target));

        if (target >= threshold) {
            globalStatistics.sumPositiveTargets++;
            predicatesStatistics[iter->first].sumPositiveTargets++;
            argmax_confusion_table[iter->first][result.GetWinnerPredicate()]++;
        } else {
            globalStatistics.sumNegativeTargets++;
            predicatesStatistics[iter->first].sumNegativeTargets++;
        }

        if (iter->second >= threshold) {
            // Classified as predicate c
            if (target >= threshold) {
                globalStatistics.TP++;
                predicatesStatistics[iter->first].TP++;
            } else {
                globalStatistics.FP++;
                predicatesStatistics[iter->first].FP++;
            }
        } else {
            // Not classified as predicate c
            if (target > threshold) {
                globalStatistics.FN++;
                predicatesStatistics[iter->first].FN++;
            } else {
                globalStatistics.TN++;
                predicatesStatistics[iter->first].TN++;
            }
        }
    }
}

// Add a result pair to the table
void ArgmaxClassificationStats::Add(const ClassifierOut& result)
{
    const ClassifierOut::FunctionsValues& scores = result.GetScores();
    const Pattern* pattern = result.GetPattern();

    const Function::ID& winner_predicate = result.GetWinnerPredicate();
    for (ClassifierOut::FunctionsValues::const_iterator iter = scores.begin();
         iter != scores.end(); ++iter) {
        Value target = 0.0;
        if (!examples->IsSupervised(iter->first, pattern->GetName(), &target))
            continue; // nothing can be said

        // The table should be correctly initialized.
        CHECK(predicatesStatistics.find(iter->first) != predicatesStatistics.end());
        CHECK(argmax_confusion_table.find(iter->first) != argmax_confusion_table.end());

        // Populate the score2target stats to later compute the AUC scores.
        globalStatistics.score2target.insert(std::make_pair(iter->second, target));
        predicatesStatistics[iter->first].score2target.insert(
                std::make_pair(iter->second, target));

        if (target >= threshold) {
            globalStatistics.sumPositiveTargets++;
            predicatesStatistics[iter->first].sumPositiveTargets++;
            argmax_confusion_table[iter->first][result.GetWinnerPredicate()]++;
        } else {
            globalStatistics.sumNegativeTargets++;
            predicatesStatistics[iter->first].sumNegativeTargets++;
        }

        if (iter->second >= threshold && target >= threshold) {
            if (iter->first == winner_predicate) {
                globalStatistics.TP++;
                predicatesStatistics[winner_predicate].TP++;
            } else {
                globalStatistics.FN++;
                predicatesStatistics[winner_predicate].FN++;
            }
        }
    }
}
/*
 * Implementation of the accessors
 */
// accuracy per predicate
Value ClassificationStats::GetAccuracy(const Function::ID& id) const
{
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());

    const Value num = iter->second.TP + iter->second.TN;
    const Value den = iter->second.TP + iter->second.TN + iter->second.FN + iter->second.FP;

    return (den > 0 ? num / den : 0);
}

namespace {
inline Value Specificity(const Value TP, const Value FP, const Value TN, const Value FN) {
    CHECK_GE(TN, static_cast<Value>(0));
    CHECK_GE(FP, static_cast<Value>(0));
    const Value den = TN + FP;
    return (den > 0 ? TN / den : 0);
}

inline Value Recall(const Value TP, const Value FP, const Value TN, const Value FN) {
    CHECK_GE(TP, static_cast<Value>(0));
    CHECK_GE(FN, static_cast<Value>(0));
    const Value den = TP + FN;
    return (den > 0 ? TP / den : 0);
}

inline Value Precision(const Value TP, const Value FP, const Value TN, const Value FN) {
    CHECK_GE(TP, static_cast<Value>(0));
    CHECK_GE(FP, static_cast<Value>(0));
    const Value den = TP + FP;
    return (den > 0 ? TP / den : 0);
}

// Comoputs the AUC of the ROC or PR curve.
// If roc is not null, it also returns the curve points.
Value AUC(const ClassificationStats::PredicateStatistics& stats, const bool roc_or_pr,
        const Value target_threshold, const int max_samples,
        ClassificationStats::ROC* roc) {
    if (roc != NULL)  roc->clear();

    const ClassificationStats::Score2Target& score2target = stats.score2target;
    // Initially everything is positive, we build the plot right to left.
    long TP = stats.sumPositiveTargets;
    long FP = stats.sumNegativeTargets;
    long TN = 0;
    long FN = 0;
    Value ROC = 0;
    Value sum_of_recall_portions = 0;
    // Since we build right to left, ROC starts in (1,1) and PR in (1, 0)
    Value old_x = (roc_or_pr ? 1 : 1);
    Value old_y = (roc_or_pr ? 1 : 0);
    ClassificationStats::Score2Target::const_iterator iter = score2target.begin();
    for (; iter != score2target.end(); ++iter) {
        const bool is_positive = (iter->second >= target_threshold);
        if (is_positive) {
            --TP;
            ++FN;
        } else {
            ++TN;
            --FP;
        }
        const Value x = (roc_or_pr ? 1 - Specificity(TP, FP, TN, FN) :
                                     Recall(TP, FP, TN, FN));

        CHECK_GE(old_x, x);
        const Value y = (roc_or_pr ? Recall(TP, FP, TN, FN) :
                                     Precision(TP, FP, TN, FN));
        if (roc != NULL) {
            roc->push_back(std::make_pair(x, y));
        }

        if (old_x != x) {
            // Add the area of this portion.
            const Value portion_area = (old_x - x);
            sum_of_recall_portions += portion_area;
            ROC += 0.5 * (old_y + y) * portion_area;

            old_x = x;
            old_y = y;
            // MESSAGE(sum_of_recall_portions << " " << y << " " << portion_area << " => " << ROC);
        }
    }
    // Add last left over portion if we did not get exactly at (0,0) for ROC and (0,1) for PR.
    ROC += 0.5 * (roc_or_pr ? old_y : 0.5 * (old_y + 1)) * old_x;

    // Reduce the number of samples to the desired max size.
    if (roc != NULL && max_samples > 0 &&
        static_cast<unsigned int>(max_samples) < roc->size()) {
        const Value step = roc->size() / max_samples;
        ClassificationStats::ROC roc1;
        for (unsigned int i = 0; i < roc->size(); i += step) {
            roc1.push_back((*roc)[i]);
        }

        // copy back to roc.
        *roc = roc1;
    }

    // CHECK_IN_RANGE(sum_of_recall_portions, static_cast<Value>(0.99), static_cast<Value>(1.01));
    CHECK_EQ(TP, 0l);
    CHECK_EQ(FP, 0l);
    CHECK_INE_RANGE(ROC, static_cast<Value>(0), static_cast<Value>(1));

    return ROC;
}

// Not used for the moment.
/* Value PRCurve(const ClassificationStats::PredicateStatistics& stats,
         const Value target_threshold, const int max_samples,
         ClassificationStats::ROC* roc) {
    return ::AUC(stats, false, target_threshold, max_samples, roc);
} */

Value PRAUC(const ClassificationStats::PredicateStatistics& stats,
         const Value target_threshold) {
    return ::AUC(stats, false, target_threshold, 0, NULL);
}

Value ROCAUC(const ClassificationStats::PredicateStatistics& stats,
         const Value target_threshold) {
    return ::AUC(stats, true, target_threshold, 0, NULL);
}

/* void ROC(const ClassificationStats::PredicateStatistics& stats,
         const Value threshold, const int max_samples,
         ClassificationStats::ROC* roc) {
    roc->clear();

    const ClassificationStats::Score2Target& score2target = stats.score2target;

    // Initially everything is positive.
    long TP = stats.sumPositiveTargets;
    long FP = stats.sumNegativeTargets;
    long TN = 0;
    long FN = 0;
    ClassificationStats::Score2Target::const_iterator iter = score2target.begin();
    for (; iter != score2target.end(); ++iter) {
        const bool is_positive = (iter->second >= threshold);
        if (is_positive) {
            --TP;
            ++FN;
        } else {
            ++TN;
            --FP;
        }
        const Value recall = Recall(TP, FP, TN, FN);
        const Value not_specificity =  1 - Specificity(TP, FP, TN, FN);
        roc->push_back(std::make_pair(not_specificity, recall));
    }
    CHECK_EQ(TP, 0l);
    CHECK_EQ(FP, 0l);

    // Reduce the number of samples to the desired max size.
    if (max_samples > 0 && static_cast<unsigned int>(max_samples) < roc->size()) {
        const Value step = roc->size() / max_samples;
        ClassificationStats::ROC roc1;
        for (unsigned int i = 0; i < roc->size(); i += step) {
            roc1.push_back((*roc)[i]);
        }

        // copy back to roc.
        *roc = roc1;
    }
} */

}  // end namespace

// recall per predicate
Value ClassificationStats::GetRecall(const Function::ID& id) const
{
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    return Recall(iter->second.TP, iter->second.FP, iter->second.TN, iter->second.FN);
}

// precision per predicate
Value ClassificationStats::GetPrecision(const Function::ID& id) const
{
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    return Precision(iter->second.TP, iter->second.FP, iter->second.TN, iter->second.FN);
}

// F1 per predicate
Value ClassificationStats::GetF1(const Function::ID& id) const
{
    const Value recall = this->GetRecall(id);
    const Value precision = this->GetPrecision(id);
    const Value den = precision + recall;

    return (den > 0 ? 2.0 * precision * recall / den : 0);
}

// specificity per predicate
Value ClassificationStats::GetSpecificity(const Function::ID& id) const {
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    const Value den = iter->second.FP + iter->second.TN;
    return (den > 0 ? iter->second.TN / den : 0);
}

// macro accuracy
Value ClassificationStats::GetMacroAccuracy(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter !=  predicatesStatistics.end(); ++iter) {
        const Value value = this->GetAccuracy(iter->first);
        res += value;

        if (predicate_by_predicate != NULL) {
            (*predicate_by_predicate)[iter->first] = value;
        }
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

Value ClassificationStats::GetMacroRecall(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
            iter != predicatesStatistics.end(); ++iter) {
        const Value value = this->GetRecall(iter->first);
        res += value;

        if (predicate_by_predicate != NULL) {
            (*predicate_by_predicate)[iter->first] = value;
        }
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

// macro precision
Value ClassificationStats::GetMacroPrecision(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        const Value value = this->GetPrecision(iter->first);
        res += value;

        if (predicate_by_predicate != NULL)
            (*predicate_by_predicate)[iter->first] = value;
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

Value ClassificationStats::GetMacroF1(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        const Value value = this->GetF1(iter->first);
        res += value;

        if (predicate_by_predicate != NULL)
            (*predicate_by_predicate)[iter->first] = value;
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

Value ClassificationStats::GetROCAUC(const Function::ID& id) const {
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    return ::ROCAUC(iter->second, threshold);
}

Value ClassificationStats::GetPRAUC(const Function::ID& id) const {
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    return ::PRAUC(iter->second, threshold);
}

Value ClassificationStats::GetPRAUC(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        const Value value = this->GetPRAUC(iter->first);
        res += value;

        if (predicate_by_predicate != NULL)
            (*predicate_by_predicate)[iter->first] = value;
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

Value ClassificationStats::GetROCAUC(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        const Value value = this->GetROCAUC(iter->first);
        res += value;

        if (predicate_by_predicate != NULL)
            (*predicate_by_predicate)[iter->first] = value;
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

Value ClassificationStats::GetMacroSpecificity(std::map<std::string, Value>* predicate_by_predicate) const
{
    Value res = static_cast<Value>(0);

    if (predicate_by_predicate != NULL) {
        predicate_by_predicate->clear();
    }

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        const Value value = this->GetSpecificity(iter->first);
        res += value;

        if (predicate_by_predicate != NULL)
            (*predicate_by_predicate)[iter->first] = value;
    }

    return (predicatesStatistics.size() > 0 ? res / predicatesStatistics.size() : 0);
}

Value ClassificationStats::GetMicroAccuracy() const {
    Value num = static_cast<Value>(0);
    Value den = static_cast<Value>(0);

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
            iter != predicatesStatistics.end(); ++iter)
    {
        num += iter->second.TP + iter->second.TN;
        den += iter->second.TP + iter->second.TN + iter->second.FN + iter->second.FP;
    }
    return (den > 0 ? num / den : 0);
}

Value ClassificationStats::GetMicroRecall() const {
    Value num = static_cast<Value>(0);
    Value den = static_cast<Value>(0);

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        num += iter->second.TP;
        den += iter->second.TP + iter->second.FN;
    }

    return (den > 0 ? num / den : 0);
}

Value ClassificationStats::GetMicroPrecision() const {
    Value num = static_cast<Value>(0);
    Value den = static_cast<Value>(0);

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        num += iter->second.TP;
        den += iter->second.TP + iter->second.FP;

    }

    return (den > 0 ? num / den : 0);
}

Value ClassificationStats::GetMicroF1() const {
    const Value R = this->GetMicroRecall();
    const Value P = this->GetMicroPrecision();
    const Value den = P + R;

    return (den > 0 ? 2.0 * P * R / den : 0);
}

Value ClassificationStats::GetMicroSpecificity() const {
    Value num = static_cast<Value>(0);
    Value den = static_cast<Value>(0);

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter) {
        num += iter->second.TN;
        den += iter->second.TN + iter->second.FP;
    }

    return (den > 0 ? num / den : 0);
}

void ClassificationStats::GetPRCurveForFunction(
        const Function::ID& id, const int max_samples, ClassificationStats::ROC* roc) const {
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    ::AUC(iter->second, false, this->threshold, max_samples, roc);
}

void ClassificationStats::GetROCForFunction(
        const Function::ID& id, const int max_samples, ClassificationStats::ROC* roc) const {
    PredicatesStatistics::const_iterator iter = predicatesStatistics.find(id);
    CHECK(iter != predicatesStatistics.end());
    ::AUC(iter->second, true, this->threshold, max_samples, roc);
}

void ClassificationStats::GetPRCurve(const int max_samples, ClassificationStats::ROC* roc) const {
    ::AUC(globalStatistics, false, this->threshold, max_samples, roc);
}

void ClassificationStats::GetROC(const int max_samples, ClassificationStats::ROC* roc) const {
    ::AUC(globalStatistics, true, this->threshold, max_samples, roc);
}

/********************************************************************
 * I/O
 ********************************************************************/
bool ClassificationStats::SaveToFile(std::string& filename) const
{
    std::ofstream out(filename.c_str());
    if (!out.good())
        return false;

    this->Save(out);
    return true;
}

void ClassificationStats::Print() const
{
    this->Save(std::cout);
}

void ClassificationStats::Save(std::ostream& out) const {
    // global
    out << "Macro Statistics:" << std::endl;
    std::map<std::string, Value> predicate_by_predicate;
    out << "Macro_Accuracy: " << std::fixed << std::setprecision(3) << this->GetMacroAccuracy(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << "Macro_Recall: " << std::fixed << std::setprecision(3) << this->GetMacroRecall(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << "Macro_Precision: " << std::fixed << std::setprecision(3) << this->GetMacroPrecision(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << "Macro_F1: " << std::fixed << std::setprecision(3) << this->GetMacroF1(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << "PR_AUC: " << std::fixed << std::setprecision(3) << this->GetPRAUC(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << "ROC_AUC: " << std::fixed << std::setprecision(3) << this->GetROCAUC(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << "Macro_Specificity: " << std::fixed << std::setprecision(3) << this->GetMacroSpecificity(&predicate_by_predicate) << std::endl;
    //out << "\tBy Class:\t" << StringUtils::VectorToString(predicate_by_predicate, ',', '\n') << endl;
    out << std::endl << "Micro Statistics:" << std::endl;
    out << "Micro_Accuracy: " << std::fixed << std::setprecision(3) << this->GetMicroAccuracy() << std::endl;
    out << "Micro_Recall: " << std::fixed << std::setprecision(3) << this->GetMicroRecall() << std::endl;
    out << "Micro_Precision: " << std::fixed << std::setprecision(3) << this->GetMicroPrecision() << std::endl;
    out << "Micro_F1: " << std::fixed << std::setprecision(3) << this->GetMicroF1() << std::endl;
    out << "PR_AUC: " << std::fixed << std::setprecision(3) << this->GetPRAUC() << std::endl;
    out << "ROC_AUC: " << std::fixed << std::setprecision(3) << this->GetROCAUC() << std::endl;
    out << "Micro_Specificity: " << std::fixed << std::setprecision(3) << this->GetMicroSpecificity() << std::endl;
    out << "#### Statistics predicate by predicate ####\n\n";

    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
            iter != predicatesStatistics.end(); ++iter)
    {
    	out << "Predicate " << iter->first << " "<< predicatesStatistics.at(iter->first).sumPositiveTargets <<"+ "
    			<< predicatesStatistics.at(iter->first).sumNegativeTargets <<"-\n";
    	out << "ConfusionTable " << iter->first <<" TP " << iter->second.TP
    			<<" TN " << iter->second.TN
    			<<" FP " << iter->second.FP
    			<<" FN " << iter->second.FN << "\n";
    	out << "Statistics "  << iter->first << " Accuracy " << std::fixed << std::setprecision(3) << this->GetAccuracy(iter->first)
    	                      << " Recall " << std::fixed << std::setprecision(3) << this->GetRecall(iter->first)
    	                      << " Precision " << std::fixed << std::setprecision(3) << this->GetPrecision(iter->first)
    	                      << " F1 " << std::fixed << std::setprecision(3) << this->GetF1(iter->first)
                              << " PR AUC " << std::fixed << std::setprecision(3) << this->GetPRAUC(iter->first)
    	                      << " Specificity " << std::fixed << std::setprecision(3) << this->GetSpecificity(iter->first) <<"\n\n";
    }
}

void ArgmaxClassificationStats::Save(std::ostream& out) const {
    // global
    out << "Macro Statistics:" << std::endl;
    std::map<std::string, Value> predicate_by_predicate;
    out << "Macro_Accuracy: " << std::fixed << std::setprecision(3) << this->GetMacroAccuracy(&predicate_by_predicate) << std::endl;
    out << std::endl << "Micro Statistics:" << std::endl;
    out << "Micro_Accuracy: " << std::fixed << std::setprecision(3) << this->GetMicroAccuracy() << std::endl;
    out << "ROC_AUC: " << std::fixed << std::setprecision(3) << this->GetROCAUC() << std::endl;
    out << "PR_AUC: " << std::fixed << std::setprecision(3) << this->GetPRAUC() << std::endl;

    out << "#### Statistics predicate by predicate ####\n\n";
    for (PredicatesStatistics::const_iterator iter = predicatesStatistics.begin();
         iter != predicatesStatistics.end(); ++iter)
    {
        out << "Predicate " << iter->first << " "<< predicatesStatistics.at(iter->first).sumPositiveTargets <<"+ "
                << predicatesStatistics.at(iter->first).sumNegativeTargets <<"-\n";
        out << "ConfusionTable " << iter->first <<" TP " << iter->second.TP
                <<" TN " << iter->second.TN
                <<" FP " << iter->second.FP
                <<" FN " << iter->second.FN << "\n";
        out << "Statistics "  << iter->first << " Accuracy " << std::fixed << std::setprecision(3) << this->GetAccuracy(iter->first);
    }
}


// Save micro results in a map
std::map<std::string, Value> ClassificationStats::GetMicroResults() const {
	std::map<std::string, Value> results;
	results["Accuracy"] = this->GetMicroAccuracy();
	results["Recall"] = this->GetMicroRecall();
	results["Precision"] = this->GetMicroPrecision();
	results["F1"] = this->GetMicroF1();
    results["Specificity"] = this->GetMicroSpecificity();
    results["PR_AUC"] = this->GetPRAUC();
    results["ROC_AUC"] = this->GetROCAUC();
	return results;
}

// Save micro results in a map
std::map<std::string, Value> ClassificationStats::GetMacroResults() const {
	std::map<std::string, Value> results;
	results["Accuracy"] = this->GetMacroAccuracy();
	results["Recall"] = this->GetMacroRecall();
	results["Precision"] = this->GetMacroPrecision();
	results["F1"] = this->GetMacroF1();
    results["Specificity"] = this->GetMacroSpecificity();
    results["PR_AUC"] = this->GetPRAUC();
    results["ROC_AUC"] = this->GetROCAUC();
	return results;
}
