#ifndef BASE_CLASSIFIER_H
#define BASE_CLASSIFIER_H

#include <map>
#include <string>

#include "classifier/classifier_out.h"
#include "classifier/functions/function.h"
#include "classifier/functions/learn_function/learn_function.h"
#include "classifier/functions/given_function.h"
#include "classifier/functions/learn_function/map_function.h"
#include "data/predicates.h"


namespace Regularization {

class Dataset;
class Examples;
class TrainOptions;

/*
 * Class storing a vector of functions. Each functions corresponds to a predicate
 */
class BaseClassifier
{
public:
    typedef Regularization::Value Value;

    // Vector of classiferOut for patterns of a domain
    typedef std::vector<ClassifierOut> ResultsSet;

    // Map of functions in the classifier
    // All learn functions.
    typedef std::map<const Function::ID, LearnFunction*> LearnContainer;
    // Like the above but easier to parallelize via omp 2.5.
    typedef std::vector<LearnFunction*> LearnVectorContainer;
    // All map functions (subset of learn functions).
    typedef std::map<const Function::ID, MapFunction*> MapContainer;
    // All given functions.
    typedef std::map<const Function::ID, GivenFunction*> GivenContainer;
    // All functions (union of learn and given containers).
    typedef std::map<const Function::ID, Function*> FunctionContainer;

    typedef std::vector<std::vector<Function*> > SharedFunctionContainer;

    /**
     * The vector contains the functions that have the same domain. The pair is
     * the vector of the names of the functions and the correspondent vector of
     * the domain.
     **/
    typedef std::vector<std::pair<std::vector<Function::ID>, std::vector<std::string> > > PerDomainFunctions;

    /**
     * Constructors
     **/
    BaseClassifier(const Predicates& predicates_);
    BaseClassifier(const BaseClassifier& classifier);

    /**
     * Destructor
     **/
    virtual ~BaseClassifier();

    virtual void Clear();

    /*
     * Classifier const_iterator, iterates over all learn functions (Map and not)
     */
    class LearnIterator
    {
    private:
        LearnContainer::const_iterator iter;
        const BaseClassifier* classifier;

    public:

        LearnIterator(const BaseClassifier& c)
        {
            classifier = &c;
            iter = classifier->learnFunctionContainer.begin();
        }

        inline bool HasNext() const
        {
            return (iter != classifier->learnFunctionContainer.end());
        }

        typedef std::pair<const Function::ID, LearnFunction*> Element;
        inline const Element* GetNext() {
            if (HasNext()) {
                const Element* ret = &(*iter);
                iter++;
                return ret;
            }

            return NULL;
        }

        inline void Rewind()
        {
            iter = classifier->learnFunctionContainer.begin();
        }

        inline int Size() {
            return static_cast<int>(classifier->learnFunctionContainer.size());
        }
    };

    /*
     * Classifier const_iterator, iterates over all learn functions (Map and not)
     */
    class MutableLearnIterator
    {
    private:
        LearnContainer::iterator iter;
        BaseClassifier* classifier;

    public:

        MutableLearnIterator(BaseClassifier* c)
        {
            classifier = c;
            iter = classifier->learnFunctionContainer.begin();
        }

        inline bool HasNext() const
        {
            return (iter != classifier->learnFunctionContainer.end());
        }

        typedef std::pair<const Function::ID, LearnFunction*> Element;
        inline Element* GetNext() {
            if (HasNext()) {
                Element* ret = &(*iter);
                iter++;
                return ret;
            }

            return NULL;
        }

        inline void Rewind()
        {
            iter = classifier->learnFunctionContainer.begin();
        }

        inline int Size() {
            return static_cast<int>(classifier->learnFunctionContainer.size());
        }
    };

    friend class LearnIterator;
    friend class MutableLearnIterator;

    /**
     * Adds a function to the classifier
     **/
    virtual void Add(Function* function);

    /**
     * Return the number of functions (i.e. the number of predicates)
     **/
    inline unsigned int Size() const
    {
        return (learnFunctionContainer.size() + givenFunctionContainer.size());
    }

    /**
     * Return the number of learnable (not given) functions
     **/
    inline unsigned int LearnableSize() const
    {
        return learnFunctionContainer.size();
    }

    inline bool HasFunction(const Function::ID& id) const {
        LearnContainer::const_iterator iter = learnFunctionContainer.find(id);
        return (iter != learnFunctionContainer.end());
    }

    /*
     * Get a function by its id.
     */
    inline const Function& GetFunctionByIDOrDie(const Function::ID& id) const {
        LearnContainer::const_iterator iter = learnFunctionContainer.find(id);
        if (iter != learnFunctionContainer.end()) {
            return *(iter->second);
        }

        GivenContainer::const_iterator jt = givenFunctionContainer.find(id);
        if (jt != givenFunctionContainer.end()) {
            return *(jt->second);
        }

        FAULT("Function with id " << id << " not found");
        return (*(iter->second));
    }

    inline bool IsLearnFunction(const Function::ID& id) const {
        LearnContainer::const_iterator iter = learnFunctionContainer.find(id);
        return iter != learnFunctionContainer.end();
    }

    /*
     * Get a function by its id.
     */
    inline const LearnFunction& GetLearnFunctionByIDOrDie(const Function::ID& id) const
    {
        LearnContainer::const_iterator iter = learnFunctionContainer.find(id);
        if (iter != learnFunctionContainer.end())
        {
            return *(iter->second);
        }

        FAULT("Function with id " << id << " not found in learn container");
        return (*(iter->second));
    }

    inline bool IsGivenFunction(const Function::ID& id) const {
        GivenContainer::const_iterator iter = givenFunctionContainer.find(id);
        return iter != givenFunctionContainer.end();
    }

    /*
     * Get a function by its id.
     */
    inline const GivenFunction& GetGivenFunctionByIDOrDie(const Function::ID& id) const
    {
        GivenContainer::const_iterator iter = givenFunctionContainer.find(id);
        if (iter != givenFunctionContainer.end())
        {
            return *(iter->second);
        }
        FAULT("Function with id " << id << " not foundin given container");
        return (*(iter->second));
    }

    /*
     * Get a function by its id.
     */
    inline Function* GetMutableFunctionByID(const Function::ID& id) {
        LearnContainer::iterator iter = learnFunctionContainer.find(id);
        if (iter != learnFunctionContainer.end())
        {
            return iter->second;
        }

        GivenContainer::iterator jt = givenFunctionContainer.find(id);
        if (jt != givenFunctionContainer.end()) {
            return jt->second;
        }
        return NULL;
    }

    /*
     * Get a function by its id.
     */
    inline LearnFunction* GetMutableLearnFunctionByID(const Function::ID& id) {
        LearnContainer::iterator iter = learnFunctionContainer.find(id);
        if (iter != learnFunctionContainer.end()) {
            return iter->second;
        }
        return NULL;
    }

    /*
     * Get a function by its id.
     */
    inline GivenFunction* GetMutableGivenFunctionByID(const Function::ID& id) {
        GivenContainer::iterator iter = givenFunctionContainer.find(id);
        if (iter != givenFunctionContainer.end()) {
            return iter->second;
        }
        return NULL;
    }

    /**
     * Return the const vector of the functions
     **/
    inline const FunctionContainer& GetFunctions() const
    {
        return functionContainer;
    }

    /**
     * Return the mutable functions vector
     **/
    inline FunctionContainer* GetMutableFunctions()
    {
        return &functionContainer;
    }

    /**
     * Return the const vector of the functions
     **/
    inline const LearnContainer& GetLearnFunctions() const
    {
        return learnFunctionContainer;
    }

    /**
     * Return the mutable functions vector
     **/
    inline LearnContainer* GetMutableLearnFunctions()
    {
        return &learnFunctionContainer;
    }

    /**
     * Return the const vector of the functions
     **/
    inline const GivenContainer& GetGivenFunctions() const
    {
        return givenFunctionContainer;
    }

    /**
     * Return the mutable functions vector
     **/
    inline GivenContainer* GetMutableGivenFunctions()
    {
        return &givenFunctionContainer;
    }

    /**
     * Return the const vector of the map functions
     **/
    inline const MapContainer& GetMapFunctions() const
    {
        return mapFunctionContainer;
    }

    /**
     * Return the mutable map function vector
     **/
    inline MapContainer* GetMutableMapFunctions()
    {
        return &mapFunctionContainer;
    }

    /**
     * Return the const vector of equal functions
     **/
    inline const PerDomainFunctions& GetPerDomainFunctions() const
    {
        return per_domain_functions;
    }

    /**********************************************************************
     * Standard Classification
     **********************************************************************/

    /*
     * Return the set of the classification results of the classifier.
     * If provided, examples are used to come up with a confusion table
     * and other classification metrics.
     */
    virtual void Classify(const Dataset& dataset, ResultsSet* results) const;

    /**
     * Classify the pattern. If examples are not null, they are used to compute
     * errors and confusion tables.
     **/
    virtual void ClassifyPattern(const Pattern& pattern, ClassifierOut* result) const;

    /**
     * Print the functions info to stdout
     **/
    virtual void Print() const;
    // Save to file or directory.
    // Can be parsed back via LoadFromFile() called from Load().
    virtual bool SaveToFile(const std::string& filename) const;
    // Saving the classifier output to dir. One file per internal function.
    // Can be parsed back via LoadFromDir() called from Load().
    virtual bool SaveToDir(const std::string& dirname) const;

    // Called at the end of training.
    virtual void EndTrain();
    // Called before starting each train iteration.
    virtual void StartTrainIteration();
    virtual void EndTrainIteration();
    virtual void PrepareForCrossvalidation();
    virtual void EndCrossvalidation();

    virtual BaseClassifier* Clone() const = 0;
    // Copy data from classifier to this.
    virtual void Copy(const BaseClassifier* classifier);

protected:
    PerDomainFunctions per_domain_functions;
    FunctionContainer functionContainer;
    LearnContainer learnFunctionContainer;
    LearnVectorContainer learnFunctionVectorContainer;  // do allow omp parallization
    typedef std::map<std::string, LearnContainer> DomainToLearnContainer;
    DomainToLearnContainer domainToLearnFunctionContainer;
    GivenContainer givenFunctionContainer;
    MapContainer mapFunctionContainer;
    SharedFunctionContainer sharedFunctionContainer;
    std::set<Function::ID> sharedFunctionSet;

    Predicates predicates;

    // Implemented by subclasses to finish the copy. Called by Copy().
    virtual void InternalCopy(const BaseClassifier* classifier) = 0;

    // Saving the classifier output to the stream, all functions are sequentially serialized.
    // Can be parsed back via LoadFromStream.
    virtual bool SaveToStream(std::ostream& os) const;
};  // end BaseClassifier

// Classifier used non collective classifiers. Since Collective classifiers need
// a different initialization, the base class is added to keep the common
// initialization procedures.
class Classifier : public BaseClassifier {
public:
    /**
     * Constructors. This is used for a classifier to be trained over the
     * given dataset, with the given examples, predicates and options.
     **/
    Classifier(const Predicates& predicates_,
               const Dataset& dataset_,
               const Examples& examples_,
               const TrainOptions& options_);

    /*
     * Builds and loads a new classifier already trained. All the needed
     * info is stored in the file. The classifier must match the predicate
     * definitions.
     */
    Classifier(const std::string& filename,    // for all LEARN functions
               const Predicates& predicates_,  // needed for GIVEN functions
               const Dataset& dataset_,        // needed for GIVEN functions
               const Examples& examples_,      // needed for GIVEN functions
               const TrainOptions& options_);

    // Copy constructor.
    Classifier(const Classifier& classifier);

    virtual BaseClassifier* Clone() const;

    /**
     * Destructor
     **/
    virtual ~Classifier();

    /*************************************************************
     * I/O
     *************************************************************/
    // Loading a classifier does not make sense for a collective one.
    // So these functions are available only here.
    // Options are used to manage singleton-like static data like large user-provided kernels.
    virtual bool Load(const std::string& filename, const TrainOptions& options);

protected:
    virtual bool LoadFromStream(std::istream& is, const TrainOptions& options);
    virtual bool LoadFromDir(const std::string& dirname, const TrainOptions& options);
    virtual void InternalCopy(const BaseClassifier* classifier);
};  // end Classifier

}  // end namespace Regularization
#endif /* BASE_CLASSIFIER_H */
