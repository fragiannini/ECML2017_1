/*
 * File:   kernel_machine_function.h
 * Author: Tore
 *
 * Created on 24 gennaio 2011, 12.07
 */

#ifndef KERNEL_MACHINE_FUNCTION_H
#define KERNEL_MACHINE_FUNCTION_H

#include "classifier/functions/learn_function/cached_learn_function.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/kernel_factory.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix.h"
#include "utils/math/math_matrix.h"
#include "utils/math/math_vector.h"


namespace Regularization {
class Dataset;
class Examples;
class TrainOptions;

class KernelMachineFunction : public CachedLearnFunction
{
public:
    // Friendship declaration needed to allow the factory class to be able
    // to correctly set up the gram matrix.
    friend class FunctionFactory;

    /********************************
     * Constructors.
     ********************************/
    /**
     * Build a KernelFunction using weights, kernel and dataset.
     */
    KernelMachineFunction(
            const Function::ID id_, const Function::TYPE predicate_type_,
            const Function::Arity arity, const std::string& domain_,
            const Value balance_weight,
            const Value bias,
            const Dataset* dataset_,
            const GramMatrix* gramMatrix_, const Kernel* kernel_);

    /**
     * Copy constructor
     */
    KernelMachineFunction(const KernelMachineFunction& KernelMachineFunction_);

    Function* Clone() const;

    /********************************
     * Destructors.
     ********************************/
    virtual ~KernelMachineFunction();

    /**********************************************
     * Accessors and Mutators
     **********************************************/

    /**
     * Returns the kernel used in the function
     */
    inline const Kernel* GetKernel() const
    {
        return kernel;
    }

    /**
     * Get the bias.
     */
    inline Value GetBias() const
    {
        return bias;
    }

    // Eval the derivative of the function on the i-th pattern of the data set
    virtual bool AccumulateGradientInternal(
            const Pattern& pattern,
            const Value weight,
            Math::Vector<Value>* derivative) const;

    /**************************************************************
     * Error / Derivative Error
     **************************************************************/

    Value RunEval(const Pattern& pattern) const;

    // Eval the regularization error using the pre-computed internal dataset and
    // the internal GramMatrix
    Value EvalRegularizationError() const;

    // Evaluate the derivative of regularization error part of the cost function.
    void GetRegularizationErrorGradient(Math::Vector<Value>* derivative_regularization_part) const;

    /*************************************
     * Support Vectors
     ************************************/
    /*
     * The vector of the support vectors. The pair is the the name of the
     * pattern and the value of the corresponding weight
     */
    typedef std::vector<std::pair<std::string, Value> > SupportVectors;
    void GetSupportVectors(SupportVectors* support_vectors) const;

protected:
    /************************************************************
     * I/O
     ************************************************************/
    bool InternalSaveToStream(std::ostream& os) const;
    bool InternalLoadFromStream(std::istream& is);
    void InternalClear();
    void InitGramMatrixes(const GramMatrix* gramMatrix_);

private:
    // Data of the function
    const Dataset* dataset;
    const GramMatrix* gramMatrix;
    // To avoid virtual calls, we dynamic cast and store a pointer to the exact type for
    // some gram matrices. Virtual calls have been time profiled to consuming 20% of CPU time.
    const DenseGramMatrix* denseGramMatrix;
    const SymmetricGramMatrix* symmetricGramMatrix;

    const Kernel* kernel;
    Value bias;

    SupportVectors support_vectors;

    // optimization: the precomputed Gram Matrix threshold
    Index precomputedGramMatrixThreshold;

    bool owns_gram_matrix;
    bool owns_dataset;
}; // end KernelMachineFunction

} // end namespace Regularization
#endif /* KERNEL_MACHINE_FUNCTION_H */
