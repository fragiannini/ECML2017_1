/*
 * gram_matrix_manager.h
 *
 *  Created on: 13/giu/2011
 *      Author: claudio
 */

#ifndef GRAM_MATRIX_MANAGER_H
#define GRAM_MATRIX_MANAGER_H

#include <map>
#include <string>
#include "train/options.h"


namespace Regularization {

class Dataset;
class Kernel;
class GramMatrix;

class GramMatrixManager {
public:

    /*
     * The map of the Gram's matrices.
     */
    typedef std::map<std::string, const GramMatrix*> DomainToGramMatrix;
    typedef std::map<std::string, std::string> DomainToGramMatrixFilename;

    // Constructors
    GramMatrixManager() { }
    GramMatrixManager(const GramMatrixManager& manager);

    // Destructor
    virtual ~GramMatrixManager();

    /*
     * Clear
     */
    void Clear();

    /******************************************************************
     * Accessors
     ******************************************************************/

    /*
     * Return the Gram's matrix.
     * If not already built, it loads it from the provided file table.
     * If not available from file, it builds from the kernel and data.
     * Calls Get(domain, gram_matrices_files_map)
     */
    const GramMatrix* Get(const Dataset& dataset, const Kernel& kernel,
                          const TrainOptions::DomainToGramMatrixFilename& gram_matrices_files_map);
    /*
     * Return the Gram's matrix.
     * If not already built tries to load it from the provided file table.
     * Calls Get(domain)
     */
    const GramMatrix* Get(const std::string& domain,
            const TrainOptions::DomainToGramMatrixFilename& gram_matrices_files_map);

    /*
     * Returns the Gram's matrix, assuming it is already built.
     */
    const GramMatrix* Get(const std::string& domain) const {
        DomainToGramMatrix::const_iterator it = domainToGramMatrix.find(domain);
        return (it != domainToGramMatrix.end() ? it->second : NULL);
    }

private:
    DomainToGramMatrix domainToGramMatrix;
    // Disallowed.
    GramMatrixManager& operator=(const GramMatrixManager& manager);
}; // end GramMatrixManager

} // end namespace Regularization

#endif /* GRAM_MATRIX_MANAGER_H */
