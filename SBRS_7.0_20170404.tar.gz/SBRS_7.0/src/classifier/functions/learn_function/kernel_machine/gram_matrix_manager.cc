/*
 * gram_matrix_manager.cc
 *
 *  Created on: Dec 21, 2013
 *      Author: michi
 */

#include "classifier/functions/learn_function/kernel_machine/gram_matrix_manager.h"

#include "classifier/functions/learn_function/kernel_machine/gram_matrix.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"
#include "data/dataset.h"
#include "utils/general.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/stl_utils.h"


DEFINE_string(gram_matrix_type, "SYMMETRIC",
        "Optimization: type of memorization of the Gram matrix (SPARSE, DENSE, SYMMETRIC)");
DEFINE_bool(gram_matrix_normalization_by_row_sum, false,
            "Multiply by a factor so that the row with max sum of the values is equal to 1.");
DEFINE_bool(gram_matrix_normalization, false,
            "Multiply by a factor so that the row with max sum of the values is equal to 1.");

using namespace Regularization;

GramMatrixManager::~GramMatrixManager() {
    this->Clear();
}

GramMatrixManager::GramMatrixManager(const GramMatrixManager& manager) {
    this->Clear();
    for (DomainToGramMatrix::const_iterator iter = manager.domainToGramMatrix.begin();
         iter != manager.domainToGramMatrix.end(); ++iter) {
        domainToGramMatrix[iter->first] = iter->second->Clone();
    }
}

/* private */
GramMatrixManager& GramMatrixManager::operator=(const GramMatrixManager& manager) {
    FAULT("Should not be called.");
    return *this;
}

/*
 * Clear
 */
void GramMatrixManager::Clear() {
    std::DeallocMapOfPointers(&domainToGramMatrix);
    domainToGramMatrix.clear();
}

/*
 * Return the Gram's matrix
 */
const GramMatrix* GramMatrixManager::Get(const Dataset& dataset, const Kernel& kernel,
        const TrainOptions::DomainToGramMatrixFilename& gram_matrices_files_map) {
    const std::string& domain = dataset.Get(0)->GetDomain();
    const GramMatrix* gramMatrix = this->Get(domain, gram_matrices_files_map);
    if (gramMatrix != NULL) {
        return gramMatrix;
    }
    VMESSAGE(1, "Building Gram Matrix for " << domain);
    GramMatrix* builtGramMatrix = kernel.BuildGramMatrix(dataset);
    if (FLAGS_gram_matrix_normalization_by_row_sum) {
        const Value max_row_sum = builtGramMatrix->GetMaxRowSum();
        VMESSAGE(1, "Normalized GramMatrix by row sum.");
        builtGramMatrix->Multiply(1.0 / max_row_sum);
    }

    if (FLAGS_gram_matrix_normalization) {
        VMESSAGE(1, "Normalized GramMatrix.");
        builtGramMatrix->Normalize();
    }

    // save in the gramMatrixMap specifying as key the name of the dataset. Future
    // functions that have the same dataset will found immediately the gram matrix
    domainToGramMatrix[domain] = builtGramMatrix;
    return builtGramMatrix;
}

const GramMatrix* GramMatrixManager::Get(
        const std::string& domain,
        const TrainOptions::DomainToGramMatrixFilename& gram_matrices_files_map) {
    const GramMatrix* gramMatrix = this->Get(domain);
    if (gramMatrix != NULL) {
        return gramMatrix;
    }

    TrainOptions::DomainToGramMatrixFilename::const_iterator it = gram_matrices_files_map.find(domain);
    if (it == gram_matrices_files_map.end()) {
        return NULL;
    }

    GramMatrix* loadedGramMatrix = NULL;
    // Load GramMatrix from file.
    const std::string& filename = it->second.filename;
    const bool binary = it->second.binary;
    if (FLAGS_gram_matrix_type == "SPARSE") {
        VMESSAGE(1, "Loading SPARSE" << (binary ? " binary" : "") <<
                 " Gram Matrix from file " << filename << " for domain " << domain);
        loadedGramMatrix = new SparseGramMatrix();
    } else if (FLAGS_gram_matrix_type == "DENSE") {
        VMESSAGE(1, "Loading DENSE" << (binary ? " binary" : "") <<
                 " Gram Matrix from file " << filename << " for domain " << domain);
        loadedGramMatrix = new DenseGramMatrix();
    } else if (FLAGS_gram_matrix_type == "SYMMETRIC") {
        VMESSAGE(1, "Loading SYMMETRIC" << (binary ? " binary" : "") <<
                 " Gram Matrix from file " << filename << " for domain " << domain);
        loadedGramMatrix = new SymmetricGramMatrix();
    } else {
        FAULT("Wrong Type of Gram Matrix");
    }

    CHECK(loadedGramMatrix->Load(filename, binary));
    const Value max_row_sum = loadedGramMatrix->GetMaxRowSum();
    VMESSAGE(1, "Loaded GramMatrix. Size " <<
             loadedGramMatrix->GetRowSize() << " x " << loadedGramMatrix->GetRowSize() <<
             " MaxRowSum " << loadedGramMatrix->GetMaxRowSum());

    if (FLAGS_gram_matrix_normalization_by_row_sum) {
        VMESSAGE(1, "Normalized GramMatrix by row sum.");
        loadedGramMatrix->Multiply(1.0 / max_row_sum);
    }

    if (FLAGS_gram_matrix_normalization) {
        VMESSAGE(1, "Normalized GramMatrix.");
        loadedGramMatrix->Normalize();
    }

    // save in the gramMatrixMap specifying as key the name of the dataset. Future
    // functions that have the same dataset will found immediately the gram matrix
    domainToGramMatrix[domain] = loadedGramMatrix;
    return loadedGramMatrix;
}
