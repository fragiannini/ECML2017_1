/*
 * gram_matrix_utils.h
 *
 *  Created on: Oct 15, 2015
 *      Author: michi
 */

#ifndef GRAM_MATRIX_UTILS_H_
#define GRAM_MATRIX_UTILS_H_

#include <string>

namespace Regularization {
class Dataset;
class GramMatrix;
class TrainOptions;

class EmpiricalKernelMap {
public:
    static void Build(
            const double default_portion, const std::string& domain_to_portion_str,
            const TrainOptions& options, Dataset* dataset);

private:
    static void BuildInternal(
            const double portion, const GramMatrix& gram_matrix, Dataset* dataset);
};  // end EmpiricalKernelMap

}  // end Regularization

#endif /* GRAM_MATRIX_UTILS_H_ */
