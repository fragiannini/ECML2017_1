/*
 * polynomial_kernel.cc
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#include "classifier/functions/learn_function/kernel_machine/kernel/polynomial_kernel.h"

#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include "data/pattern.h"

namespace Regularization
{

/**
 * Applies the Polynomial kernel to the patterns x1 and x2
 */
Kernel::Value PolynomialKernel::Eval(const Pattern* x1, const Pattern* x2) const
{
    const Value dot = x1->DotProduct(x2);
    const Value val = a * dot + b;
    return static_cast<Value>(std::pow(val, p));
}

std::string PolynomialKernel::ToString() const
{
    std::ostringstream os;
    os << "Polynomial Kernel, a " << a << ", b " << b << ", p " << p << std::endl;
    return os.str();
}


bool PolynomialKernel::SaveToStream(std::ostream& os) const
{
    os << a << " " << b << " " << p << " ";
    return true;
}


bool PolynomialKernel::LoadFromStream(std::istream& is) {
    return static_cast<bool>(is >> a >> b >> p);
}

}  // end Regularization
