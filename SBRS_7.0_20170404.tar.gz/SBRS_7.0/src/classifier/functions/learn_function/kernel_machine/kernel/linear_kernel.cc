/*
 * polynomial_kernel.cc
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#include "classifier/functions/learn_function/kernel_machine/kernel/linear_kernel.h"

#include <iostream>
#include <sstream>
#include <string>
#include "data/pattern.h"

namespace Regularization
{

/*
 * Applies the Linear kernel to the patterns x1 and x2
 */
Kernel::Value LinearKernel::Eval(const Pattern* x1, const Pattern* x2) const
{
    return a * x1->DotProduct(x2) + b;
}

std::string LinearKernel::ToString() const
{
    std::ostringstream os;
    os << "Linear Kernel, a " << a << ", b " << b << std::endl;
    return os.str();
}

bool LinearKernel::SaveToStream(std::ostream& os) const
{
    os << a << " " << b << " ";
    return true;
}


bool LinearKernel::LoadFromStream(std::istream& is) {
    return static_cast<bool>(is >> a >> b);
}

}  // end Regularization
