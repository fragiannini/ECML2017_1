/*
 * tanh_kernel.h
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#ifndef TANH_KERNEL_H
#define TANH_KERNEL_H

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"

namespace Regularization
{
// tanh(a <x,x> + b)

class TanhKernel : public Kernel
{
    public:
        TanhKernel(Value a_, Value b_) : a(a_), b(b_)
        {
        }

        Value Eval(const Pattern* x1, const Pattern* x2) const;

        virtual Kernel* Clone() const
        {
            TanhKernel* kernel = new TanhKernel(a, b);
            return kernel;
        }
        virtual std::string Name() const { return "TAHN"; }
        virtual std::string ToString() const;
        virtual bool SaveToStream(std::ostream& os) const;
        virtual bool LoadFromStream(std::istream& is);

    private:
        Value a;
        Value b;

}; // end TanhKernel

} // end namespace Regularization
#endif /* TANH_KERNEL_H */
