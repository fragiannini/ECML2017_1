/*
 * gram_matrix_manager.h
 *
 *  Created on: 13/giu/2011
 *      Author: claudio
 */

#ifndef GRAM_MATRIX_H
#define GRAM_MATRIX_H

#include <iostream>
#include <sstream>
#include <string>

#include "utils/math/math_matrix.h"
#include "utils/math/math_sparse_matrix.h"
#include "utils/math/math_symmetric_matrix.h"
#include "utils/math/math_matrix_operations.h"
#include "data/dataset.h"

namespace Regularization
{

/**
 * Abstract class for GramMatrix
 **/
class GramMatrix
{
    public:

        /**
         * Constructors
         **/
        GramMatrix()
        {
        }

        GramMatrix(const std::string& name_) :
            name(name_)
        {
        }

        /**
         * Destructor
         **/
        virtual ~GramMatrix()
        {
        }

        /*
         * Get the name
         */
        inline const std::string& GetName()
        {
            return name;
        }

        /********************************************************************
         * Virtual Functions
         ********************************************************************/
        virtual const GramMatrix* Clone() const = 0;

        virtual const Index GetRowSize() const = 0;

        virtual Value Get(const Index x, const Index y) const = 0;
        virtual bool GetRow(const Index x, Math::Vector<Value>* res) const = 0;
        virtual Value GetMaxRowSum() const = 0;
        virtual void Multiply(const Math::Vector<Value>& weights, Math::Vector<Value>* res) const = 0;
        virtual void Multiply(const Value factor) = 0;
        virtual void Normalize() = 0;
        /*
         * Clear
         */
        virtual void Clear() = 0;
        virtual bool Initialized() const = 0;

        /*
         * Print
         */
        virtual void Print() const = 0;

        /*
         * Load
         */
        virtual bool Load(const std::string& filename, const bool binary) = 0;

        /*
         * Save
         */
        virtual bool Save(const std::string& filename) const {
            std::ofstream os(filename.c_str());
            return this->SaveToStream(os);
        }
        virtual std::string ToString() const {
            std::ostringstream os;
            this->SaveToStream(os);
            return os.str();
        }
        virtual bool SaveToStream(std::ostream& os) const = 0;
        virtual bool LoadFromStream(std::istream& os, const bool binary) = 0;

    protected:
        std::string name;
};

/**
 * Class represents a DenseGramMatrix
 **/
class DenseGramMatrix : public GramMatrix {
    private:
        // GramMatrix
        Math::Matrix<Index, Value>* denseGramMatrix;

    public:

        /**
         * Constructors
         **/
        DenseGramMatrix() : denseGramMatrix(NULL)
        {
        }

        DenseGramMatrix(const std::string& name_, const Math::Matrix<Index, Value>* matrix_) :
            GramMatrix(name_), denseGramMatrix(const_cast<Math::Matrix<Index, Value>*>(matrix_))
        {
        }

        /**
         * Destructor
         **/
        virtual ~DenseGramMatrix()
        {
            this->Clear();
        }

        /**
         * Copy
         **/
        virtual GramMatrix* Clone() const
        {
            return new DenseGramMatrix(this->name, this->denseGramMatrix);
        }

        virtual bool Initialized() const {
            return this->denseGramMatrix != NULL && denseGramMatrix->Size() > 0;
        }

        /*
         * Clear
         */
        virtual void Clear()
        {
            /* if (denseGramMatrix != NULL)
                delete denseGramMatrix; */
        }

        /*
         * Get the size of the Gram Matrix
         */
        virtual const Index GetRowSize() const
        {
            return denseGramMatrix->GetYSize();
        }

        virtual Value GetMaxRowSum() const {
            return denseGramMatrix->GetMaxRowSum();
        }

        /*
         * Get an element of the Gram matrix
         */
        virtual Value Get(const Index x, const Index y) const
        {
            return denseGramMatrix->Get(x, y);
        }
        /* non virtual, can be used for speed when appropriate */
        inline Value GetFast(const Index x, const Index y) const
        {
            return denseGramMatrix->Get(x, y);
        }

        /*
         * Get a row of the Gram matrix
         */
        virtual bool GetRow(const Index x, Math::Vector<Value>* res) const
        {
            return denseGramMatrix->GetRow(x, res);
        }

        /*
         * Get a the Gram matrix by a vector (weights vector)
         */
        virtual void Multiply(const Math::Vector<Value>& weights, Math::Vector<Value>* res) const
        {
            Math::MatrixOperations<Index, Value>::Multiply(*denseGramMatrix, weights, res);
        }

        virtual void Multiply(const Value factor)
        {
            denseGramMatrix->MultiplyInPlace(factor);
        }

        virtual void Normalize() {
            for (Index i = 0; i < this->GetRowSize(); ++i) {
                for (Index j = 0; j < (this->GetRowSize() - i); ++j) {
                    const Value val = denseGramMatrix->Get(i, j) /
                            std::sqrt(denseGramMatrix->Get(i, i) * denseGramMatrix->Get(j, j));
                    denseGramMatrix->Set(i, j, val);
                }
            }
        }

        /*
         * Print
         */
        virtual void Print() const
        {
            denseGramMatrix->Print();
        }

        /*
         * Load
         */
        virtual bool Load(const std::string& filename, const bool binary)
        {
            this->Clear();
            denseGramMatrix = new Math::Matrix<Index, Value>();
            if (binary)
                return denseGramMatrix->LoadBinary(filename);
            return denseGramMatrix->Load(filename);
        }

        virtual bool LoadFromStream(std::istream& is, const bool binary)
        {
            if (binary)
                return denseGramMatrix->LoadBinaryFromStream(is);
            return denseGramMatrix->LoadFromStream(is);
        }

        /*
         * Save
         */
        virtual bool SaveToStream(std::ostream& os) const
        {
        	return denseGramMatrix->SaveToStream(os);
        }
}; // end DenseGramMatrix

/**
 * Class represents a SparseGramMatrix
 **/
class SparseGramMatrix : public GramMatrix
{
    private:

        // GramMatrix
        Math::SparseMatrix<Index, Value>* sparseGramMatrix;

    public:

        /**
         * Constructor
         **/
        SparseGramMatrix() : sparseGramMatrix(NULL)
        {
        }

        SparseGramMatrix(const std::string& name_, const Math::SparseMatrix<Index, Value>* matrix_) :
            GramMatrix(name_), sparseGramMatrix(const_cast<Math::SparseMatrix<Index, Value>*>(matrix_))
        {
        }

        /**
         * Destructor
         **/
        virtual ~SparseGramMatrix()
        {
            this->Clear();
        }

        /**
         * Copy
         **/
        virtual const GramMatrix* Clone() const
        {
            return new SparseGramMatrix(this->name, this->sparseGramMatrix);
        }

        virtual bool Initialized() const {
            return this->sparseGramMatrix != NULL && sparseGramMatrix->Size() > 0;
        }

        /*
         * Clear
         */
        virtual void Clear()
        {
            if (sparseGramMatrix != NULL)
                delete sparseGramMatrix;
        }

        /*
         * Get the size of the Gram Matrix
         */
        virtual const Index GetRowSize() const
        {
            return sparseGramMatrix->GetYSize();
        }

        virtual Value GetMaxRowSum() const {
            return sparseGramMatrix->GetMaxRowSum();
        }

        virtual void Multiply(const Value factor)
        {
            sparseGramMatrix->MultiplyInPlace(factor);
        }

        virtual void Normalize() { /* Not implemented */ }

        /*
         * Get an element of the Gram matrix
         */
        virtual Value Get(const Index x, const Index y) const
        {
            return sparseGramMatrix->Get(x, y);
        }
        /* non virtual, can be used for speed when appropriate */
        inline Value GetFast(const Index x, const Index y) const
        {
            return sparseGramMatrix->Get(x, y);
        }

        /*
         * Get a row of the Gram matrix
         * Note: the resulting vector is dense while the row of the matrix is
         * sparse
         */
        virtual bool GetRow(const Index x, Math::Vector<Value>* res) const
        {
            const Math::SparseMatrix<Index, Value>::Row* row = sparseGramMatrix->Get(x);

            for (unsigned int i = 0; i < res->Size(); ++i)
            {
                Math::SparseMatrix<Index, Value>::Row::const_iterator iter = row->find(i);

                if (iter != row->end())
                {
                    (*res).Set(i, iter->second);
                }

                else
                {
                    (*res).Set(i, static_cast<Value>(0));
                }
            }

            return true;
        }

        /*
         * Get a the Gram matrix by a vector (weights vector)
         */
        virtual void Multiply(const Math::Vector<Value>& weights, Math::Vector<Value>* res) const
        {
            Math::SparseMatrixOperations<Index, Value>::Multiply(*sparseGramMatrix, weights, res);
        }

        /*
         * Print
         */
        virtual void Print() const
        {
            sparseGramMatrix->Print();
        }

        /*
         * , const bool binary
         */
        virtual bool Load(const std::string& filename, const bool binary)
        {
            this->Clear();
            sparseGramMatrix = new Math::SparseMatrix<Index, Value>();
            if (binary)
                return sparseGramMatrix->LoadBinary(filename);
            return sparseGramMatrix->Load(filename);
        }

        virtual bool LoadFromStream(std::istream& is, const bool binary)
        {
            if (binary)
                return sparseGramMatrix->LoadBinaryFromStream(is);
            return sparseGramMatrix->LoadFromStream(is);
        }

        /*
         * Save
         */
        virtual bool SaveToStream(std::ostream& os) const
        {
        	return sparseGramMatrix->SaveToStream(os);
        }
}; // end SparseGramMatrix

/**
 * Class represents a SymmetricGramMatrix
 **/
class SymmetricGramMatrix : public GramMatrix
{
    private:

        // GramMatrix
        Math::SymmetricMatrix<Index, Value>* symmetricGramMatrix;

    public:

        /**
         * Constructors
         **/
        SymmetricGramMatrix() : symmetricGramMatrix(NULL)
        {
        }

        SymmetricGramMatrix(const std::string& name_, const Math::SymmetricMatrix<Index, Value>* matrix_) :
            GramMatrix(name_), symmetricGramMatrix(const_cast<Math::SymmetricMatrix<Index, Value>*>(matrix_))
        {
        }

        /**
         * Destructor
         **/
        virtual ~SymmetricGramMatrix()
        {
            if (symmetricGramMatrix)
                delete symmetricGramMatrix;
        }

        /**
         * Copy
         **/
        virtual const GramMatrix* Clone() const
        {
            return new SymmetricGramMatrix(this->name, this->symmetricGramMatrix);
        }

        virtual bool Initialized() const {
            return this->symmetricGramMatrix != NULL && symmetricGramMatrix->Size() > 0;
        }

        /*
         * Clear
         */
        virtual void Clear()
        {
            if (symmetricGramMatrix != NULL)
                delete symmetricGramMatrix;
        }

        /*
         * Get the size of the Gram Matrix
         */
        virtual const Index GetRowSize() const
        {
            return symmetricGramMatrix->GetYSize();
        }

        virtual Value GetMaxRowSum() const {
            return symmetricGramMatrix->GetMaxRowSum();
        }

        virtual void Multiply(const Value factor)
        {
            symmetricGramMatrix->MultiplyInPlace(factor);
        }

        virtual void Normalize() {
            for (Index i = 0; i < this->GetRowSize(); ++i) {
                for (Index j = i; j < this->GetRowSize(); ++j) {
                    const Value val =
                            symmetricGramMatrix->Get(i, j) /
                            std::sqrt(symmetricGramMatrix->Get(i, i) * symmetricGramMatrix->Get(j, j));
                    symmetricGramMatrix->Set(i, j, val);
                }
            }
        }

        /*
         * Get an element of the Gram matrix
         */
        virtual Value Get(const Index x, const Index y) const
        {
            return symmetricGramMatrix->Get(x, y);
        }
        /* non virtual, can be used for speed when appropriate */
        inline Value GetFast(const Index x, const Index y) const
        {
            return symmetricGramMatrix->Get(x, y);
        }

        /*
         * Get a row of the Gram matrix
         */
        virtual bool GetRow(const Index x, Math::Vector<Value>* res) const
        {
            return symmetricGramMatrix->GetRow(x, res);
        }

        /*
         * Get a the Gram matrix by a vector (weights vector)
         */
        virtual void Multiply(const Math::Vector<Value>& weights, Math::Vector<Value>* res) const
        {
            Math::SymmetricMatrixOperations<Index, Value>::Multiply(*symmetricGramMatrix, weights, res);
        }

        /*
         * Print
         */
        virtual void Print() const
        {
            symmetricGramMatrix->Print();
        }

        /*
         * Load
         */
        virtual bool Load(const std::string& filename, const bool binary)
        {
            this->Clear();
        	symmetricGramMatrix = new Math::SymmetricMatrix<Index, Value>();
        	if (binary)
                return symmetricGramMatrix->LoadBinary(filename);
        	return symmetricGramMatrix->Load(filename);
        }
        virtual bool LoadFromStream(std::istream& is, const bool binary)
        {
            if (binary)
                return symmetricGramMatrix->LoadBinaryFromStream(is);
            return symmetricGramMatrix->LoadFromStream(is);
        }

        /*
         * Save
         */
        virtual bool SaveToStream(std::ostream& os) const
        {
        	return symmetricGramMatrix->SaveToStream(os);
        }
}; // end SymmetricGramMatrix

} // end namespace Regularization

#endif /* GRAM_MATRIX_MANAGER_H */
