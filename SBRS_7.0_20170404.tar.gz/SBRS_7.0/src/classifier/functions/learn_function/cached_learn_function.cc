#include "classifier/functions/learn_function/cached_learn_function.h"
#include "data/pattern.h"


using namespace Regularization;

CachedLearnFunction::CachedLearnFunction(
        const Function::ID& id_,
        const Function::TYPE predicate_type_,
        const Function::Arity arity_,
        const std::string& domain_,
        const Value balance_weight_,
        const bool cache_enabled_) :
        LearnFunction(id_, predicate_type_, arity_, domain_, balance_weight_),
        cache_enabled(cache_enabled_) {
}

CachedLearnFunction::CachedLearnFunction(const CachedLearnFunction& function) :
                        LearnFunction(function),
                        cache_enabled(function.cache_enabled) {
}

Value CachedLearnFunction::EvalInternal(const Pattern& pattern) const {
    /* CHECK_EQ_WITH_MESSAGE(pattern.GetDomain(), this->domain,
            "Can not eval pattern from wrong domain " + pattern.GetDomain() + " " + this->domain); */

    Value value = 0.0;
#if __ACTIVATE_OPENMP_TRAINER__ > 1 || __ACTIVATE_OPENMP_CLASSIFIER__ > 0 || __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp critical
#endif
    {
        if (!cache_enabled) {
            // No cache, always call the underlying function.
            value = this->RunEval(pattern);
        } else {
            // Check if the value is in the cache.
            const std::string& pattern_name = pattern.GetName();
            FunctionValues::const_iterator iter = functionValues.find(pattern_name);
            if (iter != functionValues.end()) {
                value = iter->second;
            } else {
                value = this->RunEval(pattern);
                const_cast<CachedLearnFunction*>(this)->functionValues[pattern_name] = value;  // cache the value.
            }
        }
    }  // end critical section
    return value;
}

/**
 * Set the W_k weights vector
 */
void CachedLearnFunction::Set(const Math::Vector<Value>& weights_)
{
  this->LearnFunction::Set(weights_);
  if (cache_enabled && !functionValues.empty()) {
      functionValues.clear();
  }
}

/**
 * Update the W_k weights vector
 */
void CachedLearnFunction::Update(const Math::Vector<Value>& derivative) {
#if __ACTIVATE_OPENMP_TRAINER__ > 1
#pragma omp critical
#endif
    {
        this->LearnFunction::Update(derivative);
        if (cache_enabled && !functionValues.empty()) {
            functionValues.clear();
        }
    }  // end critical section
}

/**
 * Update the i-th (w_k)i weights
 */
void CachedLearnFunction::Update(const Index i, const Value delta) {
#if __ACTIVATE_OPENMP_TRAINER__ > 1
#pragma omp critical
#endif
    {
        this->LearnFunction::Update(i, delta);
        if (cache_enabled && !functionValues.empty()) {
            functionValues.clear();
        }
    }  // end critical section
}
