/*
 * logic_constraint_utils.cc
 *
 *  Created on: Feb 24, 2014
 *      Author: michi
 */

#include "classifier/functions/learn_function/squashing.h"

#include <sstream>
#include "utils/general.h"


using namespace Regularization;

//////////////////////////////////////////
// LinearSquashingFunction
Value LinearSquashingFunction::LIMIT(const Value value) const {
    return value;
}

Value LinearSquashingFunction::LIMIT_DERIVATIVE(const Value value) const {
    return 1.0;
}

std::string LinearSquashingFunction::ToString() const {
    return "LinearSquashingFunction";
}

LinearSquashingFunction::~LinearSquashingFunction() {}

//////////////////////////////////////////
// LinearSaturatedSquashingFunction
Value LinearSaturatedSquashingFunction::LIMIT(const Value value) const {
    if (value > 1.0)
        return 1.0;
    if (value < 0.0)
        return 0.0;
    return value;
}

Value LinearSaturatedSquashingFunction::LIMIT_DERIVATIVE(const Value value) const {
    return (value >= 0.0 && value <= 1.0 ? 1.0 : 0.0);
}

std::string LinearSaturatedSquashingFunction::ToString() const {
    return "LinearSaturatedSquashingFunction";
}

LinearSaturatedSquashingFunction::~LinearSaturatedSquashingFunction() {}

//////////////////////////////////////////
// LinearBiasedSaturatedSquashingFunction
LinearBiasedSaturatedSquashingFunction::LinearBiasedSaturatedSquashingFunction(
        const Value thr_) :
        thr(thr_) {
    CHECK_GT(thr, static_cast<Value>(0));
    CHECK_LT(thr, static_cast<Value>(1));
}

Value LinearBiasedSaturatedSquashingFunction::LIMIT(const Value value) const {
    if (value > 1.0)
        return static_cast<Value>(1.0);
    if (value < 0.0)
        return static_cast<Value>(0.0);
    if (value <= thr)
        return static_cast<Value>(value * 0.5 / thr);

    return static_cast<Value>(0.5 + (value - thr) * 0.5 / (1.0 - thr));
}

Value LinearBiasedSaturatedSquashingFunction::LIMIT_DERIVATIVE(const Value value) const {
    return (value <= thr ? 0.5 / thr : 0.5 / (1.0 - thr));
}

std::string LinearBiasedSaturatedSquashingFunction::ToString() const {
    std::ostringstream os;
    os << "LinearBiasedSaturatedSquashingFunction " << thr;
    return os.str();
}

LinearBiasedSaturatedSquashingFunction::~LinearBiasedSaturatedSquashingFunction() {}

//////////////////////////////////////////
// SigmoidSquashingFunction
SigmoidSquashingFunction::SigmoidSquashingFunction(
        const Value squashing_function_slope_) :
    squashing_function_slope(squashing_function_slope_) {
}

Value SigmoidSquashingFunction::LIMIT(const Value value) const {
    return static_cast<Value>(1.0 /
            (1.0 + std::exp(-squashing_function_slope * (value - 0.5))));
}
Value SigmoidSquashingFunction::LIMIT_DERIVATIVE(const Value value) const {
    const Value num = std::exp(-squashing_function_slope * (value - 0.5));
    return static_cast<Value>(squashing_function_slope * num / std::pow(1.0 + num, 2.0));
}

std::string SigmoidSquashingFunction::ToString() const {
    std::ostringstream os;
    os << "SigmoidSquashingFunction " << squashing_function_slope;
    return os.str();
}

SigmoidSquashingFunction::~SigmoidSquashingFunction() { }

//////////////////////////////////////////
// Factory

/* static */
SquashingFunction* SquashingFunction::Build(const SquashingFunction::Type type, const Value param = 0.5) {
    switch (type) {
    case LINEAR:
        return new LinearSquashingFunction();
    case SIGMOID:
        return new SigmoidSquashingFunction(param);
    case LINEAR_SATURATED:
        return new LinearSaturatedSquashingFunction();
    case LINEAR_BIASED_SATURATED:
        return new LinearBiasedSaturatedSquashingFunction(param);
    case NONE:
        return NULL;
    default:
        FAULT("Unknown SquashingFunctionType: " << type);
    }
    return NULL;
}

/* static */
SquashingFunction::Type SquashingFunction::TypeFromName(const std::string& name) {
    if (name == "LINEAR")
        return LINEAR;
    if (name == "SIGMOID")
        return SIGMOID;
    if (name == "LINEAR_SATURATED")
        return LINEAR_SATURATED;
    if (name == "LINEAR_BIASED_SATURATED")
        return LINEAR_BIASED_SATURATED;
    if (name == "NONE")
        return NONE;
    FAULT("Unknown ActivationFunctionType: " << name);
    return UNKNOWN;
}

// Factory method
/* static */
SquashingFunction* SquashingFunction::Build(const std::string& name, const Value param = 0.5) {
    const Type type = TypeFromName(name);
    return SquashingFunction::Build(type, param);
}
