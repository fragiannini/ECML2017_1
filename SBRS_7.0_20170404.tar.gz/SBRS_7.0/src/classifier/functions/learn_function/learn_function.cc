#include "classifier/functions/learn_function/learn_function.h"

#include "classifier/functions/learn_function/squashing.h"  // for SquashingFunction
#include "data/dataset.h"
#include "data/examples.h"
#include "data/pattern.h"
#include "train/loss/loss_function.h"  // for LossFunction
#include "utils/gflags/gflags/gflags.h"


// Squashing Function
DEFINE_string(squashing_function_type,
              "LINEAR_SATURATED", "Type of the default squashing function: "
              "LINEAR y = x, LINEAR_SATURATED min(max(0,x),1), "
              "SIGMOID 1 / (1 + exp(-slope*(x-0.5))). "
              "Note: values must be in the [0,1] range for the continuous logic to be valid");
DEFINE_double(squashing_function_slope, 4.4,
              "The slope of the SIGMOID squashing function. "
              "NOTE: to have a sigmoid equal to 0.99 for a given x > 0 the slope have to be equal to -log 0.01 / (x - 0.5)");
DEFINE_string(per_function_squashing_function_type, "",
              "Function specific squashing function. Format: id1:squashing1:param1,id2,squashing2:param,...");


using namespace Regularization;

LearnFunction::LearnFunction(const Function::ID& id_,
        const Function::TYPE predicate_type_,
        const Function::Arity arity_,
        const std::string& domain_,
        const Value balance_weight_) :
    Function(id_, predicate_type_, arity_, domain_),
    balance_weight(balance_weight_) {
    this->SetSquashingFunction();
}

LearnFunction::LearnFunction(const LearnFunction& function) :
        Function(function),
        balance_weight(function.balance_weight) {
    this->SetSquashingFunction();
}


LearnFunction::~LearnFunction() { }

/*
 *  Eval the function and applies a squashing function on it if requested.
 */
Value LearnFunction::Eval(const Pattern& pattern) const {
    const Value value = this->EvalInternal(pattern);
    return (squashing_function.Get() != NULL ? squashing_function->LIMIT(value) : value);
}

/**
 * Set the W_k weights vector
 */
void LearnFunction::Set(const Math::Vector<Value>& weights_) {
    CHECK_EQ(weights.Size(), weights_.Size());
    weights.Copy(weights_);
}

/**
 * Update the W_k weights vector
 */
void LearnFunction::Update(const Math::Vector<Value>& derivative)
{
    // w = w - \delta Error / \delta w
    weights.SubInPlace(derivative);
}

/**
 * Update the i-th (w_k)i weights
 */
void LearnFunction::Update(const Index i, const Value delta) {
    // w = w - \delta Error / \delta w
    if (delta != static_cast<Value>(0))
        weights.Set(i, weights.Get(i) - delta);
}

Value LearnFunction::EvalLabeledError(
        const Dataset* dataset_,
        const Examples* examples,
        const LossFunction& labeled_loss_function) const {
    if (examples == NULL) {
        return 0.0;
    }

    const Examples::PerFunctionExamples* fexamples = examples->GetExamplesForPredicate(this->GetId());
    if (fexamples == NULL) {
      return 0.0;
    }

    Value sum = static_cast<Value>(0.0);
    for (unsigned int i = 0; i < fexamples->size(); ++i) {
        const Value y = (*fexamples)[i]->value;
        const Index index = dataset_->GetPatternIndexOrDie((*fexamples)[i]->pattern);
        const Value fx = this->Eval(*dataset_->Get(index));
        const Value err = (y != 0 ? balance_weight : 1.0) *
                labeled_loss_function.Eval(LossFunction::MAP_TO(fx), LossFunction::MAP_TO(y));
        sum += err;
    }

    return sum;
}

void LearnFunction::GetLabeledErrorGradient(const Dataset* dataset_,
        const Examples::PerFunctionExamples* fexamples,
        const LossFunction& labeled_loss_function,
        Math::Vector<Value>* derivative_labeled_part) const {
    CHECK_EQ(weights.Size(), derivative_labeled_part->Size());
    derivative_labeled_part->SetAll(0);
    for (unsigned int i = 0; i < fexamples->size(); ++i) {
        const Value y = (*fexamples)[i]->value;
        const Pattern* pattern = dataset_->GetByNameOrDie((*fexamples)[i]->pattern);
        const Value eval_derivative = (y != 0 ? balance_weight : 1.0) *
                labeled_loss_function.EvalDerivative(
                LossFunction::MAP_TO(this->Eval(*pattern)), LossFunction::MAP_TO(y));
        if (eval_derivative == 0.0) {
            continue;
        }

        this->AccumulateGradient(*pattern, eval_derivative, derivative_labeled_part);
    }
}

bool LearnFunction::AccumulateGradient(const Pattern& pattern,
        const Value weight,
        Math::Vector<Value>* derivative) const {
    const Value value = (squashing_function.Get() != NULL ?
            squashing_function->LIMIT_DERIVATIVE(this->Eval(pattern)) : 1.0f);
    return AccumulateGradientInternal(pattern, value * weight, derivative);
}

void LearnFunction::SetSquashingFunction() {
    squashing_function.Reset(NULL);

    std::vector<std::string> squashing_strs;
    StringUtils::SplitToVector(
            FLAGS_per_function_squashing_function_type, &squashing_strs, ",", true);
    for (unsigned int i = 0; i < squashing_strs.size(); ++i) {
        std::vector<std::string> squashing_str;
        StringUtils::SplitToVector(squashing_strs[i], &squashing_str, ":", false);
        CHECK_EQ(static_cast<int>(squashing_str.size()), 3);
        CHECK(!squashing_str[0].empty() && !squashing_str[1].empty() && !squashing_str[2].empty());
        if (squashing_str[0] != this->GetId())  continue;

        std::istringstream is(squashing_str[2]);
        const double param = StringUtils::ReadElementOrDie<double>(is);
        squashing_function.Reset(SquashingFunction::Build(squashing_str[1], param));
    }

    if (squashing_function.Get() == NULL) {
        squashing_function.Reset(SquashingFunction::Build(
                FLAGS_squashing_function_type, FLAGS_squashing_function_slope));
    }
}
