#include <string>
#include <vector>
#include "classifier/functions/learn_function/map_function.h"
#include "utils/general.h"
#include "utils/math/math_vector_operations.h"
#include "utils/string_utils.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "train/loss/quadratic_loss_function.h"
#include "utils/gtl_utils.h"


using namespace std;
using namespace Regularization;

MapFunction::MapFunction(const Function::ID id_, const Function::TYPE predicate_type_,
                         const Function::Arity arity_, const std::string& domain_,
                         const Value bias_,
                         const Dataset* dataset_) :
    LearnFunction(id_, predicate_type_, arity_, domain_, 1.0),
    dataset(dataset_), bias(bias_) {
    CHECK_NE_NULL(dataset);

    weights.Init(dataset->Size());
    weights.SetAll(bias);
    function_initial_values.Init(dataset->Size());
    function_initial_values.SetAll(bias);
}

/**
 * Copy constructor:
 */
MapFunction::MapFunction(const MapFunction& mapFunction) :
    LearnFunction(mapFunction.GetId(), mapFunction.GetType(),
                  mapFunction.GetArity(), mapFunction.GetDomain(), 1.0),
    dataset(mapFunction.dataset),
    bias(mapFunction.bias) {
    weights.Copy(mapFunction.weights);
    function_initial_values.Copy(mapFunction.function_initial_values);
}

Function* MapFunction::Clone() const {
    return new MapFunction(*this);
}

Value MapFunction::EvalInternal(const Pattern& pattern) const {
    // Costly check for such a simple function.
    /* CHECK_EQ_WITH_MESSAGE(pattern.GetDomain(), this->domain,
            "Can not eval pattern from wrong domain " + pattern.GetDomain() + " " + this->domain); */
    const Index index = dataset->GetPatternIndexOrDie(pattern.GetName());
    return weights.Get(index);
}

void MapFunction::SetValue(const std::string& patternName, const Value val) {
    const Index index = dataset->GetPatternIndexOrDie(patternName);
    weights.Set(index, val);
}

/**
 * Get the derivative of the function with respect to the weights on a
 * training point.
 */
bool MapFunction::AccumulateGradientInternal(
        const Pattern& pattern,
        const Value weight,
        Math::Vector<Value>* derivative) const {
    // Costly check for this simple function.
    // CHECK_EQ(static_cast<Index>(derivative->Size()), weights.Size());
    const Index index = dataset->GetPatternIndexOrDie(pattern.GetName());
    derivative->Add(index, weight * 1.0);
    return true;
}

/*
 * Eval the regularization error
 */
Value MapFunction::EvalRegularizationError() const {
    Value error = static_cast<Value>(0);

    // accumulate the loss for each dataset point
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel default(none) shared(error)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for schedule(static,500) reduction(+:error)
#endif
        for (Index i = 0; i < static_cast<Index>(dataset->Size()); ++i) {
            const Value diff = weights.Get(i) - function_initial_values.Get(i);
            error += diff * diff;
        }
    }  // end parallel section
    return 0.5 * error;
}

/**
 * Evaluate the derivative of regularization error part of the cost function.
 */
void MapFunction::GetRegularizationErrorGradient(
        Math::Vector<Value>* derivative_regularization_part) const {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel default(none) shared(derivative_regularization_part)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for schedule(static,100)
#endif
        for (Index i = 0; i < static_cast<Index>(dataset->Size()); ++i) {
            const Value eval_derivative = weights.Get(i) - function_initial_values.Get(i);
            derivative_regularization_part->Add(i, eval_derivative);
        }
    }  // end parallel section
}

void MapFunction::InternalClear() {
    weights.Clear();
}

/**
 * Save to stream
 **/
bool MapFunction::InternalSaveToStream(ostream& os) const {
    if (weights.Size() > 0) {
        Index i = 0;
        for (; i < weights.Size() - 1; ++i) {
            os << dataset->Get(i)->GetName() << ":" << weights[i] << ",";
        }
        os << dataset->Get(weights.Size() - 1)->GetName() << ":" << weights[i];
    }
    os << endl;
    return true;
}

bool MapFunction::InternalLoadFromStream(istream& is)
{
    this->InternalClear();

    VMESSAGE(1, "Loading map function "<< this->GetId());
    map<string, Value> values_map;
    string string_values;
    CHECK(static_cast<bool>(is >> string_values));
    StringUtils::SplitToMapByType(string_values, &values_map, ",", ":", static_cast<Value>(0), 0);

    weights.Init(values_map.size());
    for (map<string, Value>::const_iterator it = values_map.begin();
         it != values_map.end(); ++it) {
        bool found = false;
        const Index pattern_index = dataset->GetPatternIndex(it->first, &found);
        if (found) {
            weights.Set(pattern_index, it->second);
        }
    }
    return true;
}

bool MapFunction::InitFromFunction(const LearnFunction& function_) {
    VMESSAGE(1, "MapFunction " << this->id << " will be inited from Function "
             << function_.GetId());
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp for
#endif
        for (Index i = 0; i < weights.Size(); ++i) {
            const Pattern* pattern = dataset->Get(i);
            const Value val = function_.Eval(*pattern);
            weights.Set(i, val);
            function_initial_values.Set(i, val);

            if (weights.Size() > static_cast<Index>(100) &&
                    i % (weights.Size() / 100) == 0) {
                VPRINT(1, "\rLoading " << id << " " <<
                        100 * (i + 1) / weights.Size() << "/" << 100);
            }
        }
    }  // end parallel section

    VPRINTLN(1, "\rLoading " << id << " processed 100/100");

    return true;
}

bool MapFunction::InitFromExamples(const Examples& examples) {
    const Examples::PerFunctionExamples* examples_per_function =
            examples.GetExamplesForPredicate(id);
    if (examples_per_function == NULL)  return true;

#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for
#endif
        for (unsigned int i = 0; i < examples_per_function->size(); ++i) {
            const Index index = dataset->GetPatternIndexOrDie(
                    (*examples_per_function)[i]->pattern);
            const Value value = (*examples_per_function)[i]->value;
            weights.Set(index, value);
            function_initial_values.Set(index, value);
        }
    }  // end parallel section

    return true;
}

bool MapFunction::InitFromPrior(const Value default_value) {
    VMESSAGE(1, "MapFunction " << this->id << " inited from default " << default_value);
    weights.SetAll(default_value);
    return true;
}

bool MapFunction::Init(
        const LearnFunction* lfunction, const Examples* examples,
        const Value default_value) {
    if (lfunction != NULL) {
        if (!this->InitFromFunction(*lfunction))  return false;
    } else {  // use prior.
        if (!this->InitFromPrior(default_value))  return false;
    }

    if (examples != NULL) {  // if available train examples take priority.
        if (!this->InitFromExamples(*examples))   return false;
    }

    return true;
}
