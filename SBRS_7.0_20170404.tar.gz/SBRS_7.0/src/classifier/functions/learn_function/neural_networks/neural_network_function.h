/*
 * File:   neural_network_function.h
 * Author: Michi
 *
 * Created on 07 November 2013, 19.47
 */

#ifndef NEURAL_NETWORK_FUNCTION_H
#define NEURAL_NETWORK_FUNCTION_H

#include <iostream>
#include <map>
#include <string>
#include "classifier/functions/learn_function/cached_learn_function.h"
#include "data/examples.h"
#include "classifier/functions/learn_function/neural_networks/BP/myBP.h"
#include "utils/math/math_vector.h"


namespace Regularization {
class TrainOptions;

class NeuralNetworkFunction : public CachedLearnFunction {
public:

#ifdef __SPARSE_NN__
    typedef BP::SparseNET NN;
#else
    typedef BP::NET NN;
#endif

    template<typename NN>
    static NN* CreateNeuralNetworkFromOptions(
            const TrainOptions& options,
            const Index input_size, const Index output_size,
            const Function::ID& id);

    /********************************
     * Constructors.
     ********************************/
    // Builds an empty network, useful only to call LoadFromStream or LoadFromFile.
    NeuralNetworkFunction();

    /**
     * Build a NeuralNetworkFunction.
     * - if pre_built_inputs=true, the NN inputs for the training dataset are converted off-line in the
     *   constructor. This setting uses more memory but less cpu during training.
     */
    NeuralNetworkFunction(
            const Function::ID& id_,
            const Function::TYPE predicate_type,
            const Function::Arity arity,
            const std::string& domain_,
            const Value bias_,
            const Dataset* dataset,
            const TrainOptions* options,
            // Options allowing to reuse an externally allocated network shared across different functions.
            NN* pre_built_shared_net_ = NULL,
            const Index pre_built_shared_net_output_index_ = 0);

    /**
     * Copy constructor
     */
    NeuralNetworkFunction(const NeuralNetworkFunction& nn_function);

    Function* Clone() const;

    /********************************
     * Destructors.
     ********************************/
    virtual ~NeuralNetworkFunction();

    /***********************************************************
     * Update weight for kernel machine functions
     * update values for map functions
     ***********************************************************/
    virtual void Update(const Math::Vector<Value>& derivative);
    virtual void Update(const Index i, const Value delta);
    virtual void Set(const Math::Vector<Value>& vec_);

    /**************************************************************
     * Error / Derivative Error
     **************************************************************/
    virtual bool AccumulateGradientInternal(const Pattern& pattern,
            const Value weight,
            Math::Vector<Value>* derivative) const;

    // Eval the regularization error.
    virtual Value EvalRegularizationError() const;

    // Evaluate the derivative of regularization error part of the cost function.
    virtual void GetRegularizationErrorGradient(
            Math::Vector<Value>* derivative_regularization_part) const;

    virtual bool HasDropout() const {
        return (dropout_thr > 0 || input_dropout_thr > 0);
    }

    virtual void EndTrain();
    virtual void StartTrainIteration();
    virtual void EndTrainIteration();
    virtual void PrepareForCrossvalidation();
    virtual void EndCrossvalidation();
    virtual NN* ReleaseNeuralNetwork() {
        NN* ret = net;  // provide access to the underlying network.
        net = NULL;
        return ret;
    }
    virtual const NN* const GetNeuralNetwork() const {
        return net;  // provide const access to the underlying network.
    }
    virtual void SetSharedNeuralNetwork(NN* net_) {
        if (net != NULL && net != pre_built_shared_net) {
            delete net;  // previous net is owned an must be cleared.
        }
        pre_built_shared_net = net_;
        net = net_;
    }

protected:
    /**************************************************************
     * Eval
     **************************************************************/

    // Eval the function on the pattern of the test set
    // only kernel machine can evaluate a pattern not in training
    virtual Value RunEval(const Pattern& pattern) const;
    virtual Value RunEvalWithSharedNet(const Pattern& pattern) const;

    /************************************************************
     * I/O
     ************************************************************/
    virtual bool InternalLoadFromStream(std::istream& is);
    virtual bool InternalSaveToStream(std::ostream& os) const;
    virtual void InternalClear();

#ifdef __SPARSE_NN__
    typedef BP::SparsePattern NNinput;
    typedef std::map<std::string, NNinput> InputMap;
#else
    typedef BP::Pattern NNinput;
    typedef std::map<std::string, NNinput> InputMap;
#endif

    // Internally allocated network.
    NN* net;
    InputMap inputs;
    int input_size;
    // Externally allocated network.
    NN* pre_built_shared_net;
    const Index pre_built_shared_net_output_index;
    Index pre_built_shared_net_output_size;

    const bool pre_built_inputs;
    Value dropout_thr;
    Value input_dropout_thr;
    Value limit_weight_norm_by_neuron;
    Value bias;
}; // end NeuralNetworkFunction

} // end namespace Regularization
#endif /* NEURAL_NETWORK_FUNCTION_H */
