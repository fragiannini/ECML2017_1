/*
 * Copyright (C) 2003-2005. Michelangelo Diligenti. All Rights Reserved.
 */


#ifndef BH_H
#define BH_H 1

#include <iostream>
#include <limits>
#include <string>
#include <map>
#include <vector>
#include <cmath>

#include "data/basic_data_types.h"
#include "utils/math/math_vector.h"

// Forward declaration to make this friend of BP::basicNET.
namespace Regularization {
class NeuralNetworkFunction;
}  // end Regularization

namespace BP {
typedef Regularization::Index Index;
typedef Regularization::Value Value;

typedef std::vector<Value> Pattern; // pattern in input
typedef std::vector<Pattern> PatternSet; // set of patterns in input

typedef Index SparsePatternIndex;
typedef std::pair<SparsePatternIndex, Value> SparsePatternEntry;
typedef std::vector<SparsePatternEntry> SparsePattern;  // pattern in input
typedef std::vector<SparsePattern> SparsePatternSet;  // pattern in input

typedef Pattern Targets;
typedef PatternSet TargetSet;

class ActivationFunction {
  public:
    enum Type {
        LINEAR,
        SIGMOID,
        HYPERBOLIC_TANGENT,
        LECUN_HYPERBOLIC_TANGENT,
        RECTIFIEDLINEAR,
        LEAKYRECTIFIEDLINEAR,
        UNKNOWN
    };  // end Type

   virtual Value Function(Value arg) const = 0;
   virtual Value Derivative(Value arg) const = 0;
   virtual Value Min() const = 0;
   virtual Value Max() const = 0;
   virtual std::string GetTypeName() const = 0;
   virtual Type GetType() const = 0;
   virtual ~ActivationFunction() {}

   // Factory methods
   static ActivationFunction* Build(const Type type);
   static ActivationFunction* Build(const std::string& type);
   static Type TypeFromName(const std::string& name);
 };

class Linear : public ActivationFunction {
 public:
  Value Function(Value arg) const {
    return arg;
  }
  Value Derivative(Value /*arg*/) const {
    return 1;
  }
  Value Min() const { return std::numeric_limits<Value>::min(); }
  Value Max() const { return std::numeric_limits<Value>::max(); }
  std::string GetTypeName() const { return "LINEAR"; }
  Type GetType() const { return LINEAR; }
  virtual ~Linear() {}
};  // end class Linear

class RectifiedLinear : public ActivationFunction {
 public:
  Value Function(Value arg) const {
    return (arg > 0 ? arg : 0);
  }
  Value Derivative(Value arg) const {
    return (arg > 0 ? 1 : 0);
  }
  Value Min() const { return 0; }
  Value Max() const { return std::numeric_limits<Value>::max(); }
  std::string GetTypeName() const { return "RECTIFIEDLINEAR"; }
  Type GetType() const { return RECTIFIEDLINEAR; }
  virtual ~RectifiedLinear() {}
};  // end class RectifiedLinear

class LeakyRectifiedLinear : public ActivationFunction {
 private:
  static const Value a;
 public:
  Value Function(Value arg) const {
    return (arg > 0 ? arg : arg * a);
  }
  Value Derivative(Value arg) const {
    return (arg > 0 ? 1 : a);
  }
  Value Min() const { return -a * std::numeric_limits<Value>::max(); }
  Value Max() const { return std::numeric_limits<Value>::max(); }
  std::string GetTypeName() const { return "LEAKYRECTIFIEDLINEAR"; }
  Type GetType() const { return LEAKYRECTIFIEDLINEAR; }
  virtual ~LeakyRectifiedLinear() {}
};  // end class LeakyRectifiedLinear

class Sigmoid : public ActivationFunction {
 public:
  static const Value a;
  Value Function(const Value arg) const {
    const Value e_arg = std::exp(a * arg);
    return e_arg / (1 + e_arg);
    // return 0.5 * std::tanh(a * arg * 0.5) + 0.5;
  }
  Value Derivative(const Value arg) const {
    return a * arg * (1.0 - arg);
  }
  Value Min() const { return 0; }
  Value Max() const { return 1.0; }
  std::string GetTypeName() const { return "SIGMOID"; }
  Type GetType() const { return SIGMOID; }
  virtual ~Sigmoid() {}
};  // end class Sigmoid

class HyperbolicTangent : public ActivationFunction {
 public:
  Value Function(const Value arg) const {
    return static_cast<Value>(std::tanh(arg));
  }
  Value Derivative(const Value arg) const {
    return static_cast<Value>(1.0 - arg * arg);
  }
  Value Min() const { return static_cast<Value>(-1.0); }
  Value Max() const { return static_cast<Value>(+1.0); }
  std::string GetTypeName() const { return "HYPERBOLIC_TANGENT"; }
  Type GetType() const { return HYPERBOLIC_TANGENT; }
  virtual ~HyperbolicTangent() {}
};  // end class HyperbolicTangent

class LecunHyperbolicTangent : public ActivationFunction {
 private:
  static const Value a;
  static const Value b;
 public:
  Value Function(const Value arg) const {
    return static_cast<Value>(a * tanh(b * arg));
  }
  Value Derivative(const Value arg) const {
    return static_cast<Value>(a * (1.0-(arg*arg)/(a*a)) * b);
  }
  Value Min() const { return static_cast<Value>(-a); }
  Value Max() const { return static_cast<Value>(+a); }
  std::string GetTypeName() const { return "LECUN_HYPERBOLIC_TANGENT"; }
  Type GetType() const { return LECUN_HYPERBOLIC_TANGENT; }
  virtual ~LecunHyperbolicTangent() {}
};  // end class LecunHyperbolicTangent

enum TrainMode {
  BATCH = 0,
  PATTERN = 1,
  STOCHASTIC = 2
};  // end train_mode_type
  
class Layer {
 public:
  Index Units;              // - number of units in this layer
  Index lowerUnits;         // - number of units in the lower layer
  Value* Output;   // - output of i-th unit
  Value* Error;    // - error term of i-th unit
  Value** Weight;  // - connection weights to ith unit
  Value** WeightUpdateAccumulator;  // - connection weights to ith unit
  Value** WeightSave;    // - saved weights in stopped training
  Value** dWeight;       // - last weight deltas for momentum
  ActivationFunction* ofunction;
  Value dropout_thr;
  bool* dropouts;
  Layer(const Index lowerNumUnits,
        const Index numUnits,
        const Index level,
        const bool allocDweight,
        const bool allocSaveWeight,
        const ActivationFunction::Type ofunction_type,
        const Value dropout_thr_);
  int AllocSaveWeights(const Index lowerNumUnits, const Index numUnits);
  void DeallocSaveWeights();

  void Print() const;
  inline Index NumWeights() const {
    return (lowerUnits + 1) * Units;
  }
  void ResetDropouts(const Value dropout_thr_);
  ~Layer();
};  // end class Layer

class BasicNET {   // virtual abstract class
  ///////////////////////////////////
  // Data
 public:
  static const Index DEFAULT_N_EPOCHS;
  static const Value DEFAULT_BIAS;
  static const Value STOP_CONDITION;
  static const Value MIN_ERROR;
  static const Value MAX_RANDOM_WEIGHT_AT_INITIALIZATION;
  static const TrainMode DEFAULT_TRAIN_MODE;
  static const bool DEFAULT_USE_WEIGHT_SAVE; // weight save on/off

 private:
  bool weight_save_mode;
  friend class Regularization::NeuralNetworkFunction;
  // save best net in crossvalidation, but increases memory usage.
  bool useWeightSave; 

 protected:
  Layer** layer;      /* - hidden layers of this net */
  std::vector<ActivationFunction::Type> ofunction_types;
  Value Alpha;         /* - momentum factor           */
  Value Eta;           /* - learning rate             */
  Value Error;         /* - total net error           */
  Value bias;          /* - bias of each neuron       */

  Value EtaDecrement;  /* - learning rate increment   */
  Value EtaIncrement;  /* - learning rate decrement   */

  Index NUM_LAYERS; // num layers
  Index* Units; // num elements in each layer
  Index numInputs;

  Index num_units;
  Index num_weights;
  TrainMode train_mode;
  Value dropout_thr;
  Value input_dropout_thr;
  struct WeightPosition {
      Index layer;
      Index unit_upper;
      Index unit_lower;
      WeightPosition(Index layer_, Index unit_upper_, Index unit_lower_) :
          layer(layer_), unit_upper(unit_upper_), unit_lower(unit_lower_) {
      }
      WeightPosition() : layer(0), unit_upper(0), unit_lower(0) { }
      bool operator==(const WeightPosition& a) const {
          return (layer == a.layer && unit_lower == a.unit_lower && unit_upper == a.unit_upper);
      }
      bool operator!=(const WeightPosition& a) const {
          return !(*this == a);
      }
      friend std::ostream& operator<<(std::ostream& os, const WeightPosition& a) {
          os << a.layer << " " << a.unit_lower << " " << a.unit_upper;
          return os;
      }
  };

  // Vector mapping linear indexes into a weight positions.
  // This allows to easily serialize, de-serialize the weights to a and
  // from a vector. This is initialized by ComputeWeightPositions()
  std::vector<WeightPosition> weight_positions;

  ///////////////////////////////////
  // Methods
 public:
  BasicNET();
  BasicNET(Index nl, Index* theUnits, const ActivationFunction::Type ofunction_type);

  BasicNET(Index nl,  // set different activation functions for different layers
           Index* theUnits, const std::vector<ActivationFunction::Type>& ofunction_types);

  BasicNET(const BasicNET& N);

 protected:
  virtual void Init();
  virtual void Dealloc();

  ///////////////////////////////////
  // Getters ans setters
  inline Value getError() const
  {
    return Error;
  }
  inline void setAlpha(const Value a = 0.5)
  {
    Alpha = a;
  }
  void setDropout(const Value input_dropout_thr_, const Value dropout_thr_);

  inline Value getAlpha() const
  {
    return Alpha;
  }
  inline void setEta(const Value e = 0.1)
  {
    Eta = e;
  }
  inline Value getEta() const
  {
    return Eta;
  }

  inline void GetOutput(Value* const output) const {
      memcpy(output,
             layer[NUM_LAYERS]->Output,
             layer[NUM_LAYERS]->Units * sizeof(Value));
  }

  void GetWeights(Math::Vector<Value>* weights) const;
  // Get the weight update values and stores them in weightUpdateAccumulator
  // (which is cleared first.)
  void GetWeightUpdateAccumulator(
      Math::Vector<Value>* weightUpdateAccumulator) const;
  // Same as GetWeightUpdateAccumulator but updates are added in place to weightUpdateAccumulator.
  // Note that weightUpdateAccumulator.Size() must be equal to num_weights.
  void AddWeightUpdateAccumulator(
      Math::Vector<Value>* weightUpdateAccumulator) const;
  void SetWeights(const Math::Vector<Value>& weights) const;
  void SetWeight(Index index, const Value weight);

  inline TrainMode getTrainMode() const {
    return train_mode;
  }
  inline void setTrainMode(const TrainMode tm) {
    train_mode = tm;
  }
  inline bool getWeightSaveMode() {
    return weight_save_mode;
  }
  int setWeightSaveMode(const bool wsm);

  inline Index getUnits(Index u) const
  {
    return Units[u];
  }
  inline Index getNumLayers() const
  {
    return NUM_LAYERS;
  }
  void setNeuronOutputFunction(Value (*f) (Value), Value (*f1) (Value));

  // Print
  void PrintLayersWeights() const;
  void PrintLog(Index actualEpoch, Value cost) const;

  virtual void AdaptLearningRate(const Value oldError, const Value Error);
  // Generate the network with neurons with the specified activation function

  virtual Index Generate(const ActivationFunction::Type ofunction_type);
  // Generate the network with neurons with the specified activation functions:
  // the vector contains as many elements as layers.
  // activactionFunction[i] specifies the activation function for the i-th layer.
  virtual Index Generate(const std::vector<ActivationFunction::Type>& ofunction_types);

  // initialize each weight equal to consWt
  virtual void InitWeights(const Value constW = 0);

  void BackpropagateLayer(const Layer* Upper, Layer* Lower);
  void PropagateLayer(const Layer* Lower, Layer* Upper);

  // Initialize the weight_positions.
  void ComputeWeightPositions();
  void ComputeNumWeights();
  void ComputeNumUnits();

  // Rescaling functions.
  void ScaleWeights(const Value factor);
  void ScaleWeightsForDropout();
  // Keep the weight vector for each neuron below max-norm
  // ||w||_2 < max_norm
  void LimitWeightNormByNeuron(const Value max_norm);

 public:
  /////////////////////////////////////////
  // Public Interface
  inline Index NumWeights() const { return num_weights; }
  inline Index NumUnits() const { return num_units; }

  Value MaxG(Index startLayer = 1) const; // return the max gradient
  Value MaxWeight(Index startLayer = 1) const; // return the max weight
  // normalize the gradient respect factor
  void NormalizeG(Value factor);
  // normalize the weights respect factor
  void NormalizeWeights(const Value factor);

  void ClearOutputError();
  void ClearLayersError();

  // clear of the accumulated updates of the weights. Default, clear all layers
  void ClearUpdates(Index startFromLayer = 1);

  // random weights
  virtual void RandomWeights(
          unsigned long seed = 0,
          const Value max_value = MAX_RANDOM_WEIGHT_AT_INITIALIZATION);
  virtual void LecunRandomWeights(unsigned long seed = 0);

  void SaveWeights();
  void RestoreWeights();

  // update of the weights
  virtual void Update(const Value factor = 1) = 0;
  virtual void Propagate();
  virtual void Backpropagate();
  virtual void ComputeOutputError(const Targets& targets);
  virtual void SetOutputError(const Value* errors);
  virtual void AccumulateUpdates();
  virtual void ScaleErrors(const Value weight);
  // As above but accumulates on an external vector, scaled by weight, instead of
  // on the internal buffer.
  void AccumulateUpdates(Math::Vector<Value>* updates, const Value weight=1.0) const;

  // Maybe called externally at the end of training.
  void UnscaleWeightsForDropout();

  virtual ~BasicNET();

  /////////////////////////////////////
  // I/O

  // Save to file (ascii).
  virtual bool SaveToFile(const std::string& filename) const;
  // Save to file (binary).
  virtual bool BinarySaveToFile(const std::string& filename) const;
  // Save to stream (ascii)
  virtual bool SaveToStream(std::ostream& os) const;
  // Save to stream (binary)
  virtual bool BinarySaveToStream(std::ostream& os) const;
  // Load from file (ascii).
  virtual bool LoadFromFile(const std::string& filename);
  // Load from file (ascii).
  virtual bool BinaryLoadFromFile(const std::string& filename);
  // Load from ascii stream (saved by SaveFromStream()).
  virtual bool LoadFromStream(std::istream& is);

  // Load from binary stream (saved by BinarySaveFromStream()).
  virtual bool BinaryLoadFromStream(std::istream& fp);
  virtual void Print() const;

  /////////////////////////////////////////
  // Static functions
      static bool Equals(const BasicNET* a, const BasicNET* b,
                         const Value err = 0.0001);
};  // end basicNET

class NET : public BasicNET
{  // A NET:
 public:
  NET();
  NET(Index nl, Index* theUnits, const ActivationFunction::Type ofunction_type);

  NET(Index nl,  // set different activation functions for different layers
      Index* theUnits, const std::vector<ActivationFunction::Type>& ofunction_types);

  NET(const NET& N);

 protected:
  virtual bool Crossvalidate(const PatternSet& crossvalidation,
                             const TargetSet& crossvalidationTargets,
                             Value MinTestError);

 public:
  virtual void SetInput(const Pattern& input);
  virtual void Simulate(const Pattern& input, Value* Output = NULL);

  // Computes the gradient using the derivative definition:
  // dE(input)/dw = dE/dNN dNN/dw where
  // dNN/dw = lim_{\epsilon->0} [NN(w+\epsilon, input) - NN(w, input)] / \epsilon
  // dE/dNN must be computed and passed to this function as errors vector.
  // The output derivative is returned in derivative.
  // This is very slow and can be done only for small nets and is provided mainly for debugging.
  virtual void NumericDerivative(const Pattern& input, const Value* errors,
                                 const Value epsilon, Math::Vector<Value>* derivative);

  virtual Index Train(const PatternSet& inputs,
          const TargetSet& targets,
          Index Epochs = DEFAULT_N_EPOCHS) {
      return Train(inputs, targets, PatternSet(), TargetSet(), Epochs);
  }

  virtual Index Train(const PatternSet& inputs,
                     const TargetSet& targets,
                     const PatternSet& crossvalidation,
                     const TargetSet& crossvalidationTargets,
                     Index Epochs = DEFAULT_N_EPOCHS);

  virtual Value Test(const PatternSet& inputs, const TargetSet& targets);

  virtual void Update(const Value factor = 1); // update of the patterns

  virtual ~NET() { }
};  // end NET


class SparseNET : public BasicNET
{
 public:
  typedef std::vector<SparsePatternIndex> AllInputs;

 protected:
  SparsePattern theInput; // actual input of the net
  AllInputs allInput; // all indexes seen in a iteration

 public:
  SparseNET();

  SparseNET(Index nl, Index* theUnits, const ActivationFunction::Type ofunction_type);

  SparseNET(Index nl,  // set different activation functions for different layers
            Index* theUnits, const std::vector<ActivationFunction::Type>& ofunction_types);

  SparseNET(const SparseNET& N);

  virtual ~SparseNET();

  void SetInput(const SparsePattern& input);
  void SetAllInputs(const std::map<std::string, SparsePattern>& inputs);
  void SetAllInputs(const SparsePatternSet& inputs);

  // clear all not used weights
  void ClearInputLayerUpdates(bool allinputs);

  void Propagate();
  void PropagateInputLayer();
  void Simulate(const SparsePattern& Input, Value* Output = NULL);

  void AccumulateUpdates();
  // Accumulate the updates on the passed vector, scaled by the passed weight.
  void AccumulateUpdates(Math::Vector<Value>* updates, const Value weight=1.0) const;

  Value MaxG() const; // return the max gradient
  Value MaxWeight() const; // return the max weight

  void NormalizeG(const Value factor); // normalize the gradient respect factor
  void NormalizeWeights(const Value factor); // normalize the weights respect factor
  virtual void Update(Value factor = 1); // update of the patterns
  // update weights used in last pattern
  virtual void UpdateForPattern(const SparsePattern& Input,
                                Value factor = 1);

 protected:
  void Update_upper_layers(Value factor = 1); // update di layer da 2 a NUM_LAYERS

 public:
  virtual Index Train(const SparsePatternSet& inputs,
                    const TargetSet& targets,
                    Index Epochs = DEFAULT_N_EPOCHS) {
    const SparsePatternSet empty_crossvalidation;
    const TargetSet empty_crossvalidation_targets;
    return Train(inputs, targets, empty_crossvalidation, empty_crossvalidation_targets, Epochs);
  }
  Index Train(const SparsePatternSet& inputs, const TargetSet& targets,
            const SparsePatternSet& crossvalidation, const TargetSet& crossvalidationTargets,
            Index Epochs = DEFAULT_N_EPOCHS);
  Value Test(const SparsePatternSet& inputs, const TargetSet& targets);

  virtual bool Crossvalidate(const SparsePatternSet& Crossvalidation,
                             const TargetSet& crossvalidationTargets,
                             Value MinTestError);

  // Computes the gradient using the derivative definition:
  // dE(input)/dw = dE/dNN dNN/dw where
  // dNN/dw = lim_{\epsilon->0} [NN(w+\epsilon, input) - NN(w, input)] / \epsilon
  // dE/dNN must be computed and passed to this function as errors vector.
  // The output derivative is returned in derivative.
  // This is very slow and can be done only for small nets and is provided mainly for debugging.
  virtual void NumericDerivative(const SparsePattern& input, const Value* errors,
                                 const Value epsilon, Math::Vector<Value>* derivative);
};  // end sparseNET

class OneLayerNET : public NET
{
 public:
  OneLayerNET(const Index inputs,
              const Index outputs,
              const ActivationFunction::Type foutput_type);
  OneLayerNET(const OneLayerNET& N);

  virtual ~OneLayerNET() { }
};  // end OneLayerNET

class TwoLayersNET : public NET
{
 public:
  TwoLayersNET(const Index inputs,
               const Index hidden,
               const Index outputs,
               const ActivationFunction::Type foutput_type);
  TwoLayersNET(const Index inputs,
               const Index hidden,
               const Index outputs,
               const std::vector<ActivationFunction::Type>& foutput_types);
  TwoLayersNET(const TwoLayersNET& N);

  virtual ~TwoLayersNET() { }
};  // end TwoLayersNET

class Perceptron : public NET
{
 public:
  Perceptron();

  Perceptron(Index inputs, Index outputs);
  Perceptron(const Perceptron& N);

  Index TrainPerceptron(const PatternSet& Inputs,
                      const TargetSet& Targets,
                      Index Epochs = DEFAULT_N_EPOCHS);

  void ComputeOutputError(const Targets& Target);

  virtual ~Perceptron() { }
};  // end Perceptron

class SparsePerceptron : public SparseNET
{
 public:
  SparsePerceptron();

  SparsePerceptron(Index inputs, Index outputs);
  SparsePerceptron(const SparsePerceptron& N);

  Index TrainPerceptron(const SparsePatternSet& Inputs,
                      const TargetSet& Targets,
                      Index Epochs = DEFAULT_N_EPOCHS);
  void ComputeOutputError(const Targets& Target);

  virtual ~SparsePerceptron() { }
};  // end sparsePerceptron

class Autoassociator : public TwoLayersNET
{
 public:
  Autoassociator(const Index inputs,
                 const Index hidden,
                 const ActivationFunction::Type foutput_type);

  Autoassociator(const Autoassociator& N);
 
  virtual ~Autoassociator() { }

  Index TrainAutoass(const PatternSet& Inputs, Index Epochs = DEFAULT_N_EPOCHS);
};  // end Autoassociator

}  // end BP


#endif
