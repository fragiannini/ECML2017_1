/*
 * logic_constraint_utils.h
 *
 *  Created on: Feb 24, 2014
 *      Author: michi
 */

#ifndef __LEARN_FUNCTION_SQUASHING__
#define __LEARN_FUNCTION_SQUASHING__

#include <cmath>
#include <string>
#include "data/basic_data_types.h"

namespace Regularization
{

/********************************************************
 * Logic Utilities
 ********************************************************/

class SquashingFunction {
public:
    virtual Value LIMIT(const Value value) const = 0;
    virtual Value LIMIT_DERIVATIVE(const Value value) const = 0;
    virtual Value NOT(const Value value) const {
        return 1.0 - LIMIT(value);
    }
    virtual ~SquashingFunction() {}

    enum Type {
        LINEAR,
        LINEAR_SATURATED,
        LINEAR_BIASED_SATURATED,
        SIGMOID,
        NONE,
        UNKNOWN
    };  // end Type

    virtual std::string ToString() const = 0;

    // Factory methods
    static SquashingFunction* Build(const Type type, const Value param);
    static SquashingFunction* Build(const std::string& type, const Value param);
    static Type TypeFromName(const std::string& name);
};

class LinearSquashingFunction : public SquashingFunction {
public:
  virtual Value LIMIT(const Value value) const;
  virtual Value LIMIT_DERIVATIVE(const Value value) const;
  virtual std::string ToString() const;
  virtual ~LinearSquashingFunction();
};

class LinearSaturatedSquashingFunction : public SquashingFunction {
public:
    virtual Value LIMIT(const Value value) const;
    virtual Value LIMIT_DERIVATIVE(const Value value) const;
    virtual std::string ToString() const;
    virtual ~LinearSaturatedSquashingFunction();
};

class LinearBiasedSaturatedSquashingFunction : public SquashingFunction {
private:
    const Value thr;

public:
    LinearBiasedSaturatedSquashingFunction(const Value thr_);
    virtual Value LIMIT(const Value value) const;
    virtual Value LIMIT_DERIVATIVE(const Value value) const;
    virtual std::string ToString() const;
    virtual ~LinearBiasedSaturatedSquashingFunction();
};

class SigmoidSquashingFunction : public SquashingFunction {
private:
    const Value squashing_function_slope;

public:
    SigmoidSquashingFunction(const Value squashing_function_slope_);
    Value LIMIT(const Value value) const;
    Value LIMIT_DERIVATIVE(const Value value) const;
    virtual std::string ToString() const;
    virtual ~SigmoidSquashingFunction();
};

}  // end Regularization
#endif /* __LEARN_FUNCTION_SQUASHING__ */
