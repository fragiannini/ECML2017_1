/*
 * File:   function.cc
 * Author: Tore
 *
 * Created on 24 gennaio 2011, 10.07
 */

#include "classifier/functions/function.h"

#include <fstream>
#include <string>
#include "data/pattern.h"
#include "utils/general.h"
#include "utils/string_utils.h"


using namespace std;
using namespace Regularization;

/* static */
Function::TYPE Function::TypeFromStringOrDie(const std::string& str) {
    if (str == "LEARN")  return LEARN;
    if (str == "GIVEN" || str == "MAP_GIVEN")  return MAP_GIVEN;
    if (str == "MAP_LEARN")  return MAP_LEARN;

    FAULT("Undefined predicate type: " << str);
    return LEARN;  // we never get here.
}

/* static */
std::string Function::TypeToString(const Function::TYPE pt) {
    if (pt == LEARN)  return "LEARN";
    if (pt == MAP_GIVEN)  return "GIVEN";
    if (pt == MAP_LEARN)  return "MAP_LEARN";
    FAULT("Undefined predicate type");
    return "";  // we never get here.
}

Function::Function(const ID& id_, const TYPE type_, const Arity arity_, const std::string& domain_) :
    id(id_), type(type_), arity(arity_), domain(domain_) {
}

Function::Function(const Function& function) :
    id(function.id), type(function.type), arity(function.arity), domain(function.domain) {
}

void Function::Clear()
{
    id = Function::ID();
    type = LEARN;
    arity = 0;
    domain = "";
    this->InternalClear();
}

bool Function::LoadFromFile(const std::string& filename) {
    this->Clear();

    std::ifstream ifs(filename.c_str());
    if (!ifs.good()) {
        WARN("Could not open the file " << filename);
        return false;
    }
    return this->LoadFromStream(ifs);
}

bool Function::LoadFromStream(std::istream& is) {
    id = StringUtils::ReadElementOrDie<ID>(is);
    const string pt = StringUtils::ReadElementOrDie<string>(is);
    type = Function::TypeFromStringOrDie(pt);
    arity = StringUtils::ReadElementOrDie<Arity>(is);
    domain = StringUtils::ReadElementOrDie<std::string>(is);
    return this->InternalLoadFromStream(is);
}

bool Function::SaveToFile(const std::string& filename) const {
    std::ofstream ofs(filename.c_str());
    if (!ofs.good()) {
        WARN("Could not open the file " << filename);
        return false;
    }
    return this->SaveToStream(ofs);
}

bool Function::SaveToStream(std::ostream& is) const
{
    is << id << " " << Function::TypeToString(type) << " " << arity << " " << domain << " ";
    return this->InternalSaveToStream(is);
}

std::string Function::ToString() const
{
    std::ostringstream os;
    this->SaveToStream(os);
    return os.str();
}

void Function::Print() const
{
    this->SaveToStream(std::cout);
}
