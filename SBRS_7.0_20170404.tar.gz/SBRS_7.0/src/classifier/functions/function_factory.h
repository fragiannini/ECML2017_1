/*
 * function_factory.h
 *
 *  Created on: 11/mag/2011
 *      Author: claudio
 */
#ifndef FUNCTION_FACTORY_H
#define FUNCTION_FACTORY_H

#include <vector>
#include "classifier/functions/function.h"


namespace Regularization {

class Dataset;
class Examples;
class Kernel;
class GramMatrix;
class Predicate;
class TrainOptions;

class FunctionFactory {
public:
    typedef enum
    {
        KERNEL_MACHINE, NEURAL_NETWORK, MAP_FUNCTION, INVALID
    } FUNCTION_TYPE;

    static FUNCTION_TYPE FunctionTypeFromName(const std::string& name);
    static std::string NameFromFunctionType(const FUNCTION_TYPE type);
    // Uses RRTI to determine the function type name.
    static std::string NameFromFunction(const Function* function);
    // Uses RRTI to determine the function type.
    static FUNCTION_TYPE TypeFromFunction(const Function* function);

    // Options are used to manage singleton-like static data like large user-provided kernels.
    static Function* LoadFromFile(
            const std::string& filename,
            const FunctionFactory::FUNCTION_TYPE type,
            const TrainOptions& options);
    static Function* LoadFromStream(std::istream& is, const TrainOptions& options);
    static bool SaveToStream(const Function* function, std::ostream& os);
    static void Print(const Function* function);

    static Function* BuildFunction(
            const Predicate& predicate,
            const Examples* examples,
            const Dataset* dataset,  // may be NULL for given functions.
            const TrainOptions& options);

    static std::vector<Function*> BuildSharedFunctions(
            const std::vector<const Predicate*>& predicates,
            const Examples* examples,
            const Dataset* dataset,
            const TrainOptions& options);

    static Function* BuildMapFunction(
            const Predicate& predicate,
            const Dataset& dataset);

    static Function* BuildGivenFunction(
            const Predicate& predicate,
            const Examples* examples);
private:
    static Function* BuildKernelMachineFunction(
            const Predicate& predicate,
            const Kernel* kernel,
            const Dataset& dataset,
            const GramMatrix* gramMatrix,
            const TrainOptions& options);

    static Function* BuildNeuralNetworkFunction(
            const Predicate& predicate,
            const Dataset& dataset,
            const TrainOptions& options);
}; // end FunctionFactory
} // end namespace Regularization

#endif /* FUNCTION_FACTORY_H */
