/*
 * File:   FOL_formula_constraint.h
 * Author: claudio
 *
 * Created on May 20, 2011, 11:49 AM
 */

#ifndef FOL_FORMULA_CONSTRAINT_H
#define	FOL_FORMULA_CONSTRAINT_H

#include <map>
#include <vector>
#include <utility>
#include "data/basic_data_types.h"
#include "constraints/dataset_constraint.h"
#include "constraints/propositional_constraint/propositional_constraint.h"
#include "data/FOL_formula.h"
#include "utils/containers.h"
#include "utils/math/math_vector.h"


namespace Regularization
{
class BaseClassifier;
class LossFunction;

class FOLFormulaConstraint : public DatasetConstraint {
public:
    typedef std::map<Function::ID, Math::Vector<Value> > PerFunctionDerivative;

    /*
     * The multimap contains the predicates (literals) involved in the constraint.
     * The key of the map is the name of the predicate while the value is
     * the correspondent predicate. Note: A FOL formula can contain more than one
     * literal with same name.
     */
    typedef std::multimap<std::string, const FOLFormula::Literal*> PredicateToLiteralsMultiMap;

    // Constructor, gets the FOLformula and builds the constraint using the functions,
    // dataset and examples.
    FOLFormulaConstraint(
            const Predicates& predicates,
            const FOLFormula& FOLformula_,
            const Dataset& dataset_,
            const Examples& examples,
            const LossFunction& constraint_loss_function_,
            const BaseClassifier* classifier_);

    /*
     * Destructor
     */
    virtual ~FOLFormulaConstraint() { }

    // Check if the constraint involve the function id
    virtual bool InvolvesId(const Function::ID& id) const;

    // Compute the constraint value and its derivative is constraint_derivatives in not NULL.
    // For efficiency the derivative should be accumulated into constraint_derivatives
    // rescaling it accordingly to mult.
    virtual Value Eval(const Value mult, PerFunctionDerivative* constraint_derivatives);

    // Get the name of the constraint (print the FOL formula)
    virtual const std::string& GetName() const
    {
        return this->fol_formula.GetName();
    }

    // Get the priority for the constraint
    virtual unsigned int GetConstraintPriority() const
    {
        return this->fol_formula.GetPriority();
    }

private:
    // Build the constraint
    bool BuildPropositionalConstraint();
    bool BuildPropositionalConstraintInternal(
            const FOLFormula::PropositionalFormula& propositional_formula,
            PropositionalFormulaConstraint* constraint);

    // Decide if save candidates for given predicate optimization
    inline bool doOptimization() const {
        return givenLiteral.IsValid();
    }

    // Set the parameters for the constraint
    void Setup(const Predicates& predicates, const Examples& examples);

    // Reset Temp Structures for quantified L1 optimization
    void Reset(bool reset_derivatives);
    void UpdateIntermediatePropositionalValuesHelper(
            const Value value,
            const PerFunctionDerivative* derivative_values,  // null if not computed.
            const unsigned int level);
    void UpdateIntermediatePropositionalValues(
            const LogicCardinalityIndex cardinalityIndex, const Value value,
            const PerFunctionDerivative* derivative_values);  // null if not computed.
    void ForwardUpdateIntermediatePropositionalValues(
            const LogicCardinalityIndex cardinalityIndex,
            const LogicCardinalityIndex new_cardinalityIndex,
            const bool compute_derivatives);

    // Build the formula Pattern to give in input to the constraint runEval.
    void BuildFormulaPatterns(const LogicCardinalityIndex cardinalityIndex,
            PropositionalFormulaConstraint::VariablesToPatternMap* variables_to_pattern);

    // Compute the prebuilt formula patterns and store them in
    // this->prebuiltformulaPatterns. Only up to FLAGS_prebuild_constraint_patterns_size
    // patterns will be stored (trade off memory/speed).
    void ComputePreBuildFormulaPatterns();

    // Debug methods to get the variable indexes and pattern names at a given cardinality.
    std::vector<LogicCardinalityIndex> GetPatternsAtCardinality(
            const LogicCardinalityIndex cardinalityIndex);
    std::vector<std::string> GetPatternNamesAtCardinality(
            const LogicCardinalityIndex cardinalityIndex);

    // Map storing the prebuilt formula patterns by cardinality, it may be empty,
    // in that case the patterns will be built on the fly.
    typedef std::map<LogicCardinalityIndex, PropositionalFormulaConstraint::VariablesToPatternMap>
        Cardinality2FormulaPatternsMap;
    Cardinality2FormulaPatternsMap prebuiltformulaPatterns;

    // The FOL Formula
    const FOLFormula& fol_formula;

    // The constraint that represents the quantifier-free portion (CNF) of the formula
    PropositionalFormulaConstraint propositional_formula_constraint;

    // the constraint dataset cardinality
    LogicCardinalityIndex cardinality;

    // The vector is used to compute when a variable has completed a loop.
    // i.e. a variable has already taken all values in the domain.
    // This is the product of all variable cardinalities on the right side of the current variable.
    // variablesRightContextCardinality[0] = 1
    // ...
    // variablesRightContextCardinality[i] = \prod_{j=0}^{i-1} DomainCardinality_of_i-th_var
    // ...
    // variablesRightContextCardinality[quantifiedVariablesSize] = cardinality
    std::vector<LogicCardinalityIndex> variablesRightContextCardinality;

    // Vector with the cardinality of each variable
    std::vector<LogicCardinalityIndex> variablesCardinality;

    // This is compute to determine how many total elements will contribute to the output.
    LogicCardinalityIndex cardinality_contributions;
    // The actual number executed cardinality with given literal optimization.
    LogicCardinalityIndex cardinality_with_optimization;

    // optimization: given predicate optimization
    // The map of the indexes used for given predicate optimization.
    // The key of the map is the index of the current pattern while the value
    // is the next pattern index that must be evaluated.
    typedef std::map<LogicCardinalityIndex, LogicCardinalityIndex> CardinalitySkips;
    CardinalitySkips cardinality_skips;

    // if not NULL optimization is enabled. Please note that a simple check on
    // cardinality_skips.size() is not correct as there could be no valid
    // instantiation of a variable in a domain but stil do the optimization
    // (which would entirely skip a rule in that case).
    const FOLFormula::Literal givenLiteral;

    // Non const, these are copied and then reversed in order.
    FOLFormula::QuantifiedVariables quantified_variables;
    // Map variable to position, like x->0 y->1 ...
    std::map<std::string, int> variable_name_to_position;
    // As above but as a vector, it maybe faster to search here for a small number of variables.
    std::vector<std::pair<std::string, int> > variable_name_to_position_vec;

    const Index quantified_variable_size;
    const bool universally_quantified;

    // loss function for constraint
    const LossFunction& constraint_loss_function;

    // Struct that define a pair between the value of the constraint for a specific configuration
    // of the grounded variables and the correspondent derivative for each function.
    // Overloading of operator function permits to order the vector of this elements with a specific sorting.
    struct IntermediatePropositionalValues  {
        Value value;
        // Map functionID->derivativeVector.
        PerFunctionDerivative der;

        inline void Copy(const IntermediatePropositionalValues& val) {
            value = val.value;
            der = val.der;
        }
        inline IntermediatePropositionalValues() :
            value(0) {
        }
        inline IntermediatePropositionalValues(const Value value_) :
            value(value_) {
        }
        inline IntermediatePropositionalValues(const Value value_, const PerFunctionDerivative& der_) :
            value(value_), der(der_) {
        }
        inline friend void swap(IntermediatePropositionalValues& a, IntermediatePropositionalValues& b) {
            std::swap(a.value, b.value);
            std::swap(a.der, b.der);
        }
    };

    struct IntermediatePropositionalValuesComparator {
        inline bool operator()(const IntermediatePropositionalValues* a, const IntermediatePropositionalValues* b) {
            return a->value < b->value;
        }
    };
    // Derivative and value placeholder for all entries relative to one variable. One entry is
    // needed for exist and forall quantifiers, more than one element needed for existN quantifiers.
    class PerVariableIntermediatePropositionalValues {
    private:
        std::vector<IntermediatePropositionalValues> elements;  // size=N > 1 for existsN only
        typedef std::vector<IntermediatePropositionalValues*> IntermediatePropositionalValuesContainer;
        typedef std::PrereservedPriorityQueue<IntermediatePropositionalValues*,
                IntermediatePropositionalValuesComparator> IntermediatePropositionalValuesQueue;
        IntermediatePropositionalValuesQueue elements_queue;  // for existsN only
        PerFunctionDerivative sum_derivatives;  // computed if SumDerivatives() is called
        int valid_elements;
        int N;  // equal to the overall maximum number of elements.

        Value SumValues() const;
        const PerFunctionDerivative& SumDerivatives();
    public:
        PerVariableIntermediatePropositionalValues(
                const int N_, const IntermediatePropositionalValues& el);
        inline Value GetValue() const {
            // CHECK_GT(valid_elements, 0);
            if (N == 1)
                return elements[0].value;
            return SumValues();
        }
        inline const PerFunctionDerivative& GetDerivative() {
            // CHECK_GT(valid_elements, 0);
            if (N == 1) {
                return elements[0].der;
            }
            return SumDerivatives();
        }

        void Reset(const bool reset_derivatives);
        inline Value GetMaxValue() const {
            if (N == 1) {  // for speed
                // CHECK_GT(valid_elements, 0);
                return elements[0].value;
            }
            // CHECK_GT(!elements_queue.empty(), 0);
            return elements_queue.top()->value;
        }

        // Called only for N==1
        void Add(const Value value_, const PerFunctionDerivative* der_);
        static void CopyElementHelper(const Value value_, const PerFunctionDerivative* der_,
                                      IntermediatePropositionalValues* dest);
        // Called also for N==1 (exists)
        void Set(const Value value_, const PerFunctionDerivative* der_);
    };

    // One per level. intermediate_propositional_values_derivatives[i] is the intermediate
    // derivative up to the i-th quantifier.
    // intermediate_propositional_values_derivatives[i][j] is the j-th
    // element, for exists and forall only j=0 is needed, for exists_n 0<j<n
    std::vector<PerVariableIntermediatePropositionalValues> intermediate_propositional_values;

    // Derivative at the propositional level, before quantifier aggregation.
    PerFunctionDerivative lower_level_intermediate_propositional_derivative;

    const BaseClassifier* classifier;
}; // end FOLFormulaConstraint

} // end Regularization
#endif	/* FOL_FORMULA_CONSTRAINT_H */

