#ifndef __CONSTRAINTS_TNORM_H__
#define __CONSTRAINTS_TNORM_H__

#include <vector>

#include "data/basic_data_types.h"
#include "utils/general.h"
#include "data/FOL_formula.h"


namespace Regularization {
class LearnFunction;

// Generic TNorm implementation.
class TNorm {
public:
    TNorm() {}
    virtual ~TNorm() { }

    ///////////////////////////
    // Virtual interface
    virtual TNorm* Clone() const = 0;
    virtual Value AND(const std::vector<Value>& values) const = 0;
    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const = 0;
    ///////////////////////////

    virtual Value NOT(const Value value) const {
        // CHECK_IN_RANGE(value, static_cast<Value>(0), static_cast<Value>(1));
        return 1 - value; }
    virtual Value NOTDerivative(const Value value) const { return -1; }

    virtual Value OR(const std::vector<Value>& values) const {
        // Apply DeMorgan.
        std::vector<Value> nvalues(values.size());
        this->NegateValues(values, &nvalues);
        return this->NOT(this->AND(nvalues));
    }
    virtual Value ORDerivative(const std::vector<Value>& values,
                               const unsigned int index) const {
        std::vector<Value> nvalues(values.size());
        this->NegateValues(values, &nvalues);
               // for the external 1 -
        return NOTDerivative(0 /* any value works, assuming this is constant,
                                  expensive and correct is to pass
                                  AND(NegateValues(values), index) */ ) *
               // for the value by value 1 -
               NOTDerivative(0 /* any value works, assuming this is constant,
                                  expensive and correct is to pass
                                  AND(NegateValues(values), index) */ ) *
                             this->ANDDerivative(nvalues, index);
    }

    // Default is A=>B implemented as NOT A OR B
    virtual Value Residuum(const Value l, const Value r) const {
        std::vector<Value> values(2);
        values[0] = this->NOT(l);
        values[1] = r;
        return this->OR(values);
    }

    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        std::vector<Value> values(2);
        values[0] = this->NOT(l);
        values[1] = r;
        return (ld ? this->NOTDerivative(0) : 1) * this->ORDerivative(values, ld);
    }

protected:
    virtual void NegateValues(const std::vector<Value>& values,
                              std::vector<Value>* nvalues) const {
        nvalues->resize(values.size());
        for (unsigned int i = 0; i < values.size(); ++i) {
            (*nvalues)[i] = this->NOT(values[i]);
        }
    }
};  // end TNorm
/////////////////////////////////////////

/////////////////////////////////////////
class MinimumTNorm : public TNorm {
public:
    MinimumTNorm() {}
    virtual ~MinimumTNorm() { }
    virtual TNorm* Clone() const { return new MinimumTNorm; };

    virtual Value AND(const std::vector<Value>& values) const {
        Value min = values[0];
        for (unsigned int i = 1; i < values.size(); ++i) {
            if (values[i] < min) {
                min = values[i];
            }
        }
        return min;
    }

    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const {
        const Value min = values[index];
        for (unsigned int i = 0; i < values.size(); ++i) {
            if (i != index && values[i] < min) {
                return 0;
            }
        }
        return 1;
    }

    virtual Value OR(const std::vector<Value>& values) const {
        Value max = values[0];
        for (unsigned int i = 1; i < values.size(); ++i) {
            if (values[i] > max) {
                max = values[i];
            }
        }
        return max;
    }

    virtual Value ORDerivative(const std::vector<Value>& values,
                                const unsigned int index) const {
        const Value max = values[index];
        for (unsigned int i = 0; i < values.size(); ++i) {
            if (i != index && values[i] > max) {
                return 0;
            }
        }
        return 1;
    }

    virtual Value Residuum(const Value l, const Value r) const {
        if (l < r)  return 1;
        return r;
    }

    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        if (l < r)  return 0;
        return (ld ? 0 : 1);
    }
};  // end MinimumTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class ProductTNorm : public TNorm {
public:
    ProductTNorm() {}
    virtual ~ProductTNorm() { }
    virtual TNorm* Clone() const { return new ProductTNorm; };

    virtual Value AND(const std::vector<Value>& values) const {
        Value prod = 1;
        for (unsigned int i = 0; i < values.size(); ++i) {
            // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
            prod *= values[i];
        }
        return prod;
    }

    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const {
        // Could be written as AND(values) / values[index] but it would require one division.
        Value prod = 1;
        for (unsigned int i = 0; i < values.size(); ++i) {
            if (i != index) {
                // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
                prod *= values[i];
            }
        }
        return prod;
    }

    // Could be done by the default, but this is faster as it avoid allocating
    // the value vector.
    virtual Value OR(const std::vector<Value>& values) const {
        Value prod = 1;
        for (unsigned int i = 0; i < values.size(); ++i) {
            // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
            prod *= 1 - values[i];
        }
        return 1 - prod;
    }

    // Could be done by the default, but this is faster as it avoid allocating
    // the value vector.
    virtual Value ORDerivative(const std::vector<Value>& values,
                               const unsigned int index) const {
        Value prod = 1;
        for (unsigned int i = 0; i < values.size(); ++i) {
            if (i != index) {
                // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
                prod *= 1 - values[i];
            }
        }
        return prod;
    }

    virtual Value Residuum(const Value l, const Value r) const {
        if (l < r)  return 1;
        const Value l_limited = (l > 0.00001 ? l : 0.00001);
        return r / l_limited;
    }

    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        if (l < r)  return 0;
        const Value l_limited = (l > 0.00001 ? l : 0.00001);
        if (ld)  return -0.5 * r / (l_limited * l_limited);
        return 1 / l_limited;
    }
};  // end ProductTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class LukasiewiczTNorm : public TNorm {
public:
    LukasiewiczTNorm() {}
    virtual ~LukasiewiczTNorm() { }
    virtual TNorm* Clone() const { return new LukasiewiczTNorm; };

    virtual Value AND(const std::vector<Value>& values) const {
        Value sum = static_cast<Value>(1) - values.size();
        for (unsigned int i = 0; i < values.size(); ++i) {
            // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
            sum += values[i];
        }
        return (sum > 0 ? sum : 0);
    }

    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int /* index */) const {
        return (this->AND(values) > 0 ? 1 : 0);
    }

    virtual Value OR(const std::vector<Value>& values) const {
        // Faster implementation than using demorgan.
        Value sum = 0;
        for (unsigned int i = 0; i < values.size(); ++i) {
            // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
            sum += values[i];
        }
        return (sum > 1 ? 1 : sum);
    }

    virtual Value ORDerivative(const std::vector<Value>& values,
                               const unsigned int /* index */) const {
        Value sum = 0;
        for (unsigned int i = 0; i < values.size(); ++i) {
            sum += values[i];
        }
        return (sum > 1 ? 0 : 1);
        // More elegant but it requires one extra virtual call.
        // return (this->OR(values) < 1 ? 1 : 0);
    }

    virtual Value Residuum(const Value l, const Value r) const {
        return (l < r ? 1 : 1 - l + r);
    }

    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        if (l < r)  return 0;
        return (ld ? -1 : 1);
    }
};  // end LukasiewiczTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class WeakLukasiewiczTNorm : public LukasiewiczTNorm {
public:
    WeakLukasiewiczTNorm() {}
    virtual ~WeakLukasiewiczTNorm() { }
    virtual TNorm* Clone() const { return new WeakLukasiewiczTNorm; };

    virtual Value AND(const std::vector<Value>& values) const {
        Value min = values[0];
        for (unsigned int i = 1; i < values.size(); ++i) {
            if (values[i] < min)
                min = values[i];
        }
        return min;
    }

    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const {
        const Value min = values[index];
        for (unsigned int i = 0; i < values.size(); ++i) {
            if (i != index && values[i] < min)  return 0;
        }
        return 1;
    }
};  // end WeakLukasiewiczTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class TNormFactory {
public:
    inline static TNorm* Build(
        const FOLFormula::PROPOSITIONAL_CONVERSION_NORM norm) {
        switch(norm) {
        case FOLFormula::PRODUCT_TNORM:
            return new ProductTNorm;
        case FOLFormula::MINIMUM_TNORM:
            return new MinimumTNorm;
        case FOLFormula::LUKASIEWICZ_TNORM:
            return new LukasiewiczTNorm;
        case FOLFormula::WEAK_LUKASIEWICZ_TNORM:
            return new WeakLukasiewiczTNorm;
        default:
            FAULT("Invalid Tnorm requested.");
            return NULL;
        }
    }
};  // end TNormFactory
/////////////////////////////////////////

}  // end Regularization

#endif  // __CONSTRAINTS_TNORM_H__
