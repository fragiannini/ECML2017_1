#include "constraints/propositional_constraint/propositional_constraint.h"

#include <sstream>

#include "classifier/functions/learn_function/learn_function.h"
#include "utils/string_utils.h"


namespace Regularization {


PropositionalFormulaConstraint::PropositionalFormulaConstraint() :
                logic_connective(INVALID), tnorm(NULL),
                function(NULL), size(0) { }

PropositionalFormulaConstraint& PropositionalFormulaConstraint::operator=(
        const PropositionalFormulaConstraint& formula) {
    if (this == &formula)  return *this;  // no auto-assignment.

    logic_connective = formula.logic_connective;
    tnorm = (formula.tnorm != NULL ? formula.tnorm->Clone() : NULL);
    function = formula.function;
    variables = formula.variables;
    size = formula.size;
    function_ids = formula.function_ids;
    function_ids_vec = formula.function_ids_vec;
    variable_set = formula.variable_set;

    subformulas.clear();
    subformulas.reserve(formula.subformulas.size());
    for (unsigned int i = 0; i < formula.subformulas.size(); ++i)
        subformulas.push_back(formula.subformulas[i]);

    return *this;
}

PropositionalFormulaConstraint::PropositionalFormulaConstraint(
        const PropositionalFormulaConstraint& formula) :
                logic_connective(formula.logic_connective),
                subformulas(formula.subformulas),
                tnorm(formula.tnorm != NULL ? formula.tnorm->Clone() : NULL),
                function(formula.function),
                variables(formula.variables),
                size(formula.size),
                function_ids(formula.function_ids),
                function_ids_vec(formula.function_ids_vec),
                variable_set(formula.variable_set) {
}

// Initializes the simplest formula which is composed by a single literal or atom.
PropositionalFormulaConstraint::PropositionalFormulaConstraint(
        const Function* function_,
        const std::vector<std::string>& variables_,
        const std::string& logic_connective_str,
        const TNorm* tnorm_) :
                logic_connective(PropositionalFormulaConstraint::FromString(logic_connective_str)),
                tnorm(tnorm_ != NULL ? tnorm_->Clone() : NULL),
                function(function_), variables(variables_),
                size(1) {
    CHECK_NE_NULL(function);
    CHECK_EQ(static_cast<Index>(variables.size()), function->GetArity());
    CHECK(logic_connective == NOT || logic_connective == NONE);

    function_ids.insert(function->GetId());
    function_ids_vec.push_back(function->GetId());

    variable_set.insert(variables);
}

// Initializes the recursive step where a formula is the composition of any other formula.
PropositionalFormulaConstraint::PropositionalFormulaConstraint(
        const std::vector<PropositionalFormulaConstraint>& formulas_,
        const std::string& logic_connective_str,
        const TNorm* tnorm_) :
                logic_connective(PropositionalFormulaConstraint::FromString(logic_connective_str)),
                subformulas(formulas_),
                tnorm(tnorm_ != NULL ? tnorm_->Clone() : NULL),
                function(NULL) {
    switch (logic_connective) {
    case NOT:
    case NONE:
        CHECK_EQ(static_cast<int>(subformulas.size()), 1);
        size += subformulas[0].size;
        break;

    case RESIDUUM:
        CHECK_EQ(static_cast<int>(subformulas.size()), 2);
        size += subformulas[0].size + subformulas[1].size;
        break;

    case AND:
    case OR:
        CHECK_GE(static_cast<int>(subformulas.size()), 2);
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            size += subformulas[i].size;
        }
        break;

    default:
        FAULT("Invalid Logic Connective " << ToString(logic_connective) <<
              " for propositional constraint " << this->ToString());
    }

    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        std::set<Function::ID>::const_iterator iter = subformulas[i].function_ids.begin();
        for (; iter != subformulas[i].function_ids.end(); ++iter) {
            function_ids.insert(*iter);
        }
        FormulaVariableSet::const_iterator iter1 = subformulas[i].variable_set.begin();
        for (; iter1 != subformulas[i].variable_set.end(); ++iter1) {
            variable_set.insert(*iter1);
        }
    }
    // Copy the set into the vector
    function_ids_vec.reserve(function_ids.size());
    for (std::set<Function::ID>::const_iterator iter = function_ids.begin();
        iter != function_ids.end(); ++iter) {
        function_ids_vec.push_back(*iter);
    }
}


PropositionalFormulaConstraint::~PropositionalFormulaConstraint() {
    if (tnorm != NULL) {
        delete tnorm;
    }
}

Value PropositionalFormulaConstraint::Eval(const VariablesToPatternMap& patterns) const {
    if (function != NULL) {
        VariablesToPatternMap::const_iterator iter = patterns.find(variables);
        CHECK_WITH_MESSAGE(iter != patterns.end(),
                "Could not resolve variables " + StringUtils::ContainerToString(variables, " ") +
                " in the provided map");
        const Pattern* pattern = iter->second;
        const Value value = function->Eval(*pattern);
        /* MESSAGE("ATOM " << function->GetId() << "(" << pattern->GetName() << ")" <<
                (logic_connective == NOT ? " NOT " : " ") << value << "=" <<
                (logic_connective == NOT ? tnorm->NOT(value) : value)); */
        return (logic_connective == NOT ? tnorm->NOT(value) : value);
    }

    if (logic_connective == NOT) {
        // MESSAGE("NOT " << tnorm->NOT(subformulas[0].Eval(patterns)));
        return tnorm->NOT(subformulas[0].Eval(patterns));
    }
    if (logic_connective == RESIDUUM) {
        // MESSAGE("RES " << tnorm->Residuum(subformulas[0].Eval(patterns), subformulas[1].Eval(patterns)));
        return tnorm->Residuum(subformulas[0].Eval(patterns),
                               subformulas[1].Eval(patterns));
    }

    std::vector<Value> values(subformulas.size());
    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        values[i] = subformulas[i].Eval(patterns);
    }
    if (logic_connective == AND) {
        // MESSAGE("AND " << tnorm->AND(values));
        return tnorm->AND(values);
    }
    if (logic_connective == OR) {
        // MESSAGE("OR " << tnorm->OR(values));
        return tnorm->OR(values);
    }
    FAULT("Invalid connective, we should never reach this point.");
    return 0;
}

bool PropositionalFormulaConstraint::AccumulateGradient(
        const VariablesToPatternMap& patterns,
        const LearnFunction& derivationFunction,
        const Value weight,
        Math::Vector<Value>* derivative) const {
    if (weight == 0 ||  // can happen when recursively calling this over subformulas.
        !this->InvolvesId(derivationFunction.GetId())) {
        return false;
    }

    if (function != NULL) {  // This should mean that function==derivationFunction
        CHECK_EQ(function->GetId(), derivationFunction.GetId());

        VariablesToPatternMap::const_iterator iter = patterns.find(variables);
        CHECK_WITH_MESSAGE(iter != patterns.end(),
                "Could not resolve variables " + StringUtils::ContainerToString(variables, " ") +
                " in the provided grounding map.");
        const Pattern* pattern = iter->second;

        const Value der_weight =
                (logic_connective == NOT ? tnorm->NOTDerivative(0) : 1) * weight;
        // MESSAGE(pattern->GetName() << " WEIGHT " << der_weight << " EVAL " << function->Eval(*pattern));
        const bool ret = derivationFunction.AccumulateGradient(*pattern, der_weight, derivative);
        // MESSAGE(dynamic_cast<const LearnFunction*>(function)->Get().ToStringAsSparse());
        return ret;
    }

    if (logic_connective == NOT) {
        return subformulas[0].AccumulateGradient(
                patterns, derivationFunction, tnorm->NOTDerivative(0) * weight,
                derivative);
    } else if (logic_connective == RESIDUUM) {
        const Value precondition = subformulas[0].Eval(patterns);
        const Value postcondition = subformulas[1].Eval(patterns);
        bool ret = false;
        ret |= subformulas[0].AccumulateGradient(
                patterns, derivationFunction,
                tnorm->ResiduumDerivative(precondition, postcondition, true) * weight,
                derivative);
        ret |= subformulas[1].AccumulateGradient(
                patterns, derivationFunction,
                tnorm->ResiduumDerivative(precondition, postcondition, false) * weight,
                derivative);
        return ret;
    } else if (logic_connective == AND || logic_connective == OR) {
        std::vector<Value> values(subformulas.size());
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            values[i] = subformulas[i].Eval(patterns);
        }

        // MESSAGE("VALUES " << StringUtils::VectorToString(values, ","));

        bool ret = false;
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            // MESSAGE("SUBFORMULA " << subformulas[i].ToString());

            const Value der_weight =
                    (logic_connective == AND ?
                     tnorm->ANDDerivative(values, i) : tnorm->ORDerivative(values, i));
            ret |= subformulas[i].AccumulateGradient(
                    patterns, derivationFunction, der_weight * weight,
                    derivative);
        }
        return ret;
    }

    FAULT("Unexpected logic connective! We should not be here");
    return false;
}

std::string PropositionalFormulaConstraint::ToString() const {
    std::ostringstream s;
    s << "[";
    const std::string logic_connective_str =
            (logic_connective == NONE ? "" : ToString(logic_connective) + " ");
    if (function != NULL) {
        if (logic_connective == NOT) {
            s << logic_connective_str << " ";
        }
        s << function->GetId() << "("
          << StringUtils::VectorToString(variables, ",", "") << ")";
    } else if (logic_connective == NOT) {
        CHECK_EQ(static_cast<int>(subformulas.size()), 1);
        s << logic_connective_str << subformulas[0].ToString();
    } else {
        CHECK_GE(static_cast<int>(subformulas.size()), 2);
        s << subformulas[0].ToString();
        for (unsigned int i = 1; i < subformulas.size(); ++i) {
            s << logic_connective_str << subformulas[i].ToString();
        }
    }
    s << "]";
    return s.str();
}

std::string PropositionalFormulaConstraint::GroundedToString(
        const VariablesToPatternMap& patterns) const {
    std::ostringstream s;
    s << "[";
    if (function != NULL) {
        VariablesToPatternMap::const_iterator iter = patterns.find(variables);
        CHECK_WITH_MESSAGE(iter != patterns.end(),
                "Could not resolve variables " + StringUtils::ContainerToString(variables, " ") +
                " in the provided map");
        const Pattern* pattern = iter->second;
        if (logic_connective == NOT) {
            s << ToString(logic_connective) << " ";
        }
        s << function->GetId() << "(" << pattern->GetName() << ")";
    } else if (logic_connective == NOT) {
        s << ToString(logic_connective) << subformulas[0].GroundedToString(patterns);
    } else {
        s << subformulas[0].GroundedToString(patterns);
        for (unsigned int i = 1; i < subformulas.size(); ++i) {
            s << ToString(logic_connective) << " " << subformulas[i].GroundedToString(patterns);
        }
    }
    s << "]";
    return s.str();
}
}  // end Regularization
