#ifndef TNORM_CONSTRAINT_H
#define TNORM_CONSTRAINT_H

#include <string>
#include <map>
#include <set>
#include <vector>

#include "constraints/propositional_constraint/tnorm.h"
#include "data/basic_data_types.h"
#include "data/pattern.h"
#include "classifier/functions/function.h"
#include "utils/general.h"
#include "utils/math/math_vector.h"


namespace Regularization {

class PropositionalFormulaConstraint {
public:
    // The variables->pattern association for one evaluation of the constraint. This sets the groundings.
    typedef std::map<std::vector<std::string>, const Pattern*> VariablesToPatternMap;
    // The set of all variable combinations for the atoms in this formula.
    // All the elements in this set should be grounded.
    typedef std::set<std::vector<std::string> > FormulaVariableSet;

    PropositionalFormulaConstraint();
    PropositionalFormulaConstraint(const PropositionalFormulaConstraint& formula);

    // Initializes the simplest formula which is composed by a single literal or atom.
    PropositionalFormulaConstraint(
            const Function* function_,
            const std::vector<std::string>& variables_,
            const std::string& logic_connective_str,
            const TNorm* tnorm_);  /* tnorm will be owned by the class */
    PropositionalFormulaConstraint& operator=(
            const PropositionalFormulaConstraint& formula);

    // Initializes the recursive step where a formula is the composition of any other formula,
    // using the tnorm_ to combine them.
    PropositionalFormulaConstraint(
            const std::vector<PropositionalFormulaConstraint>& formulas_,
            const std::string& logic_connective_str,
            const TNorm* tnorm_);  /* tnorm will be owned by the class */

    ~PropositionalFormulaConstraint();

    Value Eval(const VariablesToPatternMap& patterns) const;

    bool AccumulateGradient(
            const VariablesToPatternMap& patterns,
            const LearnFunction& derivationFunction,
            const Value weight,
            Math::Vector<Value>* derivative) const;

    // Attention: non-virtual for speed.
    inline int Size() const { return size; }
    std::string ToString() const;
    std::string GroundedToString(const VariablesToPatternMap& patterns) const;

    inline const FormulaVariableSet& GetVariableSet() const {
        return variable_set;
    }
    inline const std::vector<Function::ID>& GetIds() const {
        return function_ids_vec;
    }

 protected:
    inline bool InvolvesId(const Function::ID& id) const {
        return function_ids.find(id) != function_ids.end();
    }

    // Logic connective.
    enum LOGICCONNECTIVE {
        AND, OR, RESIDUUM, NOT /* negation */, NONE /* used for non negated atoms */ , INVALID
    };
    static inline LOGICCONNECTIVE FromString(const std::string& str) {
        // And
        if (str == "AND")       return AND;
        if (str == "^")         return AND;
        // Or
        if (str == "OR")        return OR;
        if (str == "v")         return OR;
        // Implication
        if (str == "RESIDUUM")  return RESIDUUM;
        if (str == "=>")        return RESIDUUM;
        // Negation
        if (str == "NOT")       return NOT;
        if (str == "~")         return NOT;
        // No-op
        if (str.empty())        return NONE;

        WARN("Unknown logic connective string " << str);
        return INVALID;
    }

    static inline std::string ToString(const LOGICCONNECTIVE lc) {
        if (lc == AND)       return "AND";
        if (lc == OR)        return "OR";
        if (lc == RESIDUUM)  return "=>";
        if (lc == NOT)       return "NOT";
        if (lc == NONE)      return "";
        return "INVALID";
    }

    LOGICCONNECTIVE logic_connective;

    // The subformulas composing this formula, they are joined by the logic_connective.
    std::vector<PropositionalFormulaConstraint> subformulas;

    const TNorm* tnorm;

    // If formulas is empty, the formula can be a single atom with relative input variables.
    // If subformulas is not empty this is NULL and variables empty.
    const Function* function;
    std::vector<std::string> variables;

    Index size;  // total number of literals or atoms in the formula, recursively computed.
    // All function ids, recursively merged from the subformulas.
    std::set<Function::ID> function_ids;
    std::vector<Function::ID> function_ids_vec;

    // All predicate variables, recursively merged from the subformulas.
    // If the formula is A(x) ^ B(x,y) ^ C(x) ^ D(y,x) the set will be
    // (x),(x,y),(y,x), this will be used to correctly compile the
    // VariablesToPatternMap for this formula.riable
    FormulaVariableSet variable_set;
};

}  // end Regularization

#endif  // TNORM_CONSTRAINT_H
