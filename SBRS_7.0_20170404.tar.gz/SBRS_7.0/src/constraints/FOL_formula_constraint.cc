/*
 * FOL_formula_constraint.cc
 *
 *  Created on: 22/mar/2011
 *      Author: claudio
 */

#include "constraints/FOL_formula_constraint.h"

#include <algorithm>
#include <limits>
#include <string>
#include <utility>

#include "classifier/classifier.h"
#include "classifier/functions/function.h"
#include "constraints/propositional_constraint/propositional_constraint.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "data/FOL_formula.h"
#include "data/predicate.h"
#include "data/predicates.h"
#include "train/loss/loss_function.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/stl_utils.h"


DEFINE_bool(normalize_constraints_by_cardinality, false,
        "Normalize each constraint by its cardinality.");

DEFINE_int32(prebuild_constraint_patterns_size, 2000,
        "How many patterns can be prebuilt, this trades memory for speed.");

using namespace std;
using namespace Regularization;

FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::PerVariableIntermediatePropositionalValues(
        const int N_, const FOLFormulaConstraint::IntermediatePropositionalValues& el) :
        elements_queue(N_), valid_elements(0), N(N_) {
    CHECK_GT(N, 0);
    elements.reserve(N);
    for (int i = 0; i < N; ++i) {
        elements.push_back(el);
    }
}

Value FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::SumValues() const {
    Value sum = 0;
    for (int i = 0; i < valid_elements; ++i) {
        sum += elements[i].value;
    }
    return sum;
}

const FOLFormulaConstraint::PerFunctionDerivative&
FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::SumDerivatives() {
    for (PerFunctionDerivative::iterator iter = sum_derivatives.begin();
         iter != sum_derivatives.end(); ++iter) {
        iter->second.SetAll(0);
    }

    for (int i = 0; i < valid_elements; ++i) {
        for (PerFunctionDerivative::const_iterator iter1 = elements[i].der.begin();
                iter1 != elements[i].der.end(); ++iter1) {
            if (sum_derivatives.find(iter1->first) == sum_derivatives.end())
                sum_derivatives[iter1->first].Copy(iter1->second);
            else
                sum_derivatives[iter1->first].AddInPlace(iter1->second);
        }
    }
    return sum_derivatives;
}

// Called for forall, just aggregate the stats.
void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::Add(
        const Value value_, const PerFunctionDerivative* der_) {
    CHECK_EQ(N, 1);  // for max speed we only support N=1 (all that we need for this operation).
    elements[0].value += value_;
    if (der_ != NULL) {
        for (PerFunctionDerivative::const_iterator iter = der_->begin(); iter != der_->end(); ++iter) {
            elements[0].der[iter->first].AddInPlace(iter->second);
        }
    }
    valid_elements = 1;
}

/* static */
void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::CopyElementHelper(
        const Value value_, const PerFunctionDerivative* der_,
        FOLFormulaConstraint::IntermediatePropositionalValues* dest) {
    dest->value = value_;
    if (der_ != NULL) {
        for (PerFunctionDerivative::const_iterator iter = dest->der.begin();
                iter != dest->der.end(); ++iter) {
            PerFunctionDerivative::const_iterator iter1 = der_->find(iter->first);
            if (iter1 != der_->end())
                dest->der[iter->first].Copy(iter1->second);
            else
                dest->der[iter->first].SetAll(0);
        }
    }
}

// Called also for N==1 (exists)
void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::Set(
        const Value value_, const PerFunctionDerivative* der_) {
    if (N == 1) {  // special case for speed.
        // value is after-loss, so smaller is better.
        if (valid_elements == 0 || value_ < elements[0].value) {
            CopyElementHelper(value_, der_, &elements[0]);
            valid_elements = 1;
        }
    } else {
        if (valid_elements < N) {
            CopyElementHelper(value_, der_, &elements[valid_elements]);
            elements_queue.push(&elements[valid_elements]);
            ++valid_elements;
        } else if (value_ < elements_queue.top()->value) {
            IntermediatePropositionalValues* el = elements_queue.top();
            elements_queue.pop();
            CopyElementHelper(value_, der_, el);
            elements_queue.push(el);
        }
    }
}

void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::Reset(
        const bool reset_derivatives) {
    for (int i = 0; i < valid_elements; ++i) {
        elements[i].value = 0;
        if (reset_derivatives) {
            for (PerFunctionDerivative::iterator iter = elements[i].der.begin();
                 iter != elements[i].der.end(); ++iter) {
                iter->second.SetAll(0);
            }
        }
    }

    // No clear() available, so we just build a new fresh container.
    elements_queue = IntermediatePropositionalValuesQueue(this->N);
    valid_elements = 0;
}

// Constructor
FOLFormulaConstraint::FOLFormulaConstraint(
        const Predicates& predicates, const FOLFormula& FOLformula_,
        const Dataset& dataset_, const Examples& examples,
        const LossFunction& constraint_loss_function_,
        const BaseClassifier* classifier_) : DatasetConstraint(dataset_),
        fol_formula(FOLformula_),
        cardinality(0),
        cardinality_contributions(0),
        cardinality_with_optimization(0),
        givenLiteral(fol_formula.GetGivenLiteral()),
        quantified_variables(fol_formula.GetQuantifiedVariables()),
        quantified_variable_size(fol_formula.GetQuantifiedVariables().size()),
        universally_quantified(fol_formula.IsUniversallyQuantified()),
        constraint_loss_function(constraint_loss_function_),
        classifier(classifier_) {
    this->Setup(predicates, examples);
}

bool FOLFormulaConstraint::BuildPropositionalConstraintInternal(
        const FOLFormula::PropositionalFormula& propositional_formula,
        PropositionalFormulaConstraint* constraint) {
    const FOLFormula::Literal& literal = propositional_formula.GetLiteral();
    const std::string& logic_connective = propositional_formula.GetLogicConnective();
    const std::vector<FOLFormula::PropositionalFormula>& subformulas =
            propositional_formula.GetSubFormulas();

    // tnorm will be owned by the constraint.
    const TNorm* tnorm = TNormFactory::Build(fol_formula.GetPropositionalNormType());
    CHECK_NE_NULL(tnorm);

    if (literal.IsValid()) {
        CHECK(subformulas.empty());  // atom it should have no subformulas
        CHECK(logic_connective == "NOT" ||
              logic_connective.empty());  // single atom can be negated but no other op

        *constraint = PropositionalFormulaConstraint(
                &(classifier->GetFunctionByIDOrDie(literal.GetId())),
                literal.GetPredicateVariables(),
                logic_connective, tnorm);
    } else {
        CHECK_WITH_MESSAGE(!logic_connective.empty(),
                           "Can not read formula " + propositional_formula.ToString());
        if (logic_connective == "NOT") {
            CHECK_EQ(static_cast<int>(subformulas.size()), 1);
        } else if (logic_connective == "=>") {
            CHECK_EQ(static_cast<int>(subformulas.size()), 2);
        } else {
            CHECK_GE(static_cast<int>(subformulas.size()), 2);
        }

        std::vector<PropositionalFormulaConstraint> subconstraints(subformulas.size());
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            BuildPropositionalConstraintInternal(subformulas[i], &subconstraints[i]);
        }
        *constraint = PropositionalFormulaConstraint(
                subconstraints, logic_connective, tnorm);
    }
    return true;
}

/*
 * Build the constraint depending on type of norm
 */
bool FOLFormulaConstraint::BuildPropositionalConstraint() {
    return BuildPropositionalConstraintInternal(
            this->fol_formula.GetPropositionalFormula(), &propositional_formula_constraint);
}

/*
 * Check if the constraint involve the function id
 */
bool FOLFormulaConstraint::InvolvesId(const Function::ID& id) const
{
    return fol_formula.InvolvesLiteral(id);
}

// Compute the prebuilt formula patterns and store them in
// this->prebuiltformulaPatterns. Only up to FLAGS_prebuild_constraint_patterns_size
// patterns will be stored (trade off memory/speed).
void FOLFormulaConstraint::ComputePreBuildFormulaPatterns() {
    int added = 0;
    LogicCardinalityIndex i = 0;
    if (this->doOptimization()) {
        i = cardinality_skips[0];  // which is always set.
    }
    for (; i < cardinality && added < FLAGS_prebuild_constraint_patterns_size; ++i) {
        PropositionalFormulaConstraint::VariablesToPatternMap variables_to_pattern;
        this->BuildFormulaPatterns(i, &variables_to_pattern);
        prebuiltformulaPatterns[i] = variables_to_pattern;
        ++added;
        if (this->doOptimization()) {
            CardinalitySkips::const_iterator iter = cardinality_skips.find(i);
            if (iter != cardinality_skips.end()) {
                i = iter->second - 1;  // -1 because ++i at the end of the loop.
            }
        }
    }
}

/*
 * Set the parameters for the constraint
 */
void FOLFormulaConstraint::Setup(const Predicates& predicates, const Examples& examples) {
    CHECK(this->BuildPropositionalConstraint());
    // Reverse the order of the vector of the variables. Inner most variables first, also all the
    // consequently build vectors like variablesRightContextCardinality will follow this reversed order.
    reverse(quantified_variables.begin(), quantified_variables.end());
    variablesRightContextCardinality.reserve(quantified_variable_size + 1);  // last entry == cardinality
    cardinality = 1;
    cardinality_contributions = 1;
    variablesRightContextCardinality.push_back(1);  // last variable changes at each iteration
    int pos = 0;
    for (FOLFormula::QuantifiedVariables::const_iterator it = quantified_variables.begin();
         it != quantified_variables.end(); ++it, ++pos) {
        // Store a map and vector to retrieve the variable index given its name
        variable_name_to_position[it->name] = pos;
        variable_name_to_position_vec.push_back(std::make_pair(it->name, pos));

        const FOLFormula::QUANTIFIER quantifier = it->quantifier;

        // compute the cardinality of the domain of the variable check if the
        // value of the cardinality is equal to the max representable number
        const LogicCardinalityIndex domainCardinality =
                dataset.GetSizeForDomain(fol_formula.GetVariableDomain(it->name));

        CHECK_GT_WITH_MESSAGE(
                (numeric_limits<LogicCardinalityIndex>::max() / cardinality), domainCardinality,
                "FOL formula cardinality overtakes the maximum representable value! "
                "Formula: " + fol_formula.ToString());
        cardinality *= domainCardinality;
        variablesCardinality.push_back(domainCardinality);
        variablesRightContextCardinality.push_back(cardinality);
        if (quantifier == FOLFormula::exists_N) {
            if (it->quantifier_num > 1.0) {
                cardinality_contributions *= it->quantifier_num;
            } else {  // a double value indicates the portion of domain for which the exists should hold.
                cardinality_contributions *= it->quantifier_num * domainCardinality;
            }
        } else if (quantifier == FOLFormula::forall) {
            cardinality_contributions *= domainCardinality;
        } /* else if (quantifier == FOLFormula::exists) {  // nothing to do
            cardinality_contributions *= 1;
        } */

        if ((fol_formula.GetQuantifierNormType() == FOLFormula::LINF && !fol_formula.IsUniversallyQuantified()) ||
             fol_formula.GetQuantifierNormType() == FOLFormula::L1 ||
             fol_formula.GetQuantifierNormType() == FOLFormula::L2) {
            // check the consistency of the cardinality of the exists_N quantifier
            if (quantifier == FOLFormula::exists_N &&
                ((it->quantifier_num > 1.0 && it->quantifier_num > domainCardinality) ||
                 it->quantifier_num <= 0.0f)) {
                FAULT("Error: check the value of N " << it->quantifier_num <<
                      " for exists_N quantifier it is above the limit of domain cardinality " << domainCardinality);
            }
        }
    }

    // default, maybe changed after if optimization is enabled.
    cardinality_with_optimization = cardinality;

    if (givenLiteral.IsValid()) {
        // get information of given predicate
        const string& id = givenLiteral.GetId();
        // get the examples for the predicate
        const Examples::PerFunctionExamples* given_function_examples = examples.GetExamplesForPredicate(id);
        // Map index->num_entries_should_be_considered.
        map<LogicCardinalityIndex, LogicCardinalityIndex> index2interval;

        if (given_function_examples != NULL) {
            cardinality_with_optimization = 0;
            for (Examples::PerFunctionExamples::const_iterator it = given_function_examples->begin();
                 it != given_function_examples->end(); ++it) {
                const Examples::Example* example = (*it);
                const Value target = example->value;

                if (target <= static_cast<Value>(0)) {
                    continue;
                }

                vector<string> example_patterns;
                StringUtils::SplitToVector(example->pattern, &example_patterns, "_", false);
                CHECK_LE(static_cast<Index>(example_patterns.size()), quantified_variable_size);

                LogicCardinalityIndex index = 0;
                // Strong Assumption! Given predicate should (left-right fashion) depend only on the left most
                // (outer) quantified variables!
                for (unsigned int i = 0; i < example_patterns.size(); ++i) {
                    // Removed for speed.
                    index += dataset.GetPatternIndexInDomain(example_patterns[i]) *
                            variablesRightContextCardinality[quantified_variable_size - 1 - i];
                }
                const LogicCardinalityIndex interval =
                        variablesRightContextCardinality[quantified_variable_size - example_patterns.size()];
                index2interval[index] = interval;
                cardinality_with_optimization += interval;
            }
        }

        // If no examples for the predicate, one single giant skip is provided:
        // cardinality_skips[0] = cardinality;
        // First skip 0->0 if first element should not be skipped.
        map<LogicCardinalityIndex, LogicCardinalityIndex>::const_iterator iter = index2interval.begin();
        LogicCardinalityIndex end_interval = 0;
        for (; iter != index2interval.end(); ++iter) {
            cardinality_skips[end_interval] = iter->first;
            end_interval = iter->first + iter->second - 1;
        }
        cardinality_skips[end_interval] = cardinality;
    }

    // Prebuild the formula patterns if requested.
    if (FLAGS_prebuild_constraint_patterns_size > 0) {
        ComputePreBuildFormulaPatterns();
    }

    if (classifier == NULL)
        return;

    PerFunctionDerivative derivativeMap;
    const vector<Function::ID>& function_ids = propositional_formula_constraint.GetIds();
    for (unsigned int f = 0; f < function_ids.size(); ++f) {
        const Function::ID& id = function_ids[f];
        const Function& function = classifier->GetFunctionByIDOrDie(id);
        derivativeMap[id].Init(function.Size());
    }
    lower_level_intermediate_propositional_derivative = derivativeMap;

    intermediate_propositional_values.reserve(quantified_variable_size);
    for (Index h = 0; h < quantified_variable_size; ++h) {
        const LogicCardinalityIndex domainCardinality =
                dataset.GetSizeForDomain(fol_formula.GetVariableDomain(quantified_variables[h].name));
        const int size = (quantified_variables[h].quantifier == FOLFormula::exists_N ?
                           (quantified_variables[h].quantifier_num > 1.0f ?
                            static_cast<int>(quantified_variables[h].quantifier_num) :
                            quantified_variables[h].quantifier_num * domainCardinality)
                          : 1);
        CHECK_GT_WITH_MESSAGE(size, 0, "Wrong exists_N, it should hold that N>0")
        intermediate_propositional_values.push_back(PerVariableIntermediatePropositionalValues(
                size, IntermediatePropositionalValues(0, derivativeMap)));
    }
}

void FOLFormulaConstraint::Reset(bool reset_derivatives) {
    for (Index j = 0; j < quantified_variable_size; ++j) {
        intermediate_propositional_values[j].Reset(reset_derivatives);
    }
}


std::vector<LogicCardinalityIndex>
FOLFormulaConstraint::GetPatternsAtCardinality(const LogicCardinalityIndex cardinalityIndex) {
    std::vector<LogicCardinalityIndex> ret(quantified_variable_size);
    LogicCardinalityIndex left_cardinalityIndex = cardinalityIndex;

    for (int j = static_cast<int>(quantified_variable_size) - 1; j >= 0; --j) {  // cast needed because Index is unsigned
        ret[j] = left_cardinalityIndex / variablesRightContextCardinality[j];
        left_cardinalityIndex = left_cardinalityIndex % variablesRightContextCardinality[j];
    }
    return ret;
}

std::vector<std::string>
FOLFormulaConstraint::GetPatternNamesAtCardinality(const LogicCardinalityIndex cardinalityIndex) {
    std::vector<std::string> ret(quantified_variable_size);
    LogicCardinalityIndex left_cardinalityIndex = cardinalityIndex;

    for (int j = static_cast<int>(quantified_variable_size) - 1; j >= 0; --j) {  // cast needed because Index is unsigned
        const LogicCardinalityIndex index = left_cardinalityIndex / variablesRightContextCardinality[j];
        const std::string& domain = fol_formula.GetVariableDomain(quantified_variables[j].name);
        ret[j] = dataset.GetByDomain(domain, index)->GetName();

        left_cardinalityIndex = left_cardinalityIndex % variablesRightContextCardinality[j];
    }
    return ret;
}

// Build the formula Pattern to give in input to the constraint runEval
void FOLFormulaConstraint::BuildFormulaPatterns(
        const LogicCardinalityIndex cardinalityIndex,
        PropositionalFormulaConstraint::VariablesToPatternMap* variables_to_patterns) {
    // Storing the pairs <variable_cardinality, variable_position> positionally by quantifier.
    std::vector<LogicCardinalityIndex> variablesIndexesVector(quantified_variable_size);
    LogicCardinalityIndex left_cardinalityIndex = cardinalityIndex;

    for (int j = static_cast<int>(quantified_variable_size) - 1; j >= 0; --j) {  // cast needed because Index is unsigned
        variablesIndexesVector[j] = left_cardinalityIndex / variablesRightContextCardinality[j];
        left_cardinalityIndex = left_cardinalityIndex % variablesRightContextCardinality[j];
    }
    CHECK_LT(left_cardinalityIndex, variablesCardinality[0]);

    std::vector<std::string> unary_predicate_variables(1);
    for (unsigned int j = 0; j < quantified_variable_size; ++j) {
        const std::string& domain = fol_formula.GetVariableDomain(quantified_variables[j].name);
        unary_predicate_variables[0] = quantified_variables[j].name;
        (*variables_to_patterns)[unary_predicate_variables] =
                dataset.GetByDomain(domain, variablesIndexesVector[j]);
    }
    const PropositionalFormulaConstraint::FormulaVariableSet& variables =
            propositional_formula_constraint.GetVariableSet();
    for (PropositionalFormulaConstraint::FormulaVariableSet::const_iterator iter = variables.begin();
         iter != variables.end(); ++iter) {
        const std::vector<std::string>& predicate_variables = *iter;
        if (predicate_variables.size() <= 1)  continue;  // unary predicates have been processed above

        // for each variable of the literal, get the correspondent pattern
        string pattern_name;
        string domain_name;
        for (unsigned int k = 0; k < predicate_variables.size(); ++k) {
            int pos = 0;
            CHECK_WITH_MESSAGE(
                std::Find(variable_name_to_position_vec /* or variable_name_to_position */,
                          predicate_variables[k], 0, &pos),
                "Variable " + predicate_variables[k] + " not found!");
            if (!pattern_name.empty()) {
                pattern_name += "_";
                domain_name += "_";
            }
            const std::string& domain = fol_formula.GetVariableDomain(quantified_variables[pos].name);
            unary_predicate_variables[0] = quantified_variables[pos].name;
            const Pattern* partial_pattern = dataset.GetByDomain(domain, variablesIndexesVector[pos]);
            CHECK_NE_NULL_WITH_MESSAGE(
                    partial_pattern,
                    StringUtils::StrCat("Unknown pattern n:", variablesIndexesVector[pos], " in domain ", domain));
            pattern_name += partial_pattern->GetName();
            domain_name += domain;
        }
        const Dataset* per_domain_dataset = dataset.GetDomainDataset(domain_name);
        CHECK_NE_NULL_WITH_MESSAGE(per_domain_dataset,  "Can not find domain " + domain_name);
        const Pattern* pattern = (per_domain_dataset != NULL ?
                per_domain_dataset->GetByName(pattern_name) :
                NULL);
        // Pattern may be NULL for a given function, when the pattern was not added as an example.
        (*variables_to_patterns)[predicate_variables] = pattern;
    }
}

void FOLFormulaConstraint::UpdateIntermediatePropositionalValuesHelper(
        const Value value, const PerFunctionDerivative* derivative_values,
        const unsigned int level) {
    const FOLFormula::QUANTIFIER quantifier = quantified_variables[level].quantifier;
    if (quantifier == FOLFormula::forall) {
        // Forall: just forward the value after loss, it will be recursively aggregated.
        intermediate_propositional_values[level].Add(value, derivative_values);
    } else {
        intermediate_propositional_values[level].Set(value, derivative_values);
    }
}

void FOLFormulaConstraint::UpdateIntermediatePropositionalValues(
        const LogicCardinalityIndex cardinalityIndex,
        const Value value, const PerFunctionDerivative* derivative_values) {
    Value intermediate_value = value;
    const PerFunctionDerivative* intermediate_derivative = derivative_values;
    for (int j = 0; j < static_cast<int>(quantified_variable_size); ++j) {
        if ((cardinalityIndex + 1) % variablesRightContextCardinality[j] != 0) {
            // We are not at the end of the domain.
            continue;
        }
        UpdateIntermediatePropositionalValuesHelper(
                intermediate_value, intermediate_derivative, j);
        if (j > 0) {  // Just moved to the next variable, remove the data for the previous variable.
            intermediate_propositional_values[j - 1].Reset(derivative_values != NULL);
        }

        if (intermediate_derivative != NULL)
            intermediate_derivative = &intermediate_propositional_values[j].GetDerivative();
        intermediate_value = intermediate_propositional_values[j].GetValue();
    }
}

void FOLFormulaConstraint::ForwardUpdateIntermediatePropositionalValues(
        const LogicCardinalityIndex cardinalityIndex,
        const LogicCardinalityIndex new_cardinalityIndex,
        const bool compute_derivatives) {
    CHECK_LT(cardinalityIndex, new_cardinalityIndex);
    int v = static_cast<int>(quantified_variable_size) - 1;  // quantifiedVariablesSize can be unsigned!
    CHECK_GE(v, 0);
    for (; v >= 0; --v) {
        const LogicCardinalityIndex index = cardinalityIndex / variablesRightContextCardinality[v];
        const LogicCardinalityIndex new_index = new_cardinalityIndex / variablesRightContextCardinality[v];
        if (index != new_index) {
            break;  // We found the most external variable that has changed! v is its index.
        }
    }

    for (int j = 0; j < v; ++j) {
        UpdateIntermediatePropositionalValuesHelper(
                intermediate_propositional_values[j].GetValue(),
                (compute_derivatives ? &(intermediate_propositional_values[j].GetDerivative()) : NULL),
                j + 1);
        intermediate_propositional_values[j].Reset(compute_derivatives);
    }

}

/****************************************************************
 *  EVAL CONSTRAINT / EVAL GRADIENT CONSTRAINT
 ***************************************************************/
Value FOLFormulaConstraint::Eval(const Value mult, PerFunctionDerivative* constraint_derivatives) {
    CHECK_GT(cardinality, static_cast<LogicCardinalityIndex>(0));

    // do not read loss_constraint value and compute eval and gradient.
    if (constraint_derivatives != NULL) {
        CHECK_NE_NULL_WITH_MESSAGE(classifier, "Missing the classifier to compute the gradient");
    }

    this->Reset(constraint_derivatives != NULL);

    const Value norm =
            (FLAGS_normalize_constraints_by_cardinality ?
             1.0 / static_cast<Value>(cardinality_contributions) : 1.0);
    const Value multiplier = mult * norm * fol_formula.GetLambda();

    // switch between prebuilt and locally built.
    PropositionalFormulaConstraint::VariablesToPatternMap variables_to_pattern;
    const PropositionalFormulaConstraint::VariablesToPatternMap* variables_to_pattern_used = NULL;

    LogicCardinalityIndex i = 0;
    if (this->doOptimization()) {
        i = cardinality_skips[0];  // which is always set.
    }

    const vector<Function::ID>& function_ids = propositional_formula_constraint.GetIds();

    for (; i < cardinality; ++i) {
        if (!prebuiltformulaPatterns.empty()) {
            Cardinality2FormulaPatternsMap::const_iterator iter = prebuiltformulaPatterns.find(i);
            if (iter != prebuiltformulaPatterns.end()) {
                variables_to_pattern_used = &iter->second;
            } else {
                this->BuildFormulaPatterns(i, &variables_to_pattern);
                variables_to_pattern_used = &variables_to_pattern;
            }
        } else {
            this->BuildFormulaPatterns(i, &variables_to_pattern);
            variables_to_pattern_used = &variables_to_pattern;
        }

        // Constraint value for one grounding.
        const Value value = propositional_formula_constraint.Eval(*variables_to_pattern_used);
        // MESSAGE("HERE " << value);

        // Constraint loss for one grounding.
        const Value loss_constraint_value =
                constraint_loss_function.Eval(value, static_cast<Value>(1.0));

        if (constraint_derivatives != NULL) {
            // MESSAGE("DER " << loss_constraint_value);

            for (unsigned int f = 0; f < function_ids.size(); ++f) {
                lower_level_intermediate_propositional_derivative[function_ids[f]].SetAll(0);
            }

            const Value loss_constraint_derivative =
                    constraint_loss_function.EvalDerivative(value, static_cast<Value>(1.0));
            // MESSAGE(pi[0] << ":" << ps[0] << " " << pi[1] << ":" << ps[1] << " PROP_ERROR " << value << "->" << loss_constraint_value);

            // no contribute from this constraint but not continue. It is necessary
            // for the following algorithm that there is a derivative vector. So
            // initialize one with zero.
            if (loss_constraint_derivative != static_cast<Value>(0.0)) {
                for (unsigned int f = 0; f < function_ids.size(); ++f) {
                    const Function::ID& id = function_ids[f];
                    if (!classifier->IsLearnFunction(id)) {
                        continue;  // No Gradient computation for non-learn functions.
                    }

                    const LearnFunction& function = classifier->GetLearnFunctionByIDOrDie(id);
                    // compute the derivative of Phi_c(f)(x) in respect to the f evaluated in f(x_i)
                    // i.e. (D Phi_c(f)/D f)(f(x_i)), where D is the differential operator.
                    propositional_formula_constraint.AccumulateGradient(
                            *variables_to_pattern_used, function,
                            multiplier * loss_constraint_derivative,
                            &(lower_level_intermediate_propositional_derivative[id]));
                    // MESSAGE(pi[0] << ":" << ps[0] << " " << pi[1] << ":" << ps[1] << " " << lower_level_intermediate_propositional_derivative[id].ToStringAsSparse());
                    // MESSAGE("ID " << id << " EL " << i<<"/"<<cardinality << " VAL " << value << " DER " << lower_level_intermediate_propositional_derivative[id].ToString());
                }
            }

            // Forward the loss for quantifier aggregation.
            this->UpdateIntermediatePropositionalValues(
                    i, loss_constraint_value, &lower_level_intermediate_propositional_derivative);
            // CHECK
            for (unsigned int f = 0; f < function_ids.size(); ++f) {
                lower_level_intermediate_propositional_derivative[function_ids[f]].SetAll(0);
            }
        } else {
            // Forward the loss for quantifier aggregation (no derivative).
            this->UpdateIntermediatePropositionalValues(i, loss_constraint_value, NULL);
        }

        if (this->doOptimization()) {
            CardinalitySkips::const_iterator iter = cardinality_skips.find(i);
            if (iter != cardinality_skips.end()) {
                this->ForwardUpdateIntermediatePropositionalValues(
                        i, iter->second, constraint_derivatives != NULL);
                i = iter->second - 1;  // -1 because ++i at the end of the loop.
            }
        }
    }

    const Value constraint_value = intermediate_propositional_values.back().GetValue();
    if (constraint_derivatives != NULL) {
        const PerFunctionDerivative& der = intermediate_propositional_values.back().GetDerivative();
        for (PerFunctionDerivative::iterator iter = constraint_derivatives->begin();
             iter != constraint_derivatives->end(); ++iter) {
            PerFunctionDerivative::const_iterator iter2 = der.find(iter->first);
            if (iter2 != der.end()) {  // else the constraint did not involve this function.
                iter->second.AddInPlace(iter2->second);
            }
        }
    }

    return multiplier * constraint_value;
}
