#ifndef DATASET_CONSTRAINT_H
#define DATASET_CONSTRAINT_H

#include <map>
#include <string>

#include "classifier/functions/function.h"
#include "data/basic_data_types.h"
#include "utils/math/math_vector.h"


namespace Regularization
{

class Dataset;
class Examples;
class BaseClassifier;

/**
 *  Virtual class, single implementations derive from this one.
 */
class DatasetConstraint
{
public:
    DatasetConstraint(const Dataset& dataset_) : dataset(dataset_) { }
    // Destructor
    virtual ~DatasetConstraint() { }

    /*********************************************************
     * EVAL
     *********************************************************/

    // Check if the constraint involve the function id
    virtual bool InvolvesId(const Function::ID& id) const = 0;

    typedef std::map<std::string, Math::Vector<Value> > PerFunctionDerivative;
    // Compute the constraint value and its derivative is constraint_derivatives in not NULL.
    // For efficiency the derivative should be accumulated into constraint_derivatives
    // rescaling it accordingly to mult.
    virtual Value Eval(const Value mult, PerFunctionDerivative* constraint_derivatives) = 0;

    // Get the name of the constraint
    virtual const std::string& GetName() const = 0;

    // Get the priority for the constraint
    virtual unsigned int GetConstraintPriority() const = 0;

protected:
    const Dataset& dataset;
}; // end DatasetConstraint

} // end namespace Regularization

#endif /* DATASET_CONSTRAINT_H */
