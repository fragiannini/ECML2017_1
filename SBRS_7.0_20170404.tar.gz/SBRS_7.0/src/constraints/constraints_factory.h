/*
 * constraints_factory.h
 *
 *  Created on: 11/mag/2011
 *      Author: claudio
 */
#ifndef CONSTRAINTS_FACTORY_H
#define CONSTRAINTS_FACTORY_H

#include "train/trainer.h"  // for Trainer::ConstraintsSet
#include "data/FOL_formula.h"  // for RULE_TYPE

namespace Regularization {

class FOLKnowledgeBase;
class Predicates;
class Examples;
class Dataset;
class BaseClassifier;

class ConstraintsFactory {
public:

    /*
     * Build the set of constraints that must be learned. It is used during
     * the training process
     */
    static void BuildConstraints(const BaseClassifier* classifier,
            const FOLKnowledgeBase& FOL_KnowledgeBase,
            const Predicates& predicates, const Dataset& dataset, const Examples& examples,
            const FOLFormula::RULE_TYPE constraint_type  /* LEARN or VERIFY */,
            const LossFunction& constraint_loss_function,
            Trainer::ConstraintsSet* constraint_set);
};  // end ConstraintsFactory
}  // end namespace Regularization

#endif /* CONSTRAINTS_FACTORY_H */
