/*
 * learn.cpp
 *
 *  Created on: 01/gen/2015
 *      Author: michi
 */

/* Usage example for a full collective classification task.
sbr_predict --transductive --collective_classification \
--training_data_file=data.txt --training_examples_file=examples.txt \
--predicates_file=predicates.txt \
--rules_file=rules.txt \
--validation_examples_file=valid_examples.txt \
--test_examples_file=test_examples.txt \
--max_iterations=100 \
--lambda_labeled_values=1 --lambda_regularization_values=0.01 --lambda_constraint_values=0.1 \
--learning_rate=0.001  --crossvalidation_iterations=30 \
--learning_type=RGD --rgd_plus_algorithm_enabled=true \
--normalize_by_constraint_number=false --squashing_function_type=SIGMOID \
--use_minimum_residuum_continuous_surrogate \
--output_dir=tmp_cc \
--input_dir=input \
--input_classifier_file=tmp/classifier.dat

For just simple classification with no collective classification train step:
sbr_predict --collective_classification=false \
--test_data_file=data.txt --test_examples_file=examples.txt \
--predicates_file=predicates.txt \
--max_iterations=0 \
--squashing_function_type=SIGMOID \
--output_dir=tmp_cc \
--input_dir=input \
--input_classifier_file=tmp/classifier.dat
*/

#include <string>
#include <sstream>

#include "classifier/classifier.h"
#include "train/options.h"
#include "train/train_runner_helper.h"
#include "utils/file_utils.h"  // for ToFileOrDie
#include "utils/gflags/gflags/gflags.h"
#include "utils/gtl_utils.h"  // for ScopedPtr
#include "utils/system.h"  // for Cmdline


// Output Files.
DECLARE_string(output_dir);

// Logging
DECLARE_string(logtofile);

namespace google {
extern void ShowUsageWithFlags(const char* argv0);
}  // end google namespace

using namespace Regularization;

int Run() {
    TrainRunnerHelper::Data data;
    TrainRunnerHelper::LoadData(&data);
    std::string output_summary;

    TrainOptions best_options;
    ScopedPtr<BaseClassifier> best_classifier(
            TrainRunnerHelper::RunTrain(data, &output_summary, &best_options));

    /*****************************************************************************
     * Constraint Verification
     ****************************************************************************/
    TrainRunnerHelper::RunConstraintVerification(data, best_options, best_classifier.Get());

    /*****************************************************************************
     * Dump and Clean up
     ****************************************************************************/
    const std::string output_base_dir = data.options.GetOutputDir();
    StringUtils::ToFileOrDie(
            output_summary, output_base_dir + "/model_output_summary.dat");
    return 0;
}

/**
 * Main: parse cmdline arguments and call the right run function
 **/
int main(int argc, char** argv)
{
    const std::string cmdline = SystemUtils::Cmdline(argc, argv);

    // parse command line
    google::ParseCommandLineFlags(&argc, &argv, true);
    const std::string logtofile = FLAGS_logtofile;
    FLAGS_logtofile = "";  // to avoid writing logs to a non-existing dir.
    FileUtils::MakePathOrDie(FLAGS_output_dir);
    FLAGS_logtofile = (logtofile.empty() ? FLAGS_output_dir + "/log.txt" : logtofile);

    // Logging has already been initialized at this point. Reset it to logging to the new file.
    Logging::ResetLogStreams();
    VMESSAGE(1, "Running " << cmdline);

    // check parameters
    if (argc != 1) {  // everything into flags.
        google::ShowUsageWithFlags(argv[0]);
        for (int i = 1; i < argc; ++i) {
            WARN("Unknown cmdline argument " << argv[i]);
        }
        return -1;
    }

    // Add FLAGS checks.
    return Run();
}
